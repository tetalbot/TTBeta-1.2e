from __future__ import annotations

import socket
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from bot.investigations.link_inspector import (
    UnsafeURL,
    _PublicResolver,
    _redacted_url,
    validate_url_syntax,
)
from bot.tools.discord_read import register_read_tools
from bot.tools.registry import ToolRegistry


class LinkInspectorTests(unittest.IsolatedAsyncioTestCase):
    def test_rejects_private_and_local_destinations(self) -> None:
        for url in (
            "http://127.0.0.1/",
            "http://10.0.0.1/",
            "http://localhost/",
            "http://service.internal/",
        ):
            with self.subTest(url=url), self.assertRaises(UnsafeURL):
                validate_url_syntax(url)

    def test_rejects_credentials_and_nonstandard_ports(self) -> None:
        for url in (
            "ftp://example.com/file",
            "https://user:pass@example.com/",
            "https://example.com:8443/",
        ):
            with self.subTest(url=url), self.assertRaises(UnsafeURL):
                validate_url_syntax(url)

    def test_redacts_query_and_fragment_from_reported_url(self) -> None:
        self.assertEqual(
            _redacted_url("https://example.com/file?token=secret#section"),
            "https://example.com/file",
        )

    async def test_dns_resolver_rejects_private_dns_answers(self) -> None:
        fake_loop = SimpleNamespace(
            getaddrinfo=AsyncMock(return_value=[
                (socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, "", ("10.0.0.7", 443))
            ])
        )
        with patch(
            "bot.investigations.link_inspector.asyncio.get_running_loop",
            return_value=fake_loop,
        ):
            with self.assertRaises(OSError):
                await _PublicResolver().resolve("attacker.example", 443)

    async def test_dns_resolver_accepts_public_dns_answers(self) -> None:
        fake_loop = SimpleNamespace(
            getaddrinfo=AsyncMock(return_value=[
                (socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, "", ("8.8.8.8", 443))
            ])
        )
        with patch(
            "bot.investigations.link_inspector.asyncio.get_running_loop",
            return_value=fake_loop,
        ):
            records = await _PublicResolver().resolve("example.com", 443)
        self.assertEqual(records[0]["host"], "8.8.8.8")


class ReadToolTests(unittest.IsolatedAsyncioTestCase):
    async def test_list_channels_filters_requester_and_bot_visibility(self) -> None:
        visible_to_both = SimpleNamespace(
            id=1,
            name="public",
            topic=None,
            category=None,
            permissions_for=lambda member: SimpleNamespace(view_channel=True),
        )
        hidden_from_requester = SimpleNamespace(
            id=2,
            name="private",
            topic=None,
            category=None,
            permissions_for=lambda member: SimpleNamespace(
                view_channel=member is bot_member
            ),
        )
        guild = SimpleNamespace(id=7, me=None, channels=[visible_to_both, hidden_from_requester])
        requester = SimpleNamespace(id=8, guild=guild, bot=False, guild_permissions=SimpleNamespace())
        bot_member = SimpleNamespace(guild=guild, guild_permissions=SimpleNamespace())
        guild.me = bot_member
        registry = ToolRegistry()
        register_read_tools(registry)

        result = await registry.get("list_channels").handler(
            SimpleNamespace(guild=guild, requester=requester, bot_member=bot_member),
            {"action": "list_channels"},
        )

        self.assertEqual([item["name"] for item in result], ["public"])
