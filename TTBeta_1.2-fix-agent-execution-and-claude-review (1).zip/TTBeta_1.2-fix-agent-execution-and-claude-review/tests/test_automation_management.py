from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from bot.ai import ModerationProposal
from bot.database.automations import AutomationRepository
from bot.automations.engine import resolve_automation_rule
from bot.security.risk_policy import classify_action_risk
from bot.tools.discord_read import register_read_tools
from bot.tools.moderation import build_moderation_registry
from bot.tools.registry import ToolRegistry


class AutomationRepositoryListingTests(unittest.IsolatedAsyncioTestCase):
    async def test_enabled_listing_is_guild_scoped_and_filters_disabled_rules(self) -> None:
        rows = [{
            "id": "aaf19221-9481-47c9-bdbf-03513d01e42a",
            "guild_id": "123",
            "name": "Welcome New Members",
            "trigger_event": "member_join",
            "action_sequence": [{"tool_name": "send_message", "arguments": {}}],
            "enabled": True,
        }]
        pool = SimpleNamespace(fetch=AsyncMock(return_value=rows))
        repository = AutomationRepository(pool)

        result = await repository.list_enabled_for_guild(123)

        self.assertEqual(result[0]["name"], "Welcome New Members")
        query, guild_id, limit = pool.fetch.await_args.args
        self.assertIn("WHERE guild_id=$1 AND enabled=TRUE", query)
        self.assertEqual(guild_id, "123")
        self.assertEqual(limit, 50)


class AutomationReadToolTests(unittest.IsolatedAsyncioTestCase):
    async def test_list_automations_reads_bot_rules_and_keeps_automod_separate(self) -> None:
        repository = SimpleNamespace(list_enabled_for_guild=AsyncMock(return_value=[{
            "id": "aaf19221-9481-47c9-bdbf-03513d01e42a",
            "name": "Welcome New Members",
            "trigger_event": "member_join",
            "action_sequence": [
                {"tool_name": "send_message"},
                {"tool_name": "assign_role"},
            ],
        }]))
        registry = ToolRegistry()
        register_read_tools(registry)
        context = SimpleNamespace(
            guild=SimpleNamespace(id=123),
            bot=SimpleNamespace(automation_repo=repository),
        )

        result = await registry.get("list_automations").handler(
            context, {"action": "list_automations"}
        )

        self.assertEqual(result["count"], 1)
        rule = result["automations"][0]
        self.assertEqual(rule["rule_id"], "aaf19221-9481-47c9-bdbf-03513d01e42a")
        self.assertEqual(rule["name"], "Welcome New Members")
        self.assertEqual(rule["trigger_event"], "member_join")
        self.assertEqual(rule["action_sequence_summary"], "send message → assign role")
        self.assertIn("list_automod_rules", registry.names())
        self.assertIn("list_automations", registry.names())
        self.assertEqual(registry.get("list_automations").risk_level, "READ")
        repository.list_enabled_for_guild.assert_awaited_once_with(123, limit=50)


class AutomationNameResolutionTests(unittest.TestCase):
    def test_uuid_and_fuzzy_name_resolve_the_same_enabled_rule(self) -> None:
        rule = {
            "id": "aaf19221-9481-47c9-bdbf-03513d01e42a",
            "name": "Welcome New Members",
        }
        rules = [rule]

        by_id = resolve_automation_rule(
            rules, rule_id="aaf19221-9481-47c9-bdbf-03513d01e42a"
        )
        by_name = resolve_automation_rule(
            rules, rule_name="Welcome New Members automation"
        )

        self.assertIs(by_id, rule)
        self.assertIs(by_name, rule)

    def test_fuzzy_name_resolution_refuses_ambiguous_matches(self) -> None:
        rules = [
            {"id": "1", "name": "Welcome New Members"},
            {"id": "2", "name": "Welcome New Members"},
        ]
        with self.assertRaisesRegex(ValueError, "several similar matches"):
            resolve_automation_rule(rules, rule_name="Welcome New Members")


class RemoveAutomationToolTests(unittest.TestCase):
    def setUp(self) -> None:
        async def executor(_context, _proposal: ModerationProposal):
            return "disabled"

        self.registry = build_moderation_registry(executor)
        self.tool = self.registry.get("remove_automation")

    def test_schema_exposes_matching_rule_id_and_rule_name_fields(self) -> None:
        properties = self.tool.parameters["properties"]["parameters"]["properties"]
        self.assertIn("rule_id", properties)
        self.assertIn("rule_name", properties)
        self.assertEqual(self.tool.required_permissions, ("manage_guild",))
        self.assertEqual(self.tool.risk_level, "HIGH")
        self.assertEqual(classify_action_risk("remove_automation"), "HIGH")

    def test_uuid_and_name_arguments_are_accepted_but_both_or_neither_are_rejected(self) -> None:
        by_id = {
            "status": "proposal",
            "action": "remove_automation",
            "parameters": {"rule_id": "aaf19221-9481-47c9-bdbf-03513d01e42a"},
        }
        by_name = {
            "status": "proposal",
            "action": "remove_automation",
            "parameters": {"rule_name": "Welcome New Members"},
        }
        both = {
            "status": "proposal",
            "action": "remove_automation",
            "parameters": {
                "rule_id": "aaf19221-9481-47c9-bdbf-03513d01e42a",
                "rule_name": "Welcome New Members",
            },
        }
        neither = {"status": "proposal", "action": "remove_automation", "parameters": {}}

        self.assertIsNone(self.tool.validate_arguments(by_id))
        self.assertIsNone(self.tool.validate_arguments(by_name))
        self.assertIn("exactly one", self.tool.validate_arguments(both))
        self.assertIn("exactly one", self.tool.validate_arguments(neither))
        self.assertTrue(ModerationProposal.from_payload(by_id).is_valid_proposal())
        self.assertTrue(ModerationProposal.from_payload(by_name).is_valid_proposal())


if __name__ == "__main__":
    unittest.main()
