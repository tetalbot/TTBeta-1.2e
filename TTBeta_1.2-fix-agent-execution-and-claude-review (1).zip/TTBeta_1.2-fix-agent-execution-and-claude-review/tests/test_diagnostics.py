from __future__ import annotations

import logging
import unittest
from types import SimpleNamespace

from bot.diagnostics.log_buffer import install_buffer_handler
from bot.tools.diagnostics import (
    _handle_read_file,
    _handle_read_log,
    _validate_read_log_args,
    build_diagnostics_registry,
)


OWNER_ID = 1317193612538417277


def _context(user_id: int) -> SimpleNamespace:
    return SimpleNamespace(requester=SimpleNamespace(id=user_id))


def _proposal(action: str, parameters: dict) -> dict:
    return {
        "status": "proposal",
        "action": action,
        "parameters": parameters,
    }


class DiagnosticsOwnerGateTests(unittest.IsolatedAsyncioTestCase):
    async def test_read_log_denied_for_non_owner(self) -> None:
        result = await _handle_read_log(
            _context(999999), _proposal("read_log", {"lines": 5})
        )
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_log_allowed_for_owner(self) -> None:
        install_buffer_handler()
        marker = "diagnostics-owner-log-buffer-test"
        logging.getLogger("diagnostics-test").warning(marker)

        result = await _handle_read_log(
            _context(OWNER_ID), _proposal("read_log", {"lines": 5})
        )
        self.assertNotIn("AUTHORIZATION_DENIED", result)
        self.assertIn(marker, result)

    async def test_read_file_denied_for_non_owner(self) -> None:
        result = await _handle_read_file(
            _context(999999), _proposal("read_file", {"path": "bot/main.py"})
        )
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_allows_core_runtime_file_for_owner(self) -> None:
        result = await _handle_read_file(
            _context(OWNER_ID), _proposal("read_file", {"path": "bot/main.py"})
        )
        self.assertIn("Discord gateway entry point", result)
        self.assertNotIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_supports_bounded_line_ranges(self) -> None:
        from bot.tools.diagnostics import PROJECT_ROOT

        source_lines = (PROJECT_ROOT / "bot/main.py").read_text(encoding="utf-8").splitlines()
        target_line = next(
            index for index, line in enumerate(source_lines, start=1)
            if "Continue a bounded multi-step request" in line
        )
        start_line = max(1, target_line - 2)
        end_line = min(len(source_lines), target_line + 2)
        result = await _handle_read_file(
            _context(OWNER_ID),
            _proposal(
                "read_file",
                {"path": "bot/main.py", "start_line": start_line, "end_line": end_line},
            ),
        )
        self.assertIn(f"lines {start_line}-{end_line}", result)
        self.assertIn("Continue a bounded multi-step request", result)

    async def test_read_file_rejects_invalid_line_ranges(self) -> None:
        from bot.tools.diagnostics import _validate_read_file_args

        self.assertIsNotNone(
            _validate_read_file_args(
                _proposal("read_file", {"path": "bot/main.py", "start_line": 0})
            )
        )
        self.assertIsNotNone(
            _validate_read_file_args(
                _proposal("read_file", {"path": "bot/main.py", "start_line": 1, "end_line": 500})
            )
        )

    async def test_read_file_blocks_environment_secrets(self) -> None:
        for path in (".env", ".env.local", ".env.production"):
            with self.subTest(path=path):
                result = await _handle_read_file(
                    _context(OWNER_ID), _proposal("read_file", {"path": path})
                )
                self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_blocks_private_ownership_material(self) -> None:
        result = await _handle_read_file(
            _context(OWNER_ID),
            _proposal(
                "read_file",
                {"path": "bot/security/ownership_public_key.py"},
            ),
        )
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_rejects_path_traversal(self) -> None:
        result = await _handle_read_file(
            _context(OWNER_ID),
            _proposal("read_file", {"path": "../../etc/passwd"}),
        )
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_allows_other_project_source_files(self) -> None:
        result = await _handle_read_file(
            _context(OWNER_ID),
            _proposal("read_file", {"path": "bot/tools/moderation.py"}),
        )
        self.assertNotIn("AUTHORIZATION_DENIED", result)
        self.assertIn("moderation", result.lower())

    async def test_read_file_blocks_dependency_and_secret_directories(self) -> None:
        for path in (
            ".secrets/tetalbot_ownership_ed25519.pem",
            ".venv/pyvenv.cfg",
            "node_modules/example/index.js",
        ):
            with self.subTest(path=path):
                result = await _handle_read_file(
                    _context(OWNER_ID), _proposal("read_file", {"path": path})
                )
                self.assertIn("AUTHORIZATION_DENIED", result)

    def test_read_log_line_limit_is_validated(self) -> None:
        self.assertIsNone(
            _validate_read_log_args(_proposal("read_log", {"lines": 100}))
        )
        self.assertIsNotNone(
            _validate_read_log_args(_proposal("read_log", {"lines": 501}))
        )
        self.assertIsNotNone(
            _validate_read_log_args(_proposal("read_log", {"lines": True}))
        )

    def test_diagnostics_tools_are_registered_as_read_only(self) -> None:
        registry = build_diagnostics_registry()
        self.assertEqual(set(registry.names()), {"read_file", "read_log"})
        for name in registry.names():
            self.assertEqual(registry.get(name).risk_level, "READ")


if __name__ == "__main__":
    unittest.main()
