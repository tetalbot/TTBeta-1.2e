from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from scripts.database_env import configure_database_url


class DatabaseEnvironmentTests(unittest.TestCase):
    def test_neon_url_takes_precedence_over_replit_database_url(self) -> None:
        with patch.dict(os.environ, {
            "NEON_DATABASE_URL": "postgresql://neon.example/db",
            "DATABASE_URL": "postgresql://replit.example/db",
        }):
            self.assertEqual(
                configure_database_url(), "postgresql://neon.example/db"
            )
            self.assertEqual(
                os.environ["DATABASE_URL"], "postgresql://neon.example/db"
            )

    def test_database_url_fallback_is_preserved(self) -> None:
        with patch.dict(
            os.environ,
            {"DATABASE_URL": "postgresql://existing.example/db"},
            clear=True,
        ):
            self.assertEqual(
                configure_database_url(), "postgresql://existing.example/db"
            )

    def test_missing_database_url_fails_clearly(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "NEON_DATABASE_URL"):
                configure_database_url()


if __name__ == "__main__":
    unittest.main()
