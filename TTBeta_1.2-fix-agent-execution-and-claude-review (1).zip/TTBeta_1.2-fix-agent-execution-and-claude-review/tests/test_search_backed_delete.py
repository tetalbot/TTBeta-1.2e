from __future__ import annotations

import unittest

from bot.agent.orchestrator import AgentOrchestrator
from bot.ai import ModerationProposal


class SearchBackedDeleteValidationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.search_results = [{
            "tool": "search_recent_messages",
            "success": True,
            "data": {
                "scan_complete": True,
                "results_complete": True,
                "match_count": 2,
                "matches": [
                    {"message_id": "101", "channel_id": "201"},
                    {"message_id": "102", "channel_id": "202"},
                ],
            },
        }]

    def proposal(self, ids=None, evidence=None, channels=None):
        ids = ids if ids is not None else ["101", "102"]
        evidence = evidence if evidence is not None else ["101", "102"]
        channels = channels if channels is not None else {"101": "201", "102": "202"}
        return ModerationProposal(
            status="proposal",
            action="delete",
            evidence_message_ids=[int(value) for value in evidence],
            parameters={
                "message_ids": ids,
                "message_channels": channels,
            },
        )

    def test_accepts_exact_search_results_and_channel_mapping(self) -> None:
        self.assertIsNone(
            AgentOrchestrator._validate_search_backed_delete(
                self.proposal(), self.search_results
            )
        )

    def test_rejects_fabricated_or_partial_message_ids(self) -> None:
        error = AgentOrchestrator._validate_search_backed_delete(
            self.proposal(ids=["101"], evidence=["101"], channels={"101": "201"}),
            self.search_results,
        )
        self.assertIn("exactly match", error or "")

    def test_rejects_mismatched_channel_mapping(self) -> None:
        error = AgentOrchestrator._validate_search_backed_delete(
            self.proposal(channels={"101": "999", "102": "202"}),
            self.search_results,
        )
        self.assertIn("channel mapping", error or "")

    def test_rejects_incomplete_search(self) -> None:
        incomplete = [{
            **self.search_results[0],
            "data": {
                **self.search_results[0]["data"],
                "scan_complete": False,
            },
        }]
        error = AgentOrchestrator._validate_search_backed_delete(
            self.proposal(), incomplete
        )
        self.assertIn("search was incomplete", error or "")

    def test_direct_message_id_delete_without_search_remains_supported(self) -> None:
        self.assertIsNone(
            AgentOrchestrator._validate_search_backed_delete(
                self.proposal(ids=["101"], evidence=["101"], channels={"101": "201"}),
                [],
            )
        )


if __name__ == "__main__":
    unittest.main()
