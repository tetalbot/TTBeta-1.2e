from __future__ import annotations

import unittest
from unittest.mock import AsyncMock

from bot.tools.moderation import (
    ACTION_DESCRIPTIONS,
    ACTION_PARAMETER_FIELDS,
    ACTION_REQUIRED_PARAMETERS,
    REQUIRED_PERMISSIONS,
    build_moderation_registry,
)
from bot.tools.discord_read import register_read_tools
from bot.utils import ACTION_NAMES


class RegisteredToolCoverageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = build_moderation_registry(AsyncMock())

    def test_every_action_name_has_exactly_one_registered_tool(self) -> None:
        self.assertEqual(set(self.registry.names()), ACTION_NAMES)

    def test_every_action_has_permission_and_risk_metadata(self) -> None:
        for name in ACTION_NAMES:
            with self.subTest(tool=name):
                tool = self.registry.get(name)
                self.assertIn(tool.risk_level, {"READ", "LOW", "HIGH"})
                self.assertIsInstance(tool.required_permissions, tuple)
                self.assertTrue(tool.description.strip())

    def test_every_parameter_schema_entry_belongs_to_a_registered_action(self) -> None:
        self.assertLessEqual(set(ACTION_PARAMETER_FIELDS), ACTION_NAMES)
        self.assertLessEqual(set(ACTION_REQUIRED_PARAMETERS), ACTION_NAMES)
        self.assertLessEqual(set(ACTION_DESCRIPTIONS), ACTION_NAMES)

    def test_required_parameter_fields_exist_in_the_action_schema(self) -> None:
        for name, required in ACTION_REQUIRED_PARAMETERS.items():
            with self.subTest(tool=name):
                schema = self.registry.get(name).parameters
                fields = schema["properties"]["parameters"]["properties"]
                self.assertLessEqual(set(required), set(fields))

    def test_each_action_schema_pins_the_action_name(self) -> None:
        for name in ACTION_NAMES:
            with self.subTest(tool=name):
                schema = self.registry.get(name).parameters
                self.assertEqual(schema["properties"]["action"]["enum"], [name])

    def test_custom_message_tool_is_registered_with_confirmation_risk(self) -> None:
        tool = self.registry.get("send_message")
        self.assertEqual(tool.risk_level, "HIGH")
        fields = tool.parameters["properties"]["parameters"]["properties"]
        self.assertEqual(fields["destination"]["enum"], ["channel", "dm"])
        self.assertIn("content", fields)
        self.assertIn("send_message", ACTION_NAMES)

    def test_custom_message_needs_confirmation_but_no_moderator_permission(self) -> None:
        tool = self.registry.get("send_message")
        self.assertEqual(tool.required_permissions, ())
        self.assertEqual(tool.risk_level, "HIGH")

    def test_server_role_listing_is_read_only_and_needs_no_manage_roles(self) -> None:
        tool = self.registry.get("list_roles")
        self.assertEqual(tool.risk_level, "READ")
        self.assertEqual(tool.required_permissions, ())

    def test_read_registry_contains_member_role_lookup(self) -> None:
        registry = build_moderation_registry(AsyncMock())
        register_read_tools(registry)
        self.assertIn("get_member_roles", registry.names())
        self.assertEqual(registry.get("get_member_roles").risk_level, "READ")


if __name__ == "__main__":
    unittest.main()
