from __future__ import annotations

import unittest
from unittest.mock import AsyncMock
from types import SimpleNamespace

from bot.ai import ModerationProposal
from bot.main import BatchConfirmationView


def batch_records(count: int, completed: int = 0) -> list[dict]:
    records = []
    for index in range(count):
        proposal = ModerationProposal(
            status="proposal",
            action="create_category",
            parameters={"category_name": f"category-{index}"},
        )
        records.append({
            "id": f"proposal-{index}",
            "guild_id": "10",
            "user_id": "20",
            "status": "completed" if index < completed else "pending",
            "arguments": proposal.to_payload(),
            "metadata": {"batch_id": "batch-test", "batch_index": index},
        })
    return records


class BatchConfirmationViewTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.bot = SimpleNamespace(proposal_repo=object())

    def test_ten_actions_fit_discord_component_row_limits(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(10)
        )

        self.assertEqual(len(view.children), 21)
        row_counts = {}
        for item in view.children:
            row_counts[item.row] = row_counts.get(item.row, 0) + 1
        self.assertEqual(row_counts, {0: 4, 1: 4, 2: 4, 3: 4, 4: 5})
        self.assertTrue(all(count <= 5 for count in row_counts.values()))

    def test_only_next_action_can_be_confirmed(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(3)
        )
        confirms = [
            item for item in view.children
            if item.custom_id and item.custom_id.endswith(":confirm")
        ]
        cancels = [
            item for item in view.children
            if item.custom_id and item.custom_id.endswith(":cancel")
        ]

        self.assertEqual([item.disabled for item in confirms], [False, True, True])
        self.assertEqual([item.disabled for item in cancels], [False, False, False])

    def test_success_unlocks_the_next_action_only(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(3, completed=1)
        )
        confirms = [
            item for item in view.children
            if item.custom_id and item.custom_id.endswith(":confirm")
        ]

        self.assertEqual([item.disabled for item in confirms], [True, False, True])

    def test_confirmation_custom_ids_are_unique(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(10)
        )
        custom_ids = [item.custom_id for item in view.children]
        self.assertEqual(len(custom_ids), len(set(custom_ids)))

    async def test_only_initiating_moderator_can_use_queue(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(2)
        )
        response = SimpleNamespace(send_message=AsyncMock())
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=99),
            guild=SimpleNamespace(id=10),
            response=response,
        )

        allowed = await view.interaction_check(interaction)

        self.assertFalse(allowed)
        response.send_message.assert_awaited_once()
        self.assertTrue(response.send_message.await_args.kwargs["ephemeral"])

    async def test_initiating_moderator_can_use_queue_in_original_server(self) -> None:
        view = BatchConfirmationView(
            self.bot, "batch-test", 20, 10, batch_records(2)
        )
        interaction = SimpleNamespace(
            user=SimpleNamespace(id=20),
            guild=SimpleNamespace(id=10),
            response=SimpleNamespace(),
        )

        self.assertTrue(await view.interaction_check(interaction))


if __name__ == "__main__":
    unittest.main()
