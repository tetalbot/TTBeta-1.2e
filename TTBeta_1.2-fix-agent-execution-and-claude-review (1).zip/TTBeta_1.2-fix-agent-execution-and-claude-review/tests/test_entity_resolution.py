from __future__ import annotations

import unittest
from types import SimpleNamespace

from bot.entity_resolution import resolve_named_entity, resolve_tool_entities
from bot.commands.roles import resolve_role
from bot.commands.channels import _channel, _category


class FuzzyEntityResolutionTests(unittest.TestCase):
    def test_ignores_case_spacing_punctuation_and_invisible_separators(self) -> None:
        channel = SimpleNamespace(name="Text\u2060freeride")
        resolved = resolve_named_entity(
            "text freeride", [channel], name_of=lambda item: item.name
        )
        self.assertIs(resolved, channel)

    def test_selects_the_closest_typo_match(self) -> None:
        roles = [
            SimpleNamespace(name="Verified"),
            SimpleNamespace(name="Santa Cruz"),
            SimpleNamespace(name="Supporter"),
        ]
        resolved = resolve_named_entity(
            "santa crz", roles, name_of=lambda item: item.name
        )
        self.assertIs(resolved, roles[1])

    def test_asks_when_two_candidates_are_equally_close(self) -> None:
        candidates = [
            SimpleNamespace(name="freeride"),
            SimpleNamespace(name="freerides"),
        ]
        with self.assertRaisesRegex(ValueError, "Which one did you mean"):
            resolve_named_entity(
                "freerid", candidates, name_of=lambda item: item.name
            )

    def test_does_not_guess_when_no_candidate_is_close(self) -> None:
        candidates = [SimpleNamespace(name="Announcements")]
        self.assertIsNone(
            resolve_named_entity(
                "santa cruz", candidates, name_of=lambda item: item.name
            )
        )

    def test_tool_arguments_resolve_role_typo_to_id(self) -> None:
        role = SimpleNamespace(id=123, name="Santa Cruz")
        guild = SimpleNamespace(roles=[role], channels=[], categories=[], members=[])
        arguments = {"action": "assign_role", "parameters": {"role_name": "santa crz"}}
        self.assertIsNone(resolve_tool_entities(guild, arguments))
        self.assertEqual(arguments["parameters"]["role_id"], "123")

    def test_tool_arguments_refuse_ambiguous_role_names(self) -> None:
        guild = SimpleNamespace(
            roles=[
                SimpleNamespace(id=1, name="freeride"),
                SimpleNamespace(id=2, name="freerides"),
            ],
            channels=[], categories=[], members=[],
        )
        arguments = {"action": "assign_role", "parameters": {"role_name": "freerid"}}
        error = resolve_tool_entities(guild, arguments)
        self.assertIsNotNone(error)
        self.assertIn("Which one did you mean", error)

    def test_tool_arguments_resolve_member_display_name(self) -> None:
        member = SimpleNamespace(id=456, name="rider", display_name="Trail Rider")
        guild = SimpleNamespace(roles=[], channels=[], categories=[], members=[member])
        arguments = {"action": "kick", "target_user_name": "trail ridr", "parameters": {}}
        self.assertIsNone(resolve_tool_entities(guild, arguments))
        self.assertEqual(arguments["target_user_id"], "456")
        self.assertNotIn("target_user_name", arguments)

    def test_tool_arguments_do_not_resolve_creation_names(self) -> None:
        guild = SimpleNamespace(roles=[], channels=[], categories=[], members=[])
        arguments = {"action": "create_role", "parameters": {"role_name": "New Role"}}
        self.assertIsNone(resolve_tool_entities(guild, arguments))
        self.assertNotIn("role_id", arguments["parameters"])

    def test_role_lookup_uses_fuzzy_name_matching(self) -> None:
        role = SimpleNamespace(id=123, name="Santa Cruz")
        guild = SimpleNamespace(roles=[role], get_role=lambda _role_id: None)
        self.assertIs(resolve_role(guild, {"role_name": "santa crz"}), role)

    def test_channel_and_category_lookup_use_fuzzy_matching(self) -> None:
        channel = SimpleNamespace(id=1, name="Text\u2060freeride")
        category = SimpleNamespace(id=2, name="Archive")
        guild = SimpleNamespace(
            channels=[channel, category],
            categories=[category],
            get_channel=lambda _channel_id: None,
        )
        self.assertIs(_channel(guild, {"channel_name": "text freeride"}), channel)
        self.assertIs(_category(guild, {"category_name": "archiv"}), category)


if __name__ == "__main__":
    unittest.main()
