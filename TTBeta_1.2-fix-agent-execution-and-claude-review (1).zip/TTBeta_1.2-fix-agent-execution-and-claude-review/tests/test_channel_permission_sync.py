from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from bot.ai import ModerationProposal
from bot.commands.channels import execute
from bot.security.risk_policy import classify_action_risk
from bot.tools.moderation import build_moderation_registry


class FakeChannel:
    def __init__(self, *, category=None, permissions_synced=False):
        self.id = 123
        self.name = "staff-commands"
        self.category = category
        self.permissions_synced = permissions_synced
        self.edit = AsyncMock(side_effect=self._edit)

    async def _edit(self, **changes):
        if changes.get("sync_permissions"):
            self.permissions_synced = True
        if "category" in changes:
            self.category = changes["category"]
        return self


class ChannelPermissionSyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_syncs_with_existing_parent_and_verifies_result(self):
        category = SimpleNamespace(name="Staff")
        channel = FakeChannel(category=category)
        guild = SimpleNamespace(
            get_channel=lambda channel_id: channel if channel_id == 123 else None,
            channels=[channel],
            categories=[category],
        )
        interaction = SimpleNamespace(guild=guild)
        proposal = ModerationProposal(
            status="proposal",
            action="modify_channel",
            parameters={"channel_id": 123, "sync_permissions": True},
        )

        result = await execute(interaction, proposal)

        self.assertIn("synchronised permissions", result)
        self.assertIn("Staff", result)
        channel.edit.assert_awaited_once()
        self.assertTrue(channel.edit.await_args.kwargs["sync_permissions"])

    async def test_refuses_sync_when_channel_has_no_category(self):
        channel = FakeChannel()
        guild = SimpleNamespace(
            get_channel=lambda channel_id: channel if channel_id == 123 else None,
            channels=[channel],
            categories=[],
        )
        interaction = SimpleNamespace(guild=guild)
        proposal = ModerationProposal(
            status="proposal",
            action="modify_channel",
            parameters={"channel_id": 123, "sync_permissions": True},
        )

        with self.assertRaisesRegex(ValueError, "not inside a category"):
            await execute(interaction, proposal)
        channel.edit.assert_not_awaited()

    async def test_sync_operation_is_high_risk_even_if_channel_edits_are_low_risk(self):
        ordinary = ModerationProposal(
            status="proposal", action="modify_channel",
            parameters={"channel_name": "staff-commands", "name": "staff"},
        )
        sync = ModerationProposal(
            status="proposal", action="modify_channel",
            parameters={"channel_name": "staff-commands", "sync_permissions": True},
        )

        self.assertEqual(classify_action_risk("modify_channel", ordinary), "LOW")
        self.assertEqual(classify_action_risk("modify_channel", sync), "HIGH")

    async def test_sync_field_is_exposed_in_registered_schema(self):
        registry = build_moderation_registry(AsyncMock())
        schema = next(item for item in registry.schemas() if item["name"] == "modify_channel")
        fields = schema["parameters"]["properties"]["parameters"]["properties"]

        self.assertEqual(fields["sync_permissions"]["type"], "boolean")
        self.assertIn("parent category", fields["sync_permissions"]["description"])
