from __future__ import annotations

import unittest
from datetime import timedelta
from types import SimpleNamespace

import discord

from bot.tools.discord_read import register_read_tools
from bot.tools.registry import ToolRegistry


class FakeChannel:
    def __init__(self, channel_id: int, name: str, messages: list[object]):
        self.id = channel_id
        self.name = name
        self._messages = messages

    def permissions_for(self, _member: object) -> SimpleNamespace:
        return SimpleNamespace(view_channel=True, read_message_history=True)

    def history(self, *, limit: int, after: object, oldest_first: bool):
        async def iterator():
            for message in self._messages[:limit]:
                if after is None or message.created_at > after:
                    yield message
        return iterator()


def make_message(
    channel: FakeChannel,
    message_id: int,
    author_id: int,
    created_at: object,
    content: str = "hello",
    *,
    bot: bool = False,
):
    author = SimpleNamespace(
        id=author_id,
        bot=bot,
        display_name=f"user-{author_id}",
    )
    return SimpleNamespace(
        id=message_id,
        author=author,
        channel=channel,
        created_at=created_at,
        content=content,
        jump_url=f"https://discord.com/channels/1/{channel.id}/{message_id}",
    )


class RecentMessageSearchTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.requester = SimpleNamespace(id=10)
        self.bot_member = SimpleNamespace(id=99)

    async def test_author_only_search_returns_exact_ids_and_channel_mapping(self) -> None:
        now = discord.utils.utcnow()
        channel = FakeChannel(200, "general", [])
        channel._messages = [
            make_message(channel, 1, 1234, now - timedelta(seconds=30), "first"),
            make_message(channel, 2, 5555, now - timedelta(seconds=20), "other user"),
            make_message(channel, 3, 1234, now - timedelta(minutes=5), "too old"),
            make_message(channel, 4, 1234, now - timedelta(seconds=10), "second"),
        ]
        guild = SimpleNamespace(text_channels=[channel], get_channel=lambda _id: channel)
        registry = ToolRegistry()
        register_read_tools(registry)
        tool = registry.get("search_recent_messages")
        context = SimpleNamespace(
            guild=guild,
            requester=self.requester,
            bot_member=self.bot_member,
            source_message=None,
        )

        error = tool.validate_arguments({
            "action": "search_recent_messages",
            "author_id": "1234",
            "minutes": 2,
        })
        self.assertIsNone(error)
        result = await tool.handler(context, {
            "action": "search_recent_messages",
            "author_id": "1234",
            "minutes": 2,
        })

        self.assertEqual(result["match_count"], 2)
        self.assertTrue(result["scan_complete"])
        self.assertTrue(result["results_complete"])
        self.assertEqual(
            [item["message_id"] for item in result["matches"]],
            ["1", "4"],
        )
        self.assertEqual(result["matches"][0]["channel_id"], "200")

    async def test_search_requires_author_or_text_query(self) -> None:
        registry = ToolRegistry()
        register_read_tools(registry)
        tool = registry.get("search_recent_messages")

        self.assertIn(
            "query, author_id, or latest_count",
            tool.validate_arguments({"action": "search_recent_messages"}) or "",
        )


    async def test_latest_count_search_uses_current_channel_and_includes_bots(self) -> None:
        now = discord.utils.utcnow()
        channel = FakeChannel(200, "general", [])
        channel._messages = [
            make_message(channel, index, 1000 + index, now - timedelta(seconds=index),
                         f"message {index}", bot=(index % 2 == 0))
            for index in range(205, 0, -1)
        ]
        source = make_message(channel, 999, 10, now, "delete the last 200 messages")
        channel._messages.insert(0, source)
        guild = SimpleNamespace(text_channels=[channel], get_channel=lambda _id: channel)
        registry = ToolRegistry()
        register_read_tools(registry)
        tool = registry.get("search_recent_messages")
        context = SimpleNamespace(
            guild=guild,
            requester=self.requester,
            bot_member=self.bot_member,
            source_message=source,
        )
        arguments = {"action": "search_recent_messages", "latest_count": 200}
        self.assertIsNone(tool.validate_arguments(arguments))
        result = await tool.handler(context, arguments)
        self.assertEqual(result["match_count"], 200)
        self.assertTrue(result["scan_complete"])
        self.assertTrue(result["results_complete"])
        self.assertEqual(result["matches"][0]["message_id"], "205")
        self.assertNotIn("999", {item["message_id"] for item in result["matches"]})
        self.assertTrue(any(int(item["author_id"]) % 2 == 0 for item in result["matches"]))

    async def test_latest_count_accepts_nested_agent_proposal_parameters(self) -> None:
        registry = ToolRegistry()
        register_read_tools(registry)
        tool = registry.get("search_recent_messages")
        arguments = {
            "status": "proposal",
            "action": "search_recent_messages",
            "parameters": {"latest_count": 25},
        }
        self.assertIsNone(tool.validate_arguments(arguments))

    async def test_latest_count_validation_is_bounded_and_exclusive(self) -> None:
        registry = ToolRegistry()
        register_read_tools(registry)
        tool = registry.get("search_recent_messages")
        self.assertIn(
            "between 1 and 200",
            tool.validate_arguments({
                "action": "search_recent_messages", "latest_count": 201,
            }) or "",
        )
        self.assertIn(
            "cannot be combined",
            tool.validate_arguments({
                "action": "search_recent_messages",
                "latest_count": 20,
                "query": "spam",
            }) or "",
        )

    async def test_author_search_includes_bot_messages_when_explicitly_requested(self) -> None:
        now = discord.utils.utcnow()
        channel = FakeChannel(200, "general", [])
        channel._messages = [
            make_message(channel, 1, 1234, now - timedelta(seconds=10), "bot output", bot=True),
        ]
        guild = SimpleNamespace(text_channels=[channel], get_channel=lambda _id: channel)
        registry = ToolRegistry()
        register_read_tools(registry)
        result = await registry.get("search_recent_messages").handler(
            SimpleNamespace(
                guild=guild,
                requester=self.requester,
                bot_member=self.bot_member,
                source_message=None,
            ),
            {"action": "search_recent_messages", "author_id": "1234", "minutes": 2},
        )

        self.assertEqual(result["match_count"], 1)
        self.assertEqual(result["matches"][0]["author_id"], "1234")

