from __future__ import annotations

import unittest
from unittest.mock import AsyncMock, MagicMock

from bot.database.automations import AutomationRepository


class AutomationRecoveryRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_recover_stale_executions_marks_only_running_rows(self) -> None:
        pool = MagicMock()
        pool.fetch = AsyncMock(return_value=[{"id": "one"}, {"id": "two"}])
        repository = AutomationRepository(pool)

        recovered = await repository.recover_stale_executions(stale_after_minutes=30)

        self.assertEqual(recovered, 2)
        query = pool.fetch.await_args.args[0]
        self.assertIn("SET result='failed'", query)
        self.assertIn("WHERE result='running'", query)
        self.assertIn("triggered_at < NOW()", query)
        self.assertIn("Automatic replay was suppressed", query)
        self.assertEqual(pool.fetch.await_args.args[1], 30)

    async def test_recovery_window_is_clamped_to_safe_bounds(self) -> None:
        pool = MagicMock()
        pool.fetch = AsyncMock(return_value=[])
        repository = AutomationRepository(pool)

        await repository.recover_stale_executions(stale_after_minutes=0)
        self.assertEqual(pool.fetch.await_args.args[1], 1)

        await repository.recover_stale_executions(stale_after_minutes=10_000)
        self.assertEqual(pool.fetch.await_args.args[1], 1440)

    async def test_recovery_returns_zero_when_nothing_is_stale(self) -> None:
        pool = MagicMock()
        pool.fetch = AsyncMock(return_value=[])
        repository = AutomationRepository(pool)

        self.assertEqual(await repository.recover_stale_executions(), 0)


    async def test_finish_does_not_increment_rule_when_recovery_won_race(self) -> None:
        class Transaction:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *_args):
                return False

        class Connection:
            def __init__(self):
                self.fetchrow = AsyncMock(return_value=None)
                self.execute = AsyncMock()

            def transaction(self):
                return Transaction()

        class Acquire:
            def __init__(self, connection):
                self.connection = connection

            async def __aenter__(self):
                return self.connection

            async def __aexit__(self, *_args):
                return False

        connection = Connection()
        pool = MagicMock()
        pool.acquire = MagicMock(return_value=Acquire(connection))
        repository = AutomationRepository(pool)

        await repository.finish_execution(
            "execution-id",
            rule_id="rule-id",
            guild_id=123,
            result="success",
            actions_taken=[],
        )

        connection.fetchrow.assert_awaited_once()
        connection.execute.assert_not_awaited()

    async def test_finish_updates_rule_only_after_winning_running_transition(self) -> None:
        class Transaction:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *_args):
                return False

        class Connection:
            def __init__(self):
                self.fetchrow = AsyncMock(return_value={"id": "execution-id"})
                self.execute = AsyncMock()

            def transaction(self):
                return Transaction()

        class Acquire:
            def __init__(self, connection):
                self.connection = connection

            async def __aenter__(self):
                return self.connection

            async def __aexit__(self, *_args):
                return False

        connection = Connection()
        pool = MagicMock()
        pool.acquire = MagicMock(return_value=Acquire(connection))
        repository = AutomationRepository(pool)

        await repository.finish_execution(
            "execution-id",
            rule_id="rule-id",
            guild_id=123,
            result="success",
            actions_taken=[],
        )

        connection.fetchrow.assert_awaited_once()
        connection.execute.assert_awaited_once()
        self.assertIn("execution_count=execution_count+1", connection.execute.await_args.args[0])


if __name__ == "__main__":
    unittest.main()
