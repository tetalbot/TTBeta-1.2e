from __future__ import annotations

import json
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from bot.ai import GeminiInterpreter, ModerationProposal
from bot.config import CaseStore, ModerationCase
from bot.main import (
    ConfirmationView,
    Conversation,
    ModerationBot,
    _batch_outcome,
    pending_proposal_for_turn,
)
from bot.utils import MAX_TIMEOUT_MINUTES, can_moderate, clamp_timeout


FALLBACK_QUESTION = (
    "I could not safely interpret that. Could you restate the action and target?"
)


class FakeRole:
    def __init__(self, rank: int) -> None:
        self.rank = rank

    def __ge__(self, other: "FakeRole") -> bool:
        return self.rank >= other.rank


class FakeMember:
    def __init__(
        self,
        member_id: int,
        guild: SimpleNamespace,
        role_rank: int,
    ) -> None:
        self.id = member_id
        self.guild = guild
        self.top_role = FakeRole(role_rank)


class FakeGeminiResponse:
    def __init__(self, text: object) -> None:
        self.text = text


class GeminiResponseTests(unittest.IsolatedAsyncioTestCase):
    async def interpret_with_response(self, response: object) -> ModerationProposal:
        client = SimpleNamespace(
            aio=SimpleNamespace(
                models=SimpleNamespace(
                    generate_content=AsyncMock(return_value=response),
                )
            )
        )
        interpreter = GeminiInterpreter.__new__(GeminiInterpreter)
        interpreter.client = client
        interpreter.model = "test-model"
        context = SimpleNamespace(
            as_text=lambda: "No additional context.",
            image_parts=lambda: [],
        )
        return await interpreter.interpret(context, [])

    async def test_invalid_json_returns_safe_question(self) -> None:
        proposal = await self.interpret_with_response(FakeGeminiResponse("not json"))

        self.assertEqual(proposal.status, "question")
        self.assertEqual(proposal.question, FALLBACK_QUESTION)

    async def test_non_object_json_returns_safe_question(self) -> None:
        proposal = await self.interpret_with_response(FakeGeminiResponse(json.dumps([])))

        self.assertEqual(proposal.status, "question")
        self.assertEqual(proposal.question, FALLBACK_QUESTION)

    async def test_response_without_choices_returns_safe_question(self) -> None:
        proposal = await self.interpret_with_response(SimpleNamespace())

        self.assertEqual(proposal.status, "question")
        self.assertEqual(proposal.question, FALLBACK_QUESTION)


class GeminiResponseTests(unittest.IsolatedAsyncioTestCase):
    async def test_usage_metering_is_optional_when_callback_is_not_configured(self) -> None:
        interpreter = GeminiInterpreter.__new__(GeminiInterpreter)
        await interpreter._record_usage(SimpleNamespace(), SimpleNamespace(), "test")

class ProposalValidationTests(unittest.TestCase):
    def test_scheduled_event_requires_all_creation_fields(self) -> None:
        incomplete = ModerationProposal(
            status="proposal", action="create_event",
            parameters={"event_name": "Community ride"},
        )
        complete = ModerationProposal(
            status="proposal", action="create_event",
            parameters={
                "event_name": "Community ride",
                "start_time": "2026-11-01T10:00:00+02:00",
                "end_time": "2026-11-01T12:00:00+02:00",
                "location": "Brasov",
            },
        )
        self.assertFalse(incomplete.is_valid_proposal())
        self.assertTrue(complete.is_valid_proposal())

    def test_asset_creation_requires_all_source_fields(self) -> None:
        proposal = ModerationProposal(
            status="proposal", action="create_sticker",
            parameters={
                "channel_id": "1", "message_id": "2",
                "attachment_id": "3", "asset_name": "test",
            },
        )
        self.assertFalse(proposal.is_valid_proposal())

    def test_proposal_without_target_is_not_executable(self) -> None:
        proposal = ModerationProposal(status="proposal", action="ban")

        self.assertFalse(proposal.is_valid_proposal())

    def test_unknown_action_is_not_executable(self) -> None:
        proposal = ModerationProposal(
            status="proposal",
            action="delete-all-members",
            target_user_id=42,
        )

        self.assertFalse(proposal.is_valid_proposal())


class PermissionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.guild = SimpleNamespace(owner_id=999, me=None)

    def test_self_moderation_is_rejected(self) -> None:
        actor = FakeMember(10, self.guild, role_rank=5)
        self.guild.me = FakeMember(20, self.guild, role_rank=10)

        allowed, reason = can_moderate(actor, actor)

        self.assertFalse(allowed)
        self.assertEqual(reason, "You cannot moderate yourself.")

    def test_target_with_equal_or_higher_role_is_rejected(self) -> None:
        actor = FakeMember(10, self.guild, role_rank=5)
        equal_target = FakeMember(20, self.guild, role_rank=5)
        higher_target = FakeMember(21, self.guild, role_rank=6)
        self.guild.me = FakeMember(30, self.guild, role_rank=10)

        self.assertEqual(
            can_moderate(actor, equal_target),
            (False, "Your highest role must be above the target's highest role."),
        )
        self.assertEqual(
            can_moderate(actor, higher_target),
            (False, "Your highest role must be above the target's highest role."),
        )

    def test_actor_and_bot_must_both_outrank_target(self) -> None:
        actor = FakeMember(10, self.guild, role_rank=5)
        target = FakeMember(20, self.guild, role_rank=4)
        self.guild.me = FakeMember(30, self.guild, role_rank=4)

        allowed, reason = can_moderate(actor, target)

        self.assertFalse(allowed)
        self.assertEqual(reason, "My highest role must be above the target's highest role.")

    def test_owner_can_moderate_non_owner_target_when_bot_outranks_target(self) -> None:
        owner = FakeMember(999, self.guild, role_rank=1)
        target = FakeMember(20, self.guild, role_rank=8)
        self.guild.me = FakeMember(30, self.guild, role_rank=9)

        self.assertEqual(can_moderate(owner, target), (True, ""))


class TimeoutLimitTests(unittest.TestCase):
    def test_missing_duration_uses_discord_maximum(self) -> None:
        self.assertEqual(clamp_timeout(None), MAX_TIMEOUT_MINUTES)

    def test_duration_is_clamped_to_discord_maximum(self) -> None:
        self.assertEqual(clamp_timeout(MAX_TIMEOUT_MINUTES + 1), MAX_TIMEOUT_MINUTES)

    def test_duration_is_never_zero_or_negative(self) -> None:
        self.assertEqual(clamp_timeout(0), 1)
        self.assertEqual(clamp_timeout(-30), 1)


class ProposalSafetyTests(unittest.IsolatedAsyncioTestCase):
    async def test_empty_mass_selection_fails_closed(self) -> None:
        candidate = SimpleNamespace(
            message=SimpleNamespace(
                id=101,
                author=SimpleNamespace(id=201),
            ),
            as_text=lambda: "message 101",
        )
        orchestrator = SimpleNamespace(
            select_message_ids=AsyncMock(return_value=set())
        )
        proposal = ModerationProposal(
            status="proposal",
            action="ban",
            parameters={"target_description": "repeat spam"},
        )
        self_ref = SimpleNamespace(orchestrator=orchestrator)

        with patch(
            "bot.main.scan_guild_messages",
            new=AsyncMock(return_value=[candidate]),
        ):
            result = await ModerationBot.prepare_mass_targets(
                self_ref,
                SimpleNamespace(id=3),
                "ban all repeat spammers",
                proposal,
            )

        self.assertEqual(result.status, "question")
        self.assertEqual(result.target_user_ids, [])
        self.assertIsNotNone(result.question)

    async def test_mass_selection_uses_only_returned_candidate_ids(self) -> None:
        candidates = [
            SimpleNamespace(
                message=SimpleNamespace(
                    id=101,
                    author=SimpleNamespace(id=201),
                ),
                as_text=lambda: "message 101",
            ),
            SimpleNamespace(
                message=SimpleNamespace(
                    id=102,
                    author=SimpleNamespace(id=202),
                ),
                as_text=lambda: "message 102",
            ),
        ]
        orchestrator = SimpleNamespace(
            select_message_ids=AsyncMock(return_value={102, 999999})
        )
        proposal = ModerationProposal(
            status="proposal",
            action="ban",
            parameters={"target_description": "repeat spam"},
        )
        guild = SimpleNamespace(
            id=3,
            members=[
                SimpleNamespace(id=201, display_name="First"),
                SimpleNamespace(id=202, display_name="Second"),
            ]
        )

        with patch(
            "bot.main.scan_guild_messages",
            new=AsyncMock(return_value=candidates),
        ):
            result = await ModerationBot.prepare_mass_targets(
                SimpleNamespace(orchestrator=orchestrator),
                guild,
                "ban all repeat spammers",
                proposal,
            )

        self.assertEqual(result.target_user_ids, [202])
        self.assertEqual(result.evidence_message_ids, [102])

    async def test_empty_delete_selection_does_not_queue_candidates(self) -> None:
        candidate = SimpleNamespace(
            message=SimpleNamespace(
                id=101,
                author=SimpleNamespace(id=201),
                channel=SimpleNamespace(id=301),
                content="promotional spam",
            ),
            as_text=lambda: "message 101",
        )
        orchestrator = SimpleNamespace(
            select_message_ids=AsyncMock(return_value=set())
        )
        proposal = ModerationProposal(
            status="proposal",
            action="delete_by_description",
            parameters={"description": "promotional spam"},
        )

        with patch(
            "bot.main.scan_guild_messages",
            new=AsyncMock(return_value=[candidate]),
        ):
            result = await ModerationBot.prepare_search_proposal(
                SimpleNamespace(orchestrator=orchestrator),
                SimpleNamespace(id=3),
                SimpleNamespace(
                    channel=SimpleNamespace(),
                    author=SimpleNamespace(id=4),
                ),
                proposal,
            )

        self.assertEqual(result.status, "question")
        self.assertEqual(result.parameters["message_ids"], [])
        self.assertEqual(result.evidence_message_ids, [])
        self.assertIsNotNone(result.question)

    def test_pending_proposal_is_not_carried_to_a_new_request(self) -> None:
        proposal = ModerationProposal(status="question", action="ban")
        conversation = Conversation(pending_proposal=proposal)

        result = pending_proposal_for_turn(conversation, is_reply_to_bot=False)

        self.assertIsNone(result)
        self.assertIsNone(conversation.pending_proposal)

    def test_direct_reply_can_continue_an_in_memory_clarification(self) -> None:
        proposal = ModerationProposal(status="question", action="ban")
        conversation = Conversation(pending_proposal=proposal)

        result = pending_proposal_for_turn(conversation, is_reply_to_bot=True)

        self.assertIs(result, proposal)

    def test_batch_summary_reports_partial_success_and_failure(self) -> None:
        summary = _batch_outcome(
            ["<@1> (`1`)"],
            [("<@2> (`2`)", "The target no longer exists.")],
        )

        self.assertIn("Partially completed: 1/2 succeeded.", summary)
        self.assertIn("The target no longer exists.", summary)

    def test_batch_with_no_success_is_reported_as_failure(self) -> None:
        with self.assertRaisesRegex(ValueError, "No targets were changed"):
            _batch_outcome([], [("message 7", "The target no longer exists.")])

    def test_partial_case_status_is_persisted(self) -> None:
        case = ModerationCase(
            case_id=7,
            guild_id=1,
            moderator_id=2,
            target_id=3,
            action="ban",
            reason=None,
            rule_reference=None,
            evidence_message_ids=[],
            proposed_at="2026-10-30T00:00:00+00:00",
        )
        store = CaseStore(cases=[case])
        store.save = Mock()

        store.mark_confirmed(
            7,
            "Partially completed: 1/2 succeeded.",
            status="partially_completed",
        )

        self.assertEqual(case.status, "partially_completed")
        self.assertIn("1/2", case.outcome or "")


class ConfirmationViewTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.repository = SimpleNamespace(
            get=AsyncMock(return_value={"metadata": {"case_id": 7}}),
            close=AsyncMock(return_value=True),
        )
        self.bot = SimpleNamespace(
            proposal_repo=self.repository,
            close_case_if_present=AsyncMock(),
        )
        self.view = ConfirmationView(
            self.bot,
            proposal_id="proposal-123",
            initiator_id=100,
            guild_id=200,
        )

    async def test_only_requesting_moderator_can_confirm(self) -> None:
        unauthorized_response = SimpleNamespace(send_message=AsyncMock())
        unauthorized = SimpleNamespace(
            user=SimpleNamespace(id=101),
            guild=SimpleNamespace(id=200),
            response=unauthorized_response,
        )

        allowed = await self.view.interaction_check(unauthorized)

        self.assertFalse(allowed)
        unauthorized_response.send_message.assert_awaited_once_with(
            "Only the moderator who requested this action can confirm it.",
            ephemeral=True,
        )

    async def test_requesting_moderator_passes_ownership_check(self) -> None:
        authorized = SimpleNamespace(
            user=SimpleNamespace(id=100),
            guild=SimpleNamespace(id=200),
        )

        self.assertTrue(await self.view.interaction_check(authorized))

    async def test_cancel_closes_persisted_proposal_without_execution(self) -> None:
        response = SimpleNamespace(defer=AsyncMock())
        message = SimpleNamespace(edit=AsyncMock())
        interaction = SimpleNamespace(
            response=response,
            followup=SimpleNamespace(send=AsyncMock()),
            message=message,
        )

        await self.view.cancel.callback(interaction)

        self.repository.get.assert_awaited_once_with("proposal-123")
        self.repository.close.assert_awaited_once_with(
            "proposal-123",
            "cancelled",
            "Cancelled by the initiating moderator.",
        )
        self.bot.close_case_if_present.assert_called_once_with(
            7,
            "cancelled",
            "Cancelled by the initiating moderator.",
        )
        message.edit.assert_awaited_once_with(
            content="Cancelled. No action was taken.",
            view=None,
        )


if __name__ == "__main__":
    unittest.main()