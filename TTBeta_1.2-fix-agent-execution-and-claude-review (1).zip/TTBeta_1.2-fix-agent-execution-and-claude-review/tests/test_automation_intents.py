from bot.automations.intents import looks_like_automation_request


def test_welcome_every_new_member_routes_to_automation_flow():
    request = (
        "welcome every new member in Text-main-chat, remind them to read "
        "and follow the rules in Text-rules, and tell them they can ask "
        "if they have questions"
    )

    assert looks_like_automation_request(request)


def test_each_new_member_routes_to_automation_flow():
    assert looks_like_automation_request("Welcome each new member when they join.")


def test_ordinary_welcome_message_is_not_automation():
    assert not looks_like_automation_request("Write a welcome message for the new member.")
