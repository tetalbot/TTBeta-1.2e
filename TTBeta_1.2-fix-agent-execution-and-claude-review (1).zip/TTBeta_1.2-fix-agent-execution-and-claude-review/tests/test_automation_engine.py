from __future__ import annotations

import unittest
from types import SimpleNamespace

from bot.ai import ModerationProposal
from bot.automations.engine import (
    conditions_match,
    ensure_automation_role_safe,
    render_event_placeholders,
    validate_automation_definition,
)
from bot.tools.moderation import build_moderation_registry


class AutomationEngineTests(unittest.TestCase):
    def setUp(self) -> None:
        async def executor(_context, _proposal: ModerationProposal):
            return "ok"

        self.registry = build_moderation_registry(executor)
        self.role = SimpleNamespace(id=123, name="Verified", is_default=lambda: False)
        self.channel = SimpleNamespace(id=456, name="welcome")
        self.guild = SimpleNamespace(
            roles=[self.role],
            text_channels=[self.channel],
            voice_channels=[],
            threads=[],
        )

    def test_conditions_match_member_join_bot_flag_and_account_age(self) -> None:
        conditions = {"is_bot": False, "min_account_age_days": 7}
        self.assertTrue(conditions_match(
            conditions, {"is_bot": False, "account_age_days": 30}
        ))
        self.assertFalse(conditions_match(
            conditions, {"is_bot": True, "account_age_days": 30}
        ))
        self.assertFalse(conditions_match(
            conditions, {"is_bot": False, "account_age_days": 2}
        ))

    def test_message_conditions_match_channel_and_literal_text(self) -> None:
        conditions = {"channel_id": "456", "content_contains": "help"}
        event = {"channel_id": "456", "content": "I need HELP please"}
        self.assertTrue(conditions_match(conditions, event))
        self.assertFalse(conditions_match(conditions, {**event, "channel_id": "999"}))
        self.assertFalse(conditions_match(conditions, {**event, "content": "hello"}))

    def test_natural_language_automation_intent_detection(self) -> None:
        from bot.main import _looks_like_automation_request

        self.assertTrue(_looks_like_automation_request(
            "Whenever someone joins, give them the verified role."
        ))
        self.assertTrue(_looks_like_automation_request(
            "Set up a rule to watch for spam."
        ))
        self.assertFalse(_looks_like_automation_request(
            "Please warn this member for spamming."
        ))

    def test_voice_leave_conditions_match_channel(self) -> None:
        from bot.automations.engine import validate_automation_definition

        raw = {
            "name": "Voice leave notice",
            "description": "Notify when a member leaves a voice channel.",
            "trigger_event": "voice_leave",
            "trigger_conditions": {"voice_channel_id": "789"},
            "action_sequence": [{
                "tool_name": "send_message",
                "arguments": {
                    "status": "proposal",
                    "action": "send_message",
                    "parameters": {
                        "destination": "channel",
                        "channel_id": "456",
                        "content": "A member left voice.",
                    },
                },
            }],
        }
        self.guild.voice_channels = [SimpleNamespace(id=789, name="Gaming")]
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        conditions = draft["trigger_conditions"]
        self.assertTrue(conditions_match(conditions, {"channel_id": "789"}))
        self.assertFalse(conditions_match(conditions, {"channel_id": "790"}))

    def test_event_placeholders_render_inside_message_content(self) -> None:
        rendered = render_event_placeholders(
            {
                "content": "Welcome $event.member_mention ($event.username)",
                "mention_user_id": "$event.member_id",
            },
            {
                "member_mention": "<@42>",
                "username": "Trail Rider",
                "member_id": "42",
                "message_id": "99",
                "channel_id": "88",
            },
        )
        self.assertEqual(
            rendered["content"], "Welcome <@42> (Trail Rider)"
        )
        self.assertEqual(rendered["mention_user_id"], "42")
        self.assertEqual(
            render_event_placeholders(
                {"message_ids": ["$event.message_id"], "channel": "$event.channel_id"},
                {"message_id": "99", "channel_id": "88"},
            ),
            {"message_ids": ["99"], "channel": "88"},
        )

    def test_valid_member_join_role_assignment_rule(self) -> None:
        raw = {
            "name": "Give verified role to humans",
            "description": "When a member joins, assign the verified role if they are not a bot.",
            "trigger_event": "member_join",
            "trigger_conditions": {"is_bot": False},
            "action_sequence": [{
                "tool_name": "assign_role",
                "arguments": {
                    "status": "proposal",
                    "action": "assign_role",
                    "target_user_id": "$event.member_id",
                    "parameters": {"role_name": "Verifed"},
                },
            }],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        self.assertEqual(draft["trigger_event"], "member_join")
        self.assertEqual(
            draft["action_sequence"][0]["arguments"]["parameters"]["role_id"],
            "123",
        )
        self.assertEqual(
            draft["action_sequence"][0]["arguments"]["target_user_id"],
            "$event.member_id",
        )

    def test_valid_message_automation_can_mention_only_the_triggering_member(self) -> None:
        raw = {
            "name": "Welcome message",
            "description": "Post a welcome message when a member joins.",
            "trigger_event": "member_join",
            "trigger_conditions": {"is_bot": False},
            "action_sequence": [{
                "tool_name": "send_message",
                "arguments": {
                    "status": "proposal",
                    "action": "send_message",
                    "parameters": {
                        "destination": "channel",
                        "channel_name": "welcom",
                        "content": "Welcome $event.member_mention!",
                    },
                },
            }],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        parameters = draft["action_sequence"][0]["arguments"]["parameters"]
        self.assertEqual(parameters["channel_id"], "456")
        self.assertEqual(parameters["mention_user_id"], "$event.member_id")

    def test_automation_rejects_destructive_actions(self) -> None:
        raw = {
            "name": "Bad rule",
            "description": "Ban every new member.",
            "trigger_event": "member_join",
            "trigger_conditions": {},
            "action_sequence": [{
                "tool_name": "ban",
                "arguments": {
                    "status": "proposal",
                    "action": "ban",
                    "target_user_id": "$event.member_id",
                    "parameters": {},
                },
            }],
        }
        with self.assertRaisesRegex(ValueError, "not permitted"):
            validate_automation_definition(
                raw, guild=self.guild, registry=self.registry
            )

    def test_dispatch_entity_resolution_matches_role_channel_and_member_names(self) -> None:
        from bot.entity_resolution import resolve_tool_entities

        member = SimpleNamespace(
            id=42, display_name="Trail Rider", global_name="Trail Rider", name="trailrider"
        )
        guild = SimpleNamespace(
            roles=[self.role],
            channels=[self.channel],
            members=[member],
        )
        arguments = {
            "action": "assign_role",
            "target_user_name": "Trail Rder",
            "parameters": {"role_name": "Verifed"},
        }
        self.assertIsNone(resolve_tool_entities(guild, arguments))
        self.assertEqual(arguments["target_user_id"], "42")
        self.assertEqual(arguments["parameters"]["role_id"], "123")

    def test_dispatch_entity_resolution_rejects_duplicate_exact_names(self) -> None:
        from bot.entity_resolution import resolve_tool_entities

        guild = SimpleNamespace(
            roles=[
                SimpleNamespace(id=1, name="Moderator"),
                SimpleNamespace(id=2, name="Moderator"),
            ],
            channels=[],
            members=[],
        )
        arguments = {
            "action": "assign_role",
            "target_user_id": "42",
            "parameters": {"role_name": "Moderator"},
        }
        error = resolve_tool_entities(guild, arguments)
        self.assertIsNotNone(error)
        self.assertIn("several similar matches", error)

    def test_dispatch_entity_resolution_reports_missing_matches(self) -> None:
        from bot.entity_resolution import resolve_tool_entities

        guild = SimpleNamespace(roles=[], channels=[], members=[])
        arguments = {
            "action": "assign_role",
            "target_user_id": "42",
            "parameters": {"role_name": "Nonexistent"},
        }
        error = resolve_tool_entities(guild, arguments)
        self.assertIsNotNone(error)
        self.assertIn("couldn't find a role", error)

    def test_automation_banlist_requires_manual_staff_confirmation(self) -> None:
        for action in ("ban", "unban", "kick"):
            raw = {
                "name": "Blocked moderation rule",
                "description": "This action must never run automatically.",
                "trigger_event": "member_join",
                "trigger_conditions": {},
                "action_sequence": [{
                    "tool_name": action,
                    "arguments": {
                        "status": "proposal",
                        "action": action,
                        "target_user_id": "$event.member_id",
                        "parameters": {},
                    },
                }],
            }
            with self.subTest(action=action):
                with self.assertRaisesRegex(
                    ValueError, "can never be automated.*manual staff confirmation"
                ):
                    validate_automation_definition(
                        raw, guild=self.guild, registry=self.registry
                    )

    def test_warn_mute_and_delete_are_registered_as_automation_eligible(self) -> None:
        for action in ("warn", "mute", "delete"):
            with self.subTest(action=action):
                self.assertTrue(self.registry.get(action).automation_eligible)

    def test_automation_warn_targets_only_the_triggering_member(self) -> None:
        raw = {
            "name": "Warn on join",
            "description": "Warn a member when they join.",
            "trigger_event": "member_join",
            "trigger_conditions": {},
            "action_sequence": [{
                "tool_name": "warn",
                "arguments": {
                    "status": "proposal",
                    "action": "warn",
                    "target_user_id": "$event.member_id",
                    "parameters": {},
                },
            }],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        self.assertEqual(
            draft["action_sequence"][0]["arguments"]["target_user_id"],
            "$event.member_id",
        )

    def test_automation_mute_requires_a_bounded_duration(self) -> None:
        raw = {
            "name": "Short timeout on join",
            "description": "Apply a short timeout to new members.",
            "trigger_event": "member_join",
            "trigger_conditions": {},
            "action_sequence": [{
                "tool_name": "mute",
                "arguments": {
                    "status": "proposal",
                    "action": "mute",
                    "target_user_id": "$event.member_id",
                    "duration_minutes": 30,
                    "parameters": {},
                },
            }],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        self.assertEqual(
            draft["action_sequence"][0]["arguments"]["duration_minutes"], 30
        )

    def test_automation_delete_is_limited_to_the_triggering_message(self) -> None:
        raw = {
            "name": "Delete matching message",
            "description": "Delete a message that matches the configured condition.",
            "trigger_event": "message_contains",
            "trigger_conditions": {"content_contains": "spam"},
            "action_sequence": [{
                "tool_name": "delete",
                "arguments": {
                    "status": "proposal",
                    "action": "delete",
                    "parameters": {},
                },
            }],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        arguments = draft["action_sequence"][0]["arguments"]
        self.assertEqual(arguments["evidence_message_ids"], ["$event.message_id"])
        self.assertEqual(
            arguments["parameters"]["message_ids"], ["$event.message_id"]
        )

    def test_role_change_trigger_cannot_start_another_role_change(self) -> None:
        raw = {
            "name": "Role loop",
            "description": "Assign a second role when the first role is assigned.",
            "trigger_event": "role_assign",
            "trigger_conditions": {"role_id": "123"},
            "action_sequence": [{
                "tool_name": "assign_role",
                "arguments": {
                    "status": "proposal",
                    "action": "assign_role",
                    "target_user_id": "$event.member_id",
                    "parameters": {"role_id": "123"},
                },
            }],
        }
        with self.assertRaisesRegex(ValueError, "prevents automation loops"):
            validate_automation_definition(
                raw, guild=self.guild, registry=self.registry
            )

    def test_privileged_roles_are_rejected_for_automation(self) -> None:
        privileged_role = SimpleNamespace(
            id=999,
            name="Admin",
            managed=False,
            is_default=lambda: False,
            permissions=SimpleNamespace(administrator=True),
        )
        with self.assertRaisesRegex(ValueError, "privileged server permissions"):
            ensure_automation_role_safe(privileged_role)

    def test_member_join_workflow_can_welcome_everyone_and_gate_role_assignment(self) -> None:
        raw = {
            "name": "Welcome and verify",
            "description": "Welcome every new member, but only assign the role to non-bot accounts.",
            "trigger_event": "member_join",
            "trigger_conditions": {},
            "action_sequence": [
                {
                    "tool_name": "send_message",
                    "arguments": {
                        "status": "proposal",
                        "action": "send_message",
                        "parameters": {
                            "destination": "channel",
                            "channel_id": "456",
                            "content": "Welcome $event.member_mention!",
                        },
                    },
                },
                {
                    "tool_name": "assign_role",
                    "conditions": {"is_bot": False},
                    "arguments": {
                        "status": "proposal",
                        "action": "assign_role",
                        "target_user_id": "$event.member_id",
                        "parameters": {"role_id": "123"},
                    },
                },
            ],
        }
        draft = validate_automation_definition(
            raw, guild=self.guild, registry=self.registry
        )
        self.assertEqual(draft["action_sequence"][0]["conditions"], {})
        self.assertEqual(
            draft["action_sequence"][1]["conditions"], {"is_bot": False}
        )
        self.assertTrue(conditions_match(
            draft["action_sequence"][1]["conditions"], {"is_bot": False}
        ))
        self.assertFalse(conditions_match(
            draft["action_sequence"][1]["conditions"], {"is_bot": True}
        ))

    def test_unknown_conditions_are_rejected(self) -> None:
        raw = {
            "name": "Bad conditions",
            "description": "Unsupported condition.",
            "trigger_event": "member_join",
            "trigger_conditions": {"random_field": True},
            "action_sequence": [{
                "tool_name": "assign_role",
                "arguments": {
                    "status": "proposal",
                    "action": "assign_role",
                    "target_user_id": "$event.member_id",
                    "parameters": {"role_id": "123"},
                },
            }],
        }
        with self.assertRaisesRegex(ValueError, "Unsupported trigger condition"):
            validate_automation_definition(
                raw, guild=self.guild, registry=self.registry
            )


if __name__ == "__main__":
    unittest.main()
