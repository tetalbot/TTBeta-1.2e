from __future__ import annotations

import unittest

from bot.ai import ModerationProposal
from bot.tools.moderation import AUTOMATION_ELIGIBLE_ACTIONS, build_moderation_registry


class ToolAutomationEligibilityTests(unittest.TestCase):
    def test_registry_exposes_only_explicitly_eligible_tools(self) -> None:
        async def executor(_context, _proposal: ModerationProposal):
            return "ok"

        registry = build_moderation_registry(executor)
        eligible = {item["name"] for item in registry.automation_schemas()}
        self.assertEqual(
            eligible,
            {"assign_role", "remove_role", "send_message", "warn", "mute", "delete"},
        )
        self.assertEqual(eligible, AUTOMATION_ELIGIBLE_ACTIONS)
        self.assertIn("warn", eligible)
        self.assertIn("mute", eligible)
        self.assertIn("delete", eligible)
        self.assertNotIn("ban", eligible)
        self.assertNotIn("lock_channel", eligible)
        self.assertNotIn("delete_by_description", eligible)

    def test_full_tool_catalog_includes_eligibility_flag(self) -> None:
        async def executor(_context, _proposal: ModerationProposal):
            return "ok"

        registry = build_moderation_registry(executor)
        schemas = {item["name"]: item for item in registry.schemas()}
        self.assertTrue(schemas["assign_role"]["automation_eligible"])
        self.assertFalse(schemas["delete_role"]["automation_eligible"])


if __name__ == "__main__":
    unittest.main()
