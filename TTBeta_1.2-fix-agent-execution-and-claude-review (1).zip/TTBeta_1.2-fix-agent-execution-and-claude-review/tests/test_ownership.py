from __future__ import annotations
import base64, hashlib, json, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from bot.security import ownership

class OwnershipIntegrityTests(unittest.TestCase):
    def make_release(self, root: Path) -> str:
        key = Ed25519PrivateKey.generate()
        public = key.public_key().public_bytes_raw()
        hashes = {}
        for relative in ownership.PROTECTED_FILES:
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text('fixture: ' + relative, encoding='utf-8')
            hashes[relative] = hashlib.sha256(target.read_bytes()).hexdigest()
        identity = {'project_id': ownership.PROJECT_ID, 'project_name': ownership.PROJECT_NAME, 'owner': ownership.OWNER, 'creator': ownership.CREATOR, 'attribution': ownership.ATTRIBUTION, 'copyright': ownership.COPYRIGHT}
        payload = {'manifest_version': 1, 'identity': identity, 'files': hashes}
        canonical = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
        envelope = {'payload': payload, 'signature': base64.b64encode(key.sign(canonical)).decode('ascii')}
        (root / ownership.MANIFEST_NAME).write_text(json.dumps(envelope), encoding='utf-8')
        return base64.b64encode(public).decode('ascii')

    def test_valid_signed_release_passes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = self.make_release(root)
            with patch.object(ownership, 'PUBLIC_KEY_B64', public):
                self.assertEqual(ownership.verify_ownership(root)['owner'], 'Tritrax')

    def test_modified_protected_file_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = self.make_release(root)
            (root / ownership.PROTECTED_FILES[0]).write_text('credits removed', encoding='utf-8')
            with patch.object(ownership, 'PUBLIC_KEY_B64', public):
                with self.assertRaises(ownership.OwnershipIntegrityError): ownership.verify_ownership(root)

    def test_modified_manifest_fails_signature(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            public = self.make_release(root)
            path = root / ownership.MANIFEST_NAME
            envelope = json.loads(path.read_text(encoding='utf-8'))
            envelope['payload']['identity']['owner'] = 'Someone else'
            path.write_text(json.dumps(envelope), encoding='utf-8')
            with patch.object(ownership, 'PUBLIC_KEY_B64', public):
                with self.assertRaises(ownership.OwnershipIntegrityError): ownership.verify_ownership(root)

    def test_missing_manifest_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(ownership, 'PUBLIC_KEY_B64', base64.b64encode(b'x' * 32).decode()):
                with self.assertRaises(ownership.OwnershipIntegrityError): ownership.verify_ownership(Path(directory))

class OwnershipDatabaseTests(unittest.IsolatedAsyncioTestCase):
    async def test_database_identity_mismatch_fails(self):
        pool = SimpleNamespace(fetchrow=AsyncMock(return_value={'project_id': ownership.PROJECT_ID, 'owner': 'Changed', 'creator': ownership.CREATOR, 'attribution': ownership.ATTRIBUTION, 'copyright': ownership.COPYRIGHT}))
        with self.assertRaises(ownership.OwnershipIntegrityError): await ownership.verify_database_identity(pool)

    async def test_database_identity_match_passes(self):
        pool = SimpleNamespace(fetchrow=AsyncMock(return_value={'project_id': ownership.PROJECT_ID, 'owner': ownership.OWNER, 'creator': ownership.CREATOR, 'attribution': ownership.ATTRIBUTION, 'copyright': ownership.COPYRIGHT}))
        await ownership.verify_database_identity(pool)
