from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from bot.main import ModerationBot


class AutomationDispatchTests(unittest.IsolatedAsyncioTestCase):
    def make_bot(self, repository, interpreter, tool_registry=None):
        instance = object.__new__(ModerationBot)
        instance.automation_repo = repository
        instance.interpreter = interpreter
        instance.tool_registry = tool_registry
        instance.config_store = SimpleNamespace(
            get=lambda _guild_id: SimpleNamespace(staff_channel_id=0)
        )
        return instance

    async def test_revoked_creator_permission_blocks_ai_evaluation(self) -> None:
        repository = SimpleNamespace(
            list_for_event=AsyncMock(return_value=[{
                "id": "rule-id",
                "created_by": "42",
                "trigger_conditions": {},
                "use_ai_reasoning": True,
                "description": "Only run for appropriate members",
                "action_sequence": [],
            }]),
            begin_execution=AsyncMock(return_value="execution-id"),
            finish_execution=AsyncMock(),
        )
        interpreter = SimpleNamespace(
            evaluate_automation_event=AsyncMock(return_value=(True, "approved"))
        )
        creator = SimpleNamespace(
            id=42,
            bot=False,
            guild_permissions=SimpleNamespace(manage_guild=False),
        )
        guild = SimpleNamespace(
            id=100,
            me=object(),
            get_member=lambda _user_id: creator,
            get_channel=lambda _channel_id: None,
            system_channel=None,
        )
        bot = self.make_bot(repository, interpreter)

        await bot._dispatch_automation_event(
            guild,
            "member_join",
            {"member_id": "7", "is_bot": False},
            "member_join:7",
        )

        interpreter.evaluate_automation_event.assert_not_awaited()
        repository.finish_execution.assert_awaited_once()
        self.assertEqual(
            repository.finish_execution.await_args.kwargs["result"], "skipped"
        )

    async def test_failed_action_stops_remaining_sequence(self) -> None:
        repository = SimpleNamespace(
            list_for_event=AsyncMock(return_value=[{
                "id": "rule-id",
                "created_by": "42",
                "trigger_conditions": {},
                "use_ai_reasoning": False,
                "action_sequence": [
                    {
                        "tool_name": "send_message",
                        "arguments": {
                            "status": "proposal",
                            "action": "send_message",
                            "parameters": {
                                "destination": "channel",
                                "channel_id": "55",
                                "content": "First message",
                            },
                        },
                    },
                    {
                        "tool_name": "send_message",
                        "arguments": {
                            "status": "proposal",
                            "action": "send_message",
                            "parameters": {
                                "destination": "channel",
                                "channel_id": "55",
                                "content": "Second message",
                            },
                        },
                    },
                ],
            }]),
            begin_execution=AsyncMock(return_value="execution-id"),
            finish_execution=AsyncMock(),
        )
        creator = SimpleNamespace(
            id=42,
            bot=False,
            guild_permissions=SimpleNamespace(manage_guild=True),
        )
        guild = SimpleNamespace(
            id=100,
            me=object(),
            get_member=lambda _user_id: creator,
            get_channel=lambda _channel_id: None,
            system_channel=None,
        )
        calls = []

        async def fail_first(_context, _arguments):
            calls.append("first")
            raise RuntimeError("simulated Discord send failure")

        tool = SimpleNamespace(
            automation_eligible=True,
            validate_arguments=lambda _arguments: None,
            handler=fail_first,
        )
        registry = SimpleNamespace(get=lambda _name: tool)
        bot = self.make_bot(repository, SimpleNamespace(), registry)

        def authorize(**_kwargs):
            return SimpleNamespace(allowed=True, message="")

        with patch("bot.main.authorize_operation", side_effect=authorize):
            await bot._dispatch_automation_event(
                guild,
                "member_join",
                {"member_id": "7", "member_mention": "<@7>", "username": "Member"},
                "member_join:7",
            )

        self.assertEqual(calls, ["first"])
        repository.finish_execution.assert_awaited_once()
        self.assertEqual(
            repository.finish_execution.await_args.kwargs["result"], "failed"
        )
        self.assertIn(
            "send_message failed:",
            repository.finish_execution.await_args.kwargs["error"],
        )


if __name__ == "__main__":
    unittest.main()
