from __future__ import annotations
import unittest
from types import SimpleNamespace
from bot.ai import AgentStep, ModerationProposal
from bot.security.authorization import OWNER_USER_ID, is_owner
from bot.security.risk_policy import classify_action_risk
from bot.tools.diagnostics import (
    _handle_read_file, _handle_read_log, build_diagnostics_registry,
)

class DiagnosticsOwnerGateTests(unittest.IsolatedAsyncioTestCase):
    async def test_read_log_denied_for_non_owner(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=999999))
        result = await _handle_read_log(context, {"parameters": {"lines": 10}})
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_log_allowed_for_owner(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=OWNER_USER_ID))
        result = await _handle_read_log(context, {"parameters": {"lines": 5}})
        self.assertNotIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_blocks_env(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=OWNER_USER_ID))
        result = await _handle_read_file(context, {"parameters": {"path": ".env"}})
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_blocks_path_traversal(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=OWNER_USER_ID))
        result = await _handle_read_file(context, {"parameters": {"path": "../../etc/passwd"}})
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_read_file_denied_for_non_owner(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=999999))
        result = await _handle_read_file(context, {"parameters": {"path": "replit.md"}})
        self.assertIn("AUTHORIZATION_DENIED", result)

    async def test_owner_can_read_allowlisted_live_file(self):
        context = SimpleNamespace(requester=SimpleNamespace(id=OWNER_USER_ID))
        result = await _handle_read_file(context, {"parameters": {"path": "pyproject.toml"}})
        self.assertIn("=== pyproject.toml (lines 1-", result)
        self.assertIn("cryptography", result)

    def test_diagnostics_tools_are_registered_as_read_only(self):
        registry = build_diagnostics_registry()
        self.assertEqual(set(registry.names()), {"read_file", "read_log"})
        for name in registry.names():
            self.assertEqual(registry.get(name).risk_level, "READ")
            self.assertEqual(classify_action_risk(name), "READ")

    def test_owner_identity_is_exact(self):
        self.assertTrue(is_owner(1317193612538417277))
        self.assertFalse(is_owner(1317193612538417278))

class ContinuationMetadataTests(unittest.TestCase):
    def test_agent_step_parses_explicit_continuation_flag(self):
        step = AgentStep.from_payload({
            "decision": "tool_call",
            "tool_name": "create_category",
            "arguments": {"status": "proposal", "action": "create_category", "parameters": {"category_name": "Archive"}},
            "continue_after_confirmation": True,
        })
        self.assertTrue(step.continue_after_confirmation)

    def test_proposal_continuation_metadata_survives_serialization(self):
        proposal = ModerationProposal(
            status="proposal", action="create_category",
            parameters={"category_name": "Archive"},
            continue_after_confirmation=True, continuation_depth=2,
        )
        restored = ModerationProposal.from_payload(proposal.to_payload())
        self.assertTrue(restored.continue_after_confirmation)
        self.assertEqual(restored.continuation_depth, 2)
