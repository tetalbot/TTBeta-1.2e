from __future__ import annotations

import unittest
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock

from bot.database.proposals import ProposalRepository, ProposalStateError
from bot.database.connection import verify_schema
from bot.database.context import ContextRepository
from bot.database.settings import GuildSettingsRepository, ModerationCaseRepository
from bot.config import CaseStore, GuildConfig, ModerationCase, ConfigStore


class ProposalRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_claim_is_one_atomic_conditional_update(self) -> None:
        row = {
            "id": "p-1",
            "guild_id": "1",
            "user_id": "2",
            "status": "executing",
            "arguments": {},
            "metadata": {},
        }
        pool = SimpleNamespace(fetchrow=AsyncMock(return_value=row))
        repository = ProposalRepository(pool)

        result = await repository.claim_for_execution(
            "p-1", guild_id=1, user_id=2
        )

        self.assertEqual(result["status"], "executing")
        pool.fetchrow.assert_awaited_once()
        query = pool.fetchrow.await_args.args[0]
        self.assertIn("SET status = 'executing'", query)
        self.assertIn("status = 'pending' AND expires_at > now()", query)

    async def test_get_batch_returns_actions_in_execution_order(self) -> None:
        rows = [
            {"id": "p-1", "metadata": {"batch_index": 0}},
            {"id": "p-2", "metadata": {"batch_index": 1}},
        ]
        pool = SimpleNamespace(fetch=AsyncMock(return_value=rows))
        repository = ProposalRepository(pool)

        result = await repository.get_batch("batch-1")

        self.assertEqual([item["id"] for item in result], ["p-1", "p-2"])
        self.assertIn("metadata->>'batch_id' = $1", pool.fetch.await_args.args[0])
        self.assertIn("ORDER BY (metadata->>'batch_index')::integer ASC", pool.fetch.await_args.args[0])

    async def test_finish_execution_rejects_cancelled_and_expired_states(self) -> None:
        pool = SimpleNamespace(fetchrow=AsyncMock())
        repository = ProposalRepository(pool)

        for status in ("cancelled", "expired"):
            with self.subTest(status=status):
                with self.assertRaises(ValueError):
                    await repository.finish_execution(
                        "p-1",
                        status=status,
                        result={"message": "invalid terminal transition"},
                    )

        pool.fetchrow.assert_not_awaited()

    async def test_finish_execution_only_finalizes_executing_proposals(self) -> None:
        pool = SimpleNamespace(fetchrow=AsyncMock(return_value={"id": "p-1"}))
        repository = ProposalRepository(pool)

        result = await repository.finish_execution(
            "p-1",
            status="completed",
            result={"outcome": "done"},
        )

        self.assertTrue(result)
        query = pool.fetchrow.await_args.args[0]
        self.assertIn("WHERE id = $1 AND status = 'executing'", query)

    async def test_claim_rejects_duplicate_confirmation(self) -> None:
        pool = SimpleNamespace(
            fetchrow=AsyncMock(
                side_effect=[
                    None,
                    {"status": "executing", "expires_at": datetime.now(timezone.utc)},
                ]
            )
        )
        repository = ProposalRepository(pool)

        with self.assertRaises(ProposalStateError) as caught:
            await repository.claim_for_execution("p-1", guild_id=1, user_id=2)

        self.assertEqual(caught.exception.code, "PROPOSAL_ALREADY_CLOSED")
        self.assertEqual(pool.fetchrow.await_count, 2)


class SchemaVerificationTests(unittest.IsolatedAsyncioTestCase):
    async def test_guild_settings_columns_are_checked_in_one_exhaustive_query(self) -> None:
        class Connection:
            def __init__(self):
                self.queries = []

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, traceback):
                return False

            async def execute(self, query):
                self.queries.append(query)

        connection = Connection()
        pool = SimpleNamespace(acquire=lambda: connection)
        await verify_schema(pool)

        settings_queries = [
            query for query in connection.queries if "FROM guild_settings" in query
        ]
        self.assertEqual(len(settings_queries), 1)
        identity_queries = [
            query for query in connection.queries if "FROM project_identity" in query
        ]
        self.assertEqual(len(identity_queries), 1)
        for column in ("project_id", "owner", "creator", "attribution", "copyright", "created_at"):
            self.assertIn(column, identity_queries[0])
        for column in (
            "retention_days",
            "excluded_channel_ids",
            "rules_channel_id",
            "logs_channel_id",
            "staff_channel_id",
            "context_message_limit",
            "rules_message_limit",
            "staff_message_limit",
            "auto_execute_low_risk_actions",
            "updated_at",
        ):
            self.assertIn(column, settings_queries[0])


class ContextRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_search_is_bounded_and_guild_scoped(self) -> None:
        pool = SimpleNamespace(
            fetch=AsyncMock(return_value=[
                {"message_id": "9", "content": "example evidence"}
            ])
        )
        repository = ContextRepository(pool)

        results = await repository.search_messages(
            123, "example evidence", limit=500, channel_ids=[10, 11]
        )

        self.assertEqual(len(results), 1)
        args = pool.fetch.await_args.args
        self.assertEqual(args[1], "123")
        self.assertEqual(args[2], "example evidence")
        self.assertEqual(args[3], ["10", "11"])
        self.assertEqual(args[4], 50)

    async def test_empty_search_terms_do_not_query_database(self) -> None:
        pool = SimpleNamespace(fetch=AsyncMock())
        repository = ContextRepository(pool)

        result = await repository.search_messages(123, "!!!")

        self.assertEqual(result, [])
        pool.fetch.assert_not_awaited()

    async def test_retention_prune_uses_a_bounded_batch(self) -> None:
        pool = SimpleNamespace(execute=AsyncMock(return_value="DELETE 7"))
        repository = ContextRepository(pool)

        removed = await repository.prune_expired(batch_size=100_000)

        self.assertEqual(removed, 7)
        self.assertEqual(pool.execute.await_args.args[1], 5000)



class GuildSettingsRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_database_settings_override_local_cache_on_startup(self) -> None:
        pool = SimpleNamespace(
            fetch=AsyncMock(return_value=[{
                "guild_id": "123",
                "rules_channel_id": "10",
                "logs_channel_id": None,
                "staff_channel_id": "11",
                "context_message_limit": 12,
                "rules_message_limit": 5,
                "staff_message_limit": 2,
                "auto_execute_low_risk_actions": ["rename_server"],
            }])
        )
        store = ConfigStore(guilds={"123": GuildConfig(context_message_limit=3)})
        await GuildSettingsRepository(pool).load_into(store)
        self.assertEqual(store.get(123).context_message_limit, 12)
        self.assertEqual(store.get(123).rules_channel_id, 10)
        self.assertEqual(store.get(123).auto_execute_low_risk_actions, ["rename_server"])

    async def test_settings_upsert_persists_low_risk_allowlist(self) -> None:
        pool = SimpleNamespace(execute=AsyncMock(return_value="INSERT 0 1"))
        config = GuildConfig(
            rules_channel_id=10,
            auto_execute_low_risk_actions=["rename_server"],
        )
        await GuildSettingsRepository(pool).upsert(123, config)
        self.assertIn("ON CONFLICT (guild_id) DO UPDATE", pool.execute.await_args.args[0])
        self.assertEqual(pool.execute.await_args.args[1], "123")
        self.assertEqual(pool.execute.await_args.args[8], '["rename_server"]')


class ModerationCaseRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_case_upsert_is_idempotent(self) -> None:
        pool = SimpleNamespace(execute=AsyncMock(return_value="INSERT 0 1"))
        case = ModerationCase(
            case_id=4,
            guild_id=123,
            moderator_id=10,
            target_id=20,
            action="warn",
            reason="Test",
            rule_reference=None,
            evidence_message_ids=[99],
            proposed_at=datetime.now(timezone.utc).isoformat(),
        )
        await ModerationCaseRepository(pool).upsert(case)
        self.assertIn("ON CONFLICT (guild_id, case_id) DO UPDATE", pool.execute.await_args.args[0])
        self.assertEqual(pool.execute.await_args.args[1:5], ("123", 4, "10", "20"))

    async def test_database_cases_merge_with_legacy_json_cases(self) -> None:
        now = datetime.now(timezone.utc)
        pool = SimpleNamespace(fetch=AsyncMock(return_value=[{
            "guild_id": "123",
            "case_id": 5,
            "moderator_id": "10",
            "target_id": "20",
            "action": "ban",
            "reason": "Imported",
            "rule_reference": None,
            "evidence_message_ids": [99],
            "proposed_at": now,
            "status": "completed",
            "confirmed_at": now,
            "closed_at": None,
            "outcome": "Completed",
            "duration_minutes": None,
        }]))
        store = CaseStore(cases=[
            ModerationCase(
                case_id=4, guild_id=123, moderator_id=10, target_id=21,
                action="warn", reason=None, rule_reference=None,
                evidence_message_ids=[], proposed_at=now.isoformat(),
            )
        ])
        await ModerationCaseRepository(pool).load_into(store)
        self.assertEqual({case.case_id for case in store.cases}, {4, 5})


if __name__ == "__main__":
    unittest.main()
