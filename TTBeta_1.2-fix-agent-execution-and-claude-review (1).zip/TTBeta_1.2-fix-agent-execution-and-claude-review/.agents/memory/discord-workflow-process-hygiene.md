---
name: Discord workflow process hygiene
description: Workflow restart behavior for the long-running Discord gateway process.
---

After changing the bot's model or runtime configuration, verify that exactly one
Discord bot process is running before testing. A stale process can survive a
restart and create duplicate replies, making old configuration errors appear to
be current.

**Why:** Multiple gateway clients can respond to the same Discord message, and
their replies may reflect different code or model settings.

**How to apply:** Check the running process list after a bot restart; stop stale
copies, then start one clean workflow instance.