---
name: Groq free-tier output limits
description: Output-token constraints that affect the Groq model used by the Discord bot.
---

The bot's structured JSON response must set an explicit output-token cap below
the active organization free-tier limit. A request without a cap can default to
an output budget larger than the limit even when the expected response is short.

**Why:** Groq rejected an otherwise valid multimodal moderation request when its
implicit 2048-token budget exceeded the organization's 1000-token output limit.

**How to apply:** Keep moderation JSON concise and set `max_tokens` below the
current free-tier ceiling; treat any future model or tier change as a reason to
recheck this setting.