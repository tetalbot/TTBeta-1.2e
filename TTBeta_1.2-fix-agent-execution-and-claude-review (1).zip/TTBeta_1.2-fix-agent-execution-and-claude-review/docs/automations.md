# Event-driven automations

TetalBot supports approved, server-scoped event automations. A Manage Server moderator drafts a rule in natural language, reviews the generated trigger/conditions/actions, and explicitly approves it before it becomes active.

## Commands

- `/automation create description:<request>`: ask Gemini to draft a rule. Nothing is saved until the moderator presses **Approve and enable**.
- `/automation list`: list this server's rules and run counts.
- `/automation disable rule_id:<id>`: disable a rule without deleting its history.
- `/automation logs rule_id:<id>`: show the latest ten executions.

The full rule ID is shown after creation and in the list.

## Supported triggers

- `member_join`: a member joins.
- `member_leave`: a member leaves.
- `message_contains`: a human member posts a message.
- `reaction_add`: a human member adds a reaction.
- `voice_join`: a member joins or switches into a voice channel.
- `role_assign` / `role_remove`: a member gains or loses a role.

Conditions are deterministic: bot-account flag, minimum account age, channel, literal message substring, reaction emoji, voice channel, or role ID. Rules can also apply conditions to individual actions, so one join workflow can welcome every new member but assign a role only when `is_bot=false`. Message matching is a literal case-insensitive substring, not arbitrary regular-expression execution.

## Supported actions

For safety, event automations currently support only:
- Assign a role to the member who triggered the event.
- Remove a role from the member who triggered the event.
- Send a message to a configured text channel. A single mention of the triggering member is allowed when the message template includes `$event.member_mention` and the member is still in the server; leave-event messages do not ping departed members.

Ban, kick, timeout, bulk deletion, channel locking, DMs, arbitrary code, and arbitrary member targeting are not available in event automations. Role-change triggers can send messages but cannot assign/remove roles, preventing recursive role automation loops. The existing moderation tools can still be used interactively through the normal confirmation flow.

## Execution safeguards

- Approval of the draft is explicit authorization for the displayed workflow.
- Actions are still validated against the registered tool catalog.
- The rule creator must remain in the server and retain Manage Server permission.
- The creator's required Discord permissions, the bot's permissions, and role hierarchy are checked again on every execution. Managed roles, @everyone, and roles granting privileged server permissions cannot be used.
- If permission checks fail, execution is skipped or failed and recorded.
- Actions run sequentially. The first failed action stops the remaining sequence; the history records completed actions and the failure.
- Event keys are stored with a uniqueness constraint to suppress duplicate processing of the same event, including when two bot instances receive the same Discord event.
- Completed execution logs are pruned daily using the server's configured retention period.
- Optional AI reasoning is off by default. When enabled, Gemini evaluates the event and fails closed if the model errors or is uncertain.
- Discord's `member.bot` flag only identifies accounts Discord marks as bots. It does not perform CAPTCHA or prove that a person is human.

Enable the Server Members Intent in the Discord Developer Portal for member join/leave events. The bot already requests member, reaction, and voice-state intents in code; the Members intent must also be enabled for the application.

## Database setup

This feature adds migration `0007_automations.sql`. Before deploying this branch, back up the PostgreSQL database and apply the new migration using the existing runner:

```sh
uv run python scripts/apply_migrations.py
uv run python scripts/apply_migrations.py --apply
```

The runner is dry-run by default. The `--apply` command asks for the literal confirmation `APPLY`. Apply it to the intended database before starting the updated bot, because startup schema verification now requires the automation tables.
