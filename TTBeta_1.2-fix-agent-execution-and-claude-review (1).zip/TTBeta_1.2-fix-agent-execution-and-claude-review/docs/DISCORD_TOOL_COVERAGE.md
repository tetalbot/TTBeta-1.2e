# Discord tool coverage and permission notes

The agent exposes only tools registered in Python. Model output is never executed as code.

## Read-only tools
- `list_roles`: reads the server role list.
- `get_server_overview`: reads basic guild metadata and counts.
- `list_channels`: returns only channels both the requester and bot can view.
- `search_recent_messages`: searches a bounded recent window (up to 24 hours, 20 channels, 50 messages per channel, 40 results) and skips channels unless both requester and bot have View Channel and Read Message History.
- `search_stored_messages`: searches retained PostgreSQL message context, restricted to channels where both requester and bot have View Channel and Read Message History. Results are untrusted evidence.
- `list_active_threads`: lists cached active threads visible to both requester and bot; archived threads are not guaranteed.
- `list_server_assets`: lists server emojis and stickers.
- `get_ai_usage`: returns aggregate Gemini token counts for the server over a bounded period; requires Manage Server.
- `get_bot_diagnostics`: returns non-secret gateway, database, and repository readiness diagnostics; requires Manage Server.
- `list_audit_log`: reads the latest 20 audit entries and requires View Audit Log for both requester and bot.
- `list_invites`: lists server invites and requires Manage Server for both requester and bot.
- `list_webhooks`: lists webhooks only in channels where both requester and bot have Manage Webhooks.
- `list_automod_rules`: lists AutoMod rule metadata and keyword filters; requires Manage Server for both requester and bot.
- `list_server_assets`: lists server emojis and stickers.
- `inspect_link`: inspects public HTTP(S) pages with DNS-level SSRF checks, no redirects, and response limits.

## Server configuration and context privacy\n- `/guild_settings`: configure system/rules/updates channels, server description, default notifications, and explicit-media filtering. Requires Manage Server.\n- `/context_settings`: configure per-server message retention and channel indexing exclusions. Requires Manage Server.\n- `/context_backfill`: explicitly index one selected text channel, bounded to 90 days and 5000 messages per invocation; requester and bot must both have View Channel and Read Message History. No historical backfill runs automatically.\n\n## Existing moderation and configuration actions
Existing action handlers remain in `bot/commands/` and are exposed through `bot/tools/moderation.py`. Their required permissions are declared in `REQUIRED_PERMISSIONS`; execution also performs target hierarchy and resource checks. Destructive and structural operations remain confirmation-gated unless an explicitly allow-listed low-risk action is enabled in that guild's configuration.

## Confirmed structural operations
- Thread/forum: create a public thread, create a forum post, archive/unarchive a thread, and lock/unlock a thread. Requires Manage Threads in the relevant parent/thread context.
- Scheduled events: create, edit, and delete external scheduled events. Requires Manage Events. Start/end values must be ISO-8601 timestamps with an explicit timezone; event creation must be in the future.
- Invites: create and revoke server invites. Creation checks Create Invite for both requester and bot in the selected channel; revocation requires Manage Server.
- Webhooks: create, rename, and delete webhooks. Each operation checks Manage Webhooks for both requester and bot in the target channel.
- AutoMod: create, edit, and delete keyword-based message-send rules. Requires Manage Server for both requester and bot. Existing non-keyword rules cannot be edited through this interface.
- These operations are high-risk and always use the persistent confirmation workflow.

## Persistent investigation commands
- `/investigation create`: open a server-scoped investigation (Manage Messages).
- `/investigation list`: list recent investigations (Manage Messages).
- `/investigation add-message`: attach a message after checking that the requester and bot can read its channel history.
- `/investigation add-url`: safely inspect a public URL and attach a bounded excerpt.
- `/investigation add-audit-entry`: attach one of the latest 100 audit-log entries after checking View Audit Log for both requester and bot.
- `/investigation show`: view the investigation and its bounded evidence list.
- `/investigation close`: close it with a summary.
- `/investigation add-url`: inspect a public URL with DNS-level SSRF defenses and attach a bounded excerpt as untrusted evidence.

## Not yet exposed
Some advanced Discord settings and unsupported API operations remain unavailable; supported server settings are documented above. Do not infer support from Discord.py having an API method.

## Unsupported by design
Voice participation, voice monitoring, recording, speech recognition, and voice moderation are out of scope. Arbitrary Python, SQL, shell execution, and unrestricted HTTP fetching are prohibited.

## Permission principle
The bot filters read results using the requester's and bot's effective channel permissions. Every modifying operation must recheck the requester, bot, hierarchy, target guild, and resource permissions at execution time.
