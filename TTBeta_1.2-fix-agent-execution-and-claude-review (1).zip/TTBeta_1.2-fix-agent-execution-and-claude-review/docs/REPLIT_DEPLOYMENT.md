# Replit deployment notes

TetalBot is a long-running Discord Gateway client. It must keep a persistent
outbound connection to Discord and run one bot process per bot token.

## Current repository configuration

The Replit **Discord Bot** workflow runs:

```sh
uv run python -m scripts.replit_start
```

The small bootstrap selects `NEON_DATABASE_URL` when present and exposes it
to the existing application as `DATABASE_URL` before importing the protected
bot runtime. This avoids silently connecting to Replit's attached PostgreSQL
when a Neon URL has been explicitly configured.

The application does not apply SQL migrations automatically at startup.
Database migration remains an explicit operator action.

## Required secrets

Configure these in Replit Secrets:

- `DISCORD_BOT_TOKEN`
- `GEMINI_API_KEY`
- `NEON_DATABASE_URL` (recommended; use the Neon direct PostgreSQL URL)

The bootstrap prefers `NEON_DATABASE_URL`. If it is absent, it falls back to
`DATABASE_URL` for existing deployments. Do not put credentials in source
code, commits, or logs.

`PICATIC_API_KEY` and `SESSION_SECRET` are not required by the current
Discord bot runtime.

## Database rollout

The repository includes migrations `0000` through `0006`.

The migration wrapper uses the same Neon-first URL selection as bot startup.
Run a dry run first:

```sh
uv run python -m scripts.neon_migrations
```

After confirming the output identifies the intended Neon database and
reviewing the pending migrations, apply them explicitly:

```sh
uv run python -m scripts.neon_migrations --apply
```

The runner requires typing `APPLY`, uses a PostgreSQL advisory lock, and
validates migration checksums. Use the Neon **direct** connection URL for
migrations, not the pooled URL. Back up the database first. Do not reset the
database or run the legacy SQLite/JSON importer unless explicitly required.

## S3 storage

The current bot stores attachment metadata and source links, not attachment
bytes. There is no S3 upload/download path in the current runtime, so Neon S3
credentials are not needed for current bot startup. Do not claim S3 is
configured until an actual object-storage feature is implemented and tested.

## Deployment target

The current deployment target is Autoscale. Autoscale is not appropriate for
a permanently connected Discord Gateway process. For always-on production
operation, use a persistent Replit deployment/runtime such as a Reserved VM,
if available. The workspace run workflow can be used for immediate testing.

## Operational safeguards

- Run only one bot process per bot token.
- Keep confirmation-gated moderation operations enabled.
- Back up the database before migrations.
- Test in a development Discord server before production use.
