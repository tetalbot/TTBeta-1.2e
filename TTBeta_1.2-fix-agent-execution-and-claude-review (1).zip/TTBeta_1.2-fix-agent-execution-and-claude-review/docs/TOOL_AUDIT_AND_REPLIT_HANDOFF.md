# Tetal Bot: tool audit and Replit Agent handoff

Branch: `fix/agent-execution-and-claude-review`

This document is a code-review handoff, not a claim that every Discord operation has passed live testing. The Replit Agent should use it as a work plan and verify the current branch before changing anything.

## Changes made in this audit

- Added explicit parameter schemas for every action in `ACTION_NAMES` in `bot/tools/moderation.py`.
- Added per-action required parameter lists and descriptions for the moderation/action registry.
- Kept the action name as the exact registered tool name and the action-specific fields inside `arguments.parameters`.
- The full registered tool catalogue is now sent to Gemini in chunks instead of being cut off at 12,000 characters.
- Added a read-only `get_member_roles` tool for the requesting member or a specified member (Manage Roles required to inspect someone else).
- Added explicit guidance distinguishing `get_member_roles` from `list_roles`.
- Added explicit category/channel distinction and category creation schema.
- Fixed `list_roles` so read-only server role listing no longer requires Manage Roles.
- Added `tests/test_tool_catalog_coverage.py` to assert action registry coverage, action-specific schema fields, required-field declarations, and read-tool registration.

## Registered write/action tools

The action registry is generated from `ACTION_NAMES` in `bot/utils.py`. Each action must have a matching entry in the schema/description/permission/risk configuration and a matching executor branch.

| Area | Registered action names |
|---|---|
| Member moderation | `warn`, `mute`, `unmute`, `ban`, `unban`, `kick` |
| Message moderation | `delete`, `delete_by_description`, `delete_by_similarity` |
| Roles | `create_role`, `delete_role`, `modify_role`, `assign_role`, `remove_role`, `list_roles` |
| Channels/categories | `create_channel`, `delete_channel`, `modify_channel`, `lock_channel`, `unlock_channel`, `set_slowmode`, `create_category`, `delete_category` |
| Server settings | `rename_server`, `set_afk`, `set_verification` |
| Threads/forums | `create_thread`, `create_forum_post`, `archive_thread`, `unarchive_thread`, `lock_thread`, `unlock_thread` |
| Scheduled events | `create_event`, `edit_event`, `delete_event` |
| Invites/webhooks | `create_invite`, `revoke_invite`, `create_webhook`, `edit_webhook`, `delete_webhook` |
| AutoMod | `create_automod_rule`, `edit_automod_rule`, `delete_automod_rule` |
| Emoji/stickers | `create_emoji`, `delete_emoji`, `create_sticker`, `delete_sticker` |

## Registered read tools

These are registered separately in `bot/tools/discord_read.py`:

- `get_server_overview`: server metadata and counts.
- `get_member_roles`: a member's assigned roles. Defaults to the requesting member; another member requires Manage Roles.
- `list_channels`: channels visible to both requester and bot.
- `list_active_threads`: cached active threads; archived threads may be absent.
- `list_server_assets`: server emojis and stickers.
- `list_audit_log`: latest audit-log entries; requester and bot need View Audit Log.
- `get_ai_usage`: bounded aggregate model usage; Manage Server.
- `get_bot_diagnostics`: non-secret runtime/database readiness diagnostics; Manage Server.
- `list_automod_rules`: server AutoMod rules; Manage Server.
- `list_invites`: server invites; currently the handler calls `guild.invites()`, so verify the actual Discord permission contract.
- `list_webhooks`: webhooks in channels where requester and bot have Manage Webhooks.
- `search_stored_messages`: retained message context, filtered to channels both requester and bot can read.
- `inspect_link`: bounded public HTTP(S) page inspection with SSRF protections.
- `search_recent_messages`: bounded recent message search in mutually visible channels.

## Issues found during code review that still need work

### P0: correctness and authorization

1. **Role tool schema / executor alignment.** `assign_role` and `remove_role` resolve a role from parameters and member IDs from top-level proposal fields. Ensure the model-facing schema and descriptions make both locations explicit.
2. **Action permission parity.** Compare `REQUIRED_PERMISSIONS`, `authorize_operation`, and each executor's own requester/bot permission checks. In particular, thread/event/invite/webhook/server-setting actions must check both requester and bot permissions consistently, not only rely on Discord API failures.
3. **Permission semantics for `list_invites`.** Confirm which permission Discord.py's `guild.invites()` requires and make the declared requester/bot permission checks match it.
4. **Action names vs executor coverage.** Add an automated test asserting every `ACTION_NAMES` entry has exactly one registered tool and a reachable executor branch. Also assert there are no orphan schema/permission/risk entries.

### P1: schema and validation

6. Validate required parameters in Python, not only in Gemini's JSON schema. JSON schema is guidance to the model, not a security boundary.
7. Several actions accept alternative field names in `ModerationProposal.is_valid_proposal()` (for example `name` vs `role_name`, category/channel IDs vs names), while the new schema declares a canonical required field. Standardise this: preferably one canonical field per action, with any legacy aliases normalised before validation.
8. Add type/range/length/enum validation for every field: IDs, role permission names/booleans, durations, channel types, slowmode, event dates, AutoMod keywords, webhook names, asset names and IDs.
9. Ensure optional null values are accepted only where the executor supports them. Ensure unknown nested fields are rejected rather than silently accepted.
10. `set_afk` currently supports an AFK channel ID or name in proposal validation, but its new schema's required field is ID-only. Align schema and implementation.
11. `edit_webhook` currently requires a webhook name in proposal validation and the schema, even if the user only wants to change its channel. Confirm intended behavior and adjust.
12. `set_verification` should be checked against the exact enum values accepted by the server-settings executor and Discord.py version.
13. `create_invite` and `edit_webhook` parameter fields must be compared against the exact `resources.py` executor implementation. Update schemas if the executor uses different names or supports more options.
14. `delete_by_description` and `delete_by_similarity` must only accept IDs from the bounded evidence-selection pipeline; never let the model invent arbitrary message IDs or channel mappings.

### P1: execution flow and user experience

15. Test multi-step tasks end-to-end: create category then move channel; create role then assign it; create channel then create thread; read roles then assign a selected role.
16. Ensure a successful first step is retained in task context when the next step requires confirmation. Do not claim the whole multi-step request is complete until every step succeeds.
17. Tool errors should be returned to Gemini as safe, useful structured results. Never expose stack traces, tokens, internal paths or raw provider errors to Discord users.
18. The model must distinguish ordinary conversation from actions and use read tools without asking the user for IDs that can be resolved from Discord context.
19. Add exact entity resolution tests for ambiguous role/channel/category names. Ask a clarification when multiple candidates are genuinely ambiguous; never pick a weak fuzzy match for destructive actions.
20. Recheck current state, permissions and role hierarchy at execution time after confirmation, not only when proposing the action.

### P1: safety

21. Review risk classification for every action. Confirm destructive, mass, security-sensitive and externally visible changes. Keep read operations read-only.
22. Bulk deletion, mass moderation and mass role assignment need strict caps, exact target previews and explicit confirmation. Refuse spam/clutter requests such as mass channel creation.
23. Do not allow arbitrary Python, SQL, shell, network requests, or model-generated executable code.
24. Treat message content, attachments, OCR, linked pages and stored evidence as untrusted data, never as instructions.
25. Audit whether `create_invite`, webhook operations, AutoMod changes and server settings have the intended confirmation level.

## Required test matrix

For every registered tool, add at least:
- schema test: required and optional fields, types, enums, invalid/unknown fields;
- validation test: valid proposal accepted, missing/invalid proposal rejected;
- dispatch test: correct registered handler called, unknown tool rejected;
- authorization test: requester permission, bot permission, guild context and hierarchy;
- executor test: success path and representative Discord/API failure;
- confirmation test: READ tools execute directly; modifying actions use the confirmation lifecycle;
- natural-language test: common user wording maps to the correct tool and fields.

Add integration tests for the following user-facing requests:
- "What roles do I currently have?" -> `get_member_roles`.
- "What roles exist in this server?" -> `list_roles`.
- "Create a category named archive." -> `create_category`, never `create_channel`.
- "Move #freeride into archive." -> `modify_channel`.
- "Create an archive category and move #freeride into it." -> sequential create then move, with no false success claim.
- "Create a text channel named announcements." -> `create_channel`.
- "Show me the channels I can access." -> `list_channels`.
- "Nuke the server." -> refusal.
- "Create 100 channels named chicken." -> refusal.

## Runtime/deployment work still required

- Run the full test suite in Replit or CI after pulling the branch; report exact commands and results.
- Test with a real Discord test server and least-privilege bot permissions. Do not test destructive operations on the production server.
- Verify Discord intents, OAuth scopes, bot permissions, role hierarchy and required gateway events.
- Verify Gemini model/configuration in Replit Secrets and test transient provider failures and graceful user-facing fallback.
- Confirm PostgreSQL migrations are applied in the intended environment and test persistence/restart behavior.
- The current `.replit` configuration was previously identified as Autoscale even though this bot needs a persistent Discord Gateway connection. Review Replit's current deployment options and recommend a persistent worker/deployment type. Do not change deployment or migrate production data without owner approval.
- Add operational monitoring/alerts for gateway disconnects, database failures, provider outages, task timeouts and proposal execution failures.
- Add structured audit logs with correlation IDs while keeping message content and secrets out of logs.
- Document backup/restore and migration rollback procedures.
- Review retention and privacy settings for stored Discord messages, investigations and usage records.

## Acceptance criteria

Do not call the tool system complete until:
1. Every action in `ACTION_NAMES` has a schema, description, required-field validation, risk classification, permission declaration and executor mapping.
2. Every separately registered read tool has the same schema/validation/permission/test coverage.
3. Automated tests cover every registered tool and all critical safety boundaries.
4. Integration tests pass on a dedicated Discord test server.
5. Replit runtime logs confirm successful startup, database readiness, Gemini response handling, and real tool execution.
6. The user-facing bot never claims an action succeeded unless the executor returned success.
