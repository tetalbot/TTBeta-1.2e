"""Generate the authoritative runtime capability reference from live registries."""

from __future__ import annotations

import inspect
import logging
from pathlib import Path
from typing import Any

from .agent.orchestrator import AgentOrchestrator
from .automations.engine import (
    AUTOMATION_ACTION_ALLOWLIST,
    AUTOMATION_ACTION_BANLIST,
    SUPPORTED_TRIGGER_EVENTS,
    TRIGGER_CONDITIONS,
)
from .automations.intents import AUTOMATION_INTENT_PATTERNS
from .database.automations import AutomationRepository
from .database.context import ContextRepository
from .database.conversations import ConversationRepository
from .database.investigations import InvestigationRepository
from .database.proposals import ProposalRepository
from .database.settings import GuildSettingsRepository, ModerationCaseRepository
from .database.usage import UsageRepository
from .tools.diagnostics import build_diagnostics_registry
from .tools.moderation import build_moderation_registry
from .tools.discord_read import register_read_tools
from .agent.discord_api import operation_catalog_text
from .tools.registry import ToolRegistry

LOGGER = logging.getLogger("ai-moderator.capabilities")

REPOSITORIES = (
    AutomationRepository,
    ContextRepository,
    ConversationRepository,
    InvestigationRepository,
    ProposalRepository,
    GuildSettingsRepository,
    ModerationCaseRepository,
    UsageRepository,
)


async def _unused_executor(context: Any, proposal: Any) -> None:
    raise RuntimeError("The capability generator never executes tools.")


def _build_registry() -> ToolRegistry:
    registry = build_moderation_registry(_unused_executor)
    diagnostics = build_diagnostics_registry()
    for name in diagnostics.names():
        registry.register(diagnostics.get(name))
    register_read_tools(registry)
    return registry


def _render_tool(tool: dict[str, Any]) -> list[str]:
    schema = tool.get("parameters") or {}
    properties = schema.get("properties") or {}
    action_schema = properties.get("parameters") or {}
    action_properties = action_schema.get("properties") or {}
    required = set(action_schema.get("required") or ())
    lines = [
        f"### {tool['name']}",
        f"- Description: {tool.get('description') or 'No description registered.'}",
        f"- Risk: {tool.get('risk_level') or 'UNKNOWN'}",
        f"- Required Discord permissions: {', '.join(tool.get('required_permissions') or ()) or 'None declared'}",
        f"- Automation eligible: {'yes' if tool.get('automation_eligible') is True else 'no'}",
    ]
    fields = []
    for name, definition in sorted(action_properties.items()):
        field_type = definition.get("type", "any")
        detail = f"{name} ({field_type})"
        if name in required:
            detail += " [required]"
        if definition.get("enum"):
            detail += "; allowed: " + ", ".join(map(str, definition["enum"]))
        if definition.get("description"):
            detail += "; " + str(definition["description"])
        fields.append(detail)
    lines.append("- Action parameters: " + ("; ".join(fields) if fields else "No action-specific fields"))
    lines.append("- Required top-level fields: " + (", ".join(schema.get("required") or ()) or "None declared"))
    return lines


def _render_repository(repository: type) -> list[str]:
    lines = [f"### {repository.__name__}"]
    methods = []
    for name, member in inspect.getmembers(repository, predicate=callable):
        if name.startswith("_"):
            continue
        try:
            signature = inspect.signature(member)
            parameters = list(signature.parameters.values())
            if parameters and parameters[0].name == "self":
                signature = signature.replace(parameters=parameters[1:])
        except (TypeError, ValueError):
            signature = "(...)"
        description = inspect.getdoc(member) or "No method documentation."
        description = " ".join(description.split())
        methods.append(f"- {name}{signature}: {description}")
    lines.extend(methods or ["- No public operations found."])
    return lines


def render_agent_capabilities() -> str:
    """Build Markdown from the same registries and policy constants used at runtime."""
    registry = _build_registry()
    tools = registry.schemas()
    lines = [
        "# TetalBot Agent Capabilities",
        "",
        "> Generated from the live Python registries and automation policy. Do not edit by hand.",
        "",
        "## Authority and routing",
        "",
        "This document describes code that is currently registered. The runtime tool catalog and Python authorization/validation remain authoritative; this reference does not grant permissions or bypass confirmation.",
        "",
        "## Platform capability versus TetalBot implementation",
        "",
        "The registered tools are the safe operations TetalBot currently implements. They are not an exhaustive list of Discord API capabilities. Absence from this catalogue means TetalBot has not exposed that operation here; it does not prove Discord cannot perform it.",
        "",
        "Never report a Discord API limitation solely because a tool is missing. Report an implementation gap as a TetalBot limitation. Report a permission failure only when runtime authorization identifies the missing permission. Only report a platform limitation when supported by explicit trusted API documentation.",
        "",
        "The agent may compose registered operations and use read-only tools to inspect live state. It may not invent tool names, dynamically execute Python/shell/code, or invoke arbitrary Discord endpoints. The generic discord_api operation discovers coroutine methods from the installed discord.py resource classes and validates arguments, permissions, risk and confirmation centrally. New Discord.py methods can become available through discovery without adding another natural-language command or bespoke handler.",
        "",
        "### Natural-language automation routing",
        "",
        "A staff message is routed to the persistent automation draft flow when it contains any of these case-insensitive substrings:",
        "",
    ]
    lines.extend(f"- {pattern!r}" for pattern in AUTOMATION_INTENT_PATTERNS)
    lines.extend([
        "",
        "The routing check is substring-based. A request that uses none of these phrases will not enter the dedicated automation-creation flow.",
        "",
        operation_catalog_text(),
        "",
        "## Registered tools",
        "",
        f"Total registered tools: {len(tools)}.",
        "",
    ])
    for tool in tools:
        lines.extend(_render_tool(tool))
        lines.append("")
    lines.extend([
        "## Event-driven automations",
        "",
        "### Supported trigger event identifiers",
        "",
    ])
    for trigger in sorted(SUPPORTED_TRIGGER_EVENTS):
        conditions = TRIGGER_CONDITIONS.get(trigger, ())
        lines.append(f"- {trigger}: conditions accepted by validation: {', '.join(sorted(conditions)) or 'none'}")
    lines.extend([
        "",
        "### Automation action policy",
        "",
        "Explicit automation allowlist:",
        "",
    ])
    lines.extend(f"- {name}" for name in sorted(AUTOMATION_ACTION_ALLOWLIST))
    lines.extend(["", "Explicit permanent banlist:", ""])
    lines.extend(f"- {name}" for name in sorted(AUTOMATION_ACTION_BANLIST))
    lines.extend([
        "",
        "Only actions both present in the allowlist and marked automation-eligible in the registered tool definition may be stored. Runtime validation applies additional trigger-specific constraints, event-bound targets, and permission checks.",
        "",
        "### Creation and approval flow",
        "",
        "1. The message router detects one of the automation intent substrings.",
        "2. The bot checks that the requester has Manage Server and that persistent automation storage is available.",
        "3. Gemini drafts a rule using the supported trigger identifiers and automation-eligible registered tools.",
        "4. validate_automation_definition validates the trigger, conditions, action sequence, target placeholders, allowlist, and tool eligibility.",
        "5. The bot displays a preview using AutomationRuleConfirmationView.",
        "6. Only the initiating moderator with Manage Server can choose Approve and enable. Approval persists the rule through AutomationRepository.create. Cancel saves nothing.",
        "7. Approved rules are dispatched by matching event listeners and checked again for conditions, permissions, and safe execution at runtime.",
        "",
        "A generated draft is not an active rule. No automation is enabled until the approval interaction succeeds.",
        "",
        "### Unsupported automation capabilities",
        "",
        "- Trigger events not listed above are unsupported.",
        "- Actions outside the explicit allowlist or not marked automation-eligible are unsupported.",
        "- Ban, unban, and kick are permanently excluded from event automation and require manual staff confirmation.",
        "- Arbitrary code execution, arbitrary tool names, and arbitrary external integrations are not automation actions.",
        "- The event system is event-driven; this registry does not define cron jobs or arbitrary scheduled timers.",
        "",
        "## Persistent database repositories",
        "",
        "The following public repository methods are discovered from the repository classes imported by the bot:",
        "",
    ])
    for repository in REPOSITORIES:
        lines.extend(_render_repository(repository))
        lines.append("")
    lines.extend([
        "## Safety and interpretation",
        "",
        "- This reference is descriptive, not an execution interface.",
        "- Tool permission requirements, argument validation, authorization, risk classification, and confirmation checks are enforced in Python.",
        "- A model response cannot create a tool, permission, trigger, database operation, or automation action that is absent from the live code.",
        "- If a requested capability is absent from this document and the live registry, state that it is unsupported instead of inventing a dashboard, control panel, command, or workaround.",
        "",
    ])
    return "\n".join(lines)


def generate_agent_capabilities(output_path: str | Path | None = None) -> str:
    """Write the generated reference and return its exact contents for prompt injection."""
    content = render_agent_capabilities()
    destination = Path(output_path) if output_path else Path(__file__).resolve().parents[1] / "AGENT_CAPABILITIES.md"
    try:
        destination.write_text(content, encoding="utf-8")
        LOGGER.info("Generated agent capability reference at %s", destination)
    except OSError:
        LOGGER.exception("Could not write generated capability reference to %s", destination)
    return content
