"""Registered action definitions for the bot's existing moderation tools."""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from ..ai import ModerationProposal
from ..security.risk_policy import classify_action_risk
from ..utils import ACTION_NAMES
from .registry import RiskLevel, ToolDefinition, ToolRegistry


RegisteredExecutor = Callable[[Any, ModerationProposal], Awaitable[Any]]

AUTOMATION_ELIGIBLE_ACTIONS = {
    "assign_role",
    "remove_role",
    "send_message",
    "warn",
    "mute",
    "delete",
}

HIGH_RISK_ACTIONS = {
    "ban",
    "kick",
    "delete",
    "delete_by_description",
    "delete_by_similarity",
    "delete_role",
    "delete_channel",
    "delete_category",
    "lock_channel",
    "set_verification",
}

REQUIRED_PERMISSIONS = {
    "warn": ("moderate_members",),
    "mute": ("moderate_members",),
    "unmute": ("moderate_members",),
    "ban": ("ban_members",),
    "unban": ("ban_members",),
    "kick": ("kick_members",),
    "delete": ("manage_messages",),
    "delete_by_description": ("manage_messages",),
    "delete_by_similarity": ("manage_messages",),
    "create_role": ("manage_roles",),
    "delete_role": ("manage_roles",),
    "modify_role": ("manage_roles",),
    "assign_role": ("manage_roles",),
    "remove_role": ("manage_roles",),
    "list_roles": (),
    "remove_automation": ("manage_guild",),
    "create_channel": ("manage_channels",),
    "delete_channel": ("manage_channels",),
    "modify_channel": ("manage_channels",),
    "lock_channel": ("manage_channels",),
    "unlock_channel": ("manage_channels",),
    "set_slowmode": ("manage_channels",),
    "create_category": ("manage_channels",),
    "delete_category": ("manage_channels",),
    "rename_server": ("manage_guild",),
    "set_afk": ("manage_guild",),
    "set_verification": ("manage_guild",),
    "create_thread": ("manage_threads",),
    "create_forum_post": ("manage_threads",),
    "archive_thread": ("manage_threads",),
    "unarchive_thread": ("manage_threads",),
    "lock_thread": ("manage_threads",),
    "unlock_thread": ("manage_threads",),
    "create_event": ("manage_events",),
    "edit_event": ("manage_events",),
    "delete_event": ("manage_events",),
    "create_invite": ("create_instant_invite",),
    "revoke_invite": ("manage_guild",),
    "create_webhook": ("manage_webhooks",),
    "edit_webhook": ("manage_webhooks",),
    "delete_webhook": ("manage_webhooks",),
    "create_automod_rule": ("manage_guild",),
    "edit_automod_rule": ("manage_guild",),
    "delete_automod_rule": ("manage_guild",),
    "create_emoji": ("manage_emojis_and_stickers",),
    "delete_emoji": ("manage_emojis_and_stickers",),
    "create_sticker": ("manage_emojis_and_stickers",),
    "delete_sticker": ("manage_emojis_and_stickers",),
    # Sending is a normal Discord capability; the bot's channel/DM API call
    # enforces its own permissions. The action remains HIGH risk and requires
    # explicit moderator confirmation because it sends externally visible content.
    "send_message": (),
    "discord_api": (),
}

ACTION_PARAMETER_FIELDS: dict[str, dict[str, dict[str, Any]]] = {
    # Roles
    "create_role": {"role_name": {"type": "string"}, "color": {"type": "string"}, "permissions": {"type": "object"}},
    "delete_role": {"role_id": {"type": ["string", "integer"]}, "role_name": {"type": "string"}},
    "modify_role": {"role_id": {"type": ["string", "integer"]}, "role_name": {"type": "string"}, "name": {"type": "string"}, "role_name_new": {"type": "string"}, "color": {"type": "string"}, "colour": {"type": "string"}, "permissions": {"type": "object"}},
    "assign_role": {"role_id": {"type": ["string", "integer"]}, "role_name": {"type": "string"}},
    "remove_role": {"role_id": {"type": ["string", "integer"]}, "role_name": {"type": "string"}},
    "remove_automation": {
        "rule_id": {"type": "string", "description": "Exact UUID of the TetalBot automation rule to disable."},
        "rule_name": {"type": "string", "description": "Automation name when its UUID is not known. Resolve against this server's enabled TetalBot automation rules."},
    },
    # Channels and categories
    "create_category": {"category_name": {"type": "string", "description": "Name of the Discord category container."}},
    "delete_category": {"category_id": {"type": ["string", "integer"]}, "category_name": {"type": "string"}},
    "create_channel": {"channel_name": {"type": "string", "description": "Name of a text, voice, or forum channel, never a category."}, "name": {"type": "string"}, "channel_type": {"type": "string", "enum": ["text", "voice", "forum"]}, "category_id": {"type": ["string", "integer"]}, "category_name": {"type": "string"}, "topic": {"type": ["string", "null"]}},
    "delete_channel": {"channel_id": {"type": ["string", "integer"]}, "channel_name": {"type": "string"}},
    "modify_channel": {"channel_id": {"type": ["string", "integer"]}, "channel_name": {"type": "string"}, "name": {"type": "string"}, "topic": {"type": ["string", "null"]}, "category_id": {"type": ["string", "integer"]}, "category_name": {"type": "string"}, "sync_permissions": {"type": "boolean", "description": "Synchronise this channel's permission overwrites with its actual parent category. Requires a category and explicit confirmation."}},
    "lock_channel": {"channel_id": {"type": ["string", "integer"]}, "channel_name": {"type": "string"}},
    "unlock_channel": {"channel_id": {"type": ["string", "integer"]}, "channel_name": {"type": "string"}},
    "set_slowmode": {"channel_id": {"type": ["string", "integer"]}, "channel_name": {"type": "string"}, "slowmode_seconds": {"type": "integer", "minimum": 0, "maximum": 21600}},
    # Server configuration
    "rename_server": {"server_name": {"type": "string"}, "name": {"type": "string"}},
    "set_afk": {"afk_channel_id": {"type": ["string", "integer"]}, "afk_channel_name": {"type": "string"}, "afk_timeout": {"type": "integer"}},
    "set_verification": {"verification_level": {"type": "string", "enum": ["none", "low", "medium", "high", "highest"]}},
    # Threads and forums
    "create_thread": {"channel_id": {"type": ["string", "integer"]}, "thread_name": {"type": "string"}, "message_id": {"type": ["string", "integer"]}, "auto_archive_duration": {"type": "integer", "enum": [60, 1440, 4320, 10080]}},
    "create_forum_post": {"channel_id": {"type": ["string", "integer"]}, "thread_name": {"type": "string"}, "content": {"type": "string"}},
    "archive_thread": {"thread_id": {"type": ["string", "integer"]}},
    "unarchive_thread": {"thread_id": {"type": ["string", "integer"]}},
    "lock_thread": {"thread_id": {"type": ["string", "integer"]}},
    "unlock_thread": {"thread_id": {"type": ["string", "integer"]}},
    # Scheduled events
    "create_event": {"event_name": {"type": "string"}, "location": {"type": "string"}, "description": {"type": "string"}, "start_time": {"type": "string", "description": "ISO-8601 datetime with timezone offset."}, "end_time": {"type": "string", "description": "ISO-8601 datetime with timezone offset."}},
    "edit_event": {"event_id": {"type": ["string", "integer"]}, "event_name": {"type": "string"}, "location": {"type": "string"}, "description": {"type": "string"}, "start_time": {"type": "string"}, "end_time": {"type": "string"}},
    "delete_event": {"event_id": {"type": ["string", "integer"]}},
    # Invites and webhooks
    "create_invite": {"channel_id": {"type": ["string", "integer"]}, "max_age": {"type": "integer"}, "max_uses": {"type": "integer"}, "temporary": {"type": "boolean"}, "unique": {"type": "boolean"}},
    "revoke_invite": {"invite_code": {"type": "string"}},
    "create_webhook": {"channel_id": {"type": ["string", "integer"]}, "webhook_name": {"type": "string"}},
    "edit_webhook": {"webhook_id": {"type": ["string", "integer"]}, "webhook_name": {"type": "string"}, "channel_id": {"type": ["string", "integer"]}},
    "delete_webhook": {"webhook_id": {"type": ["string", "integer"]}},
    # AutoMod
    "create_automod_rule": {"rule_name": {"type": "string"}, "keywords": {"type": ["array", "string"], "items": {"type": "string"}}, "custom_message": {"type": "string"}, "enabled": {"type": "boolean"}},
    "edit_automod_rule": {"rule_id": {"type": ["string", "integer"]}, "rule_name": {"type": "string"}, "keywords": {"type": ["array", "string"], "items": {"type": "string"}}, "custom_message": {"type": "string"}, "enabled": {"type": "boolean"}},
    "delete_automod_rule": {"rule_id": {"type": ["string", "integer"]}},
    # Emoji and stickers. These refer to an existing Discord message attachment.
    "create_emoji": {"channel_id": {"type": ["string", "integer"]}, "message_id": {"type": ["string", "integer"]}, "attachment_id": {"type": ["string", "integer"]}, "asset_name": {"type": "string"}},
    "delete_emoji": {"asset_id": {"type": ["string", "integer"]}},
    "create_sticker": {"channel_id": {"type": ["string", "integer"]}, "message_id": {"type": ["string", "integer"]}, "attachment_id": {"type": ["string", "integer"]}, "asset_name": {"type": "string"}, "description": {"type": "string"}, "emoji": {"type": "string"}},
    "delete_sticker": {"asset_id": {"type": ["string", "integer"]}},
    # Message cleanup. Evidence IDs and channel mapping are supplied by the search/selection flow.
    "delete_by_description": {"description": {"type": "string"}, "message_ids": {"type": "array", "items": {"type": ["string", "integer"]}}, "message_channels": {"type": "object"}},
    "delete_by_similarity": {"example_message_id": {"type": ["string", "integer"]}, "message_ids": {"type": "array", "items": {"type": ["string", "integer"]}}, "message_channels": {"type": "object"}},
    "send_message": {
        "destination": {"type": "string", "enum": ["channel", "dm"]},
        "channel_id": {"type": ["string", "integer"]},
        "channel_name": {"type": "string"},
        "target_user_id": {"type": ["string", "integer"]},
        "mention_user_id": {"type": ["string", "integer"]},
        "content": {"type": "string", "minLength": 1, "maxLength": 2000},
    },
    "discord_api": {
        "resource_type": {"type": "string", "enum": ["guild", "channel", "category", "role", "member", "thread", "message"]},
        "resource_id": {"type": ["string", "integer"], "description": "Target message ID when resource_type=message; otherwise the Discord resource ID."},
        "resource_name": {"type": "string"},
        "channel_id": {"type": ["string", "integer"], "description": "Required with resource_type=message to identify the message's channel."},
        "method": {"type": "string", "description": "Exact coroutine method from the live Discord API operation catalogue injected into the agent context."},
        "arguments": {"type": "object", "description": "Named JSON arguments matching the discovered method signature. Resource arguments use member_id, user_id, role_id, channel_id or target_id as appropriate."},
    },
}

ACTION_REQUIRED_PARAMETERS: dict[str, list[str]] = {
    "discord_api": ["resource_type", "method"],
    "create_role": ["role_name"],
    "delete_role": ["role_id"],
    "modify_role": ["role_id"],
    "assign_role": ["role_name"],
    "remove_role": ["role_name"],
    "create_category": ["category_name"],
    "delete_category": ["category_name"],
    "create_channel": ["channel_name"],
    "delete_channel": ["channel_name"],
    "modify_channel": ["channel_name"],
    "lock_channel": ["channel_name"],
    "unlock_channel": ["channel_name"],
    "set_slowmode": ["channel_name", "slowmode_seconds"],
    "rename_server": ["server_name"],
    "set_afk": ["afk_channel_id"],
    "set_verification": ["verification_level"],
    "create_thread": ["thread_name"],
    "create_forum_post": ["channel_id", "thread_name", "content"],
    "archive_thread": ["thread_id"],
    "unarchive_thread": ["thread_id"],
    "lock_thread": ["thread_id"],
    "unlock_thread": ["thread_id"],
    "create_event": ["event_name", "start_time", "end_time", "location"],
    "edit_event": ["event_id"],
    "delete_event": ["event_id"],
    "create_invite": ["channel_id"],
    "revoke_invite": ["invite_code"],
    "create_webhook": ["channel_id", "webhook_name"],
    "edit_webhook": ["webhook_id", "webhook_name"],
    "delete_webhook": ["webhook_id"],
    "create_automod_rule": ["rule_name", "keywords"],
    "edit_automod_rule": ["rule_id"],
    "delete_automod_rule": ["rule_id"],
    "create_emoji": ["channel_id", "message_id", "attachment_id", "asset_name"],
    "delete_emoji": ["asset_id"],
    "create_sticker": ["channel_id", "message_id", "attachment_id", "asset_name", "description"],
    "delete_sticker": ["asset_id"],
    "delete_by_description": ["description"],
    "delete_by_similarity": ["example_message_id"],
    "send_message": ["destination", "content"],
}

ACTION_DESCRIPTIONS = {
    "warn": "Warn one or more server members. Requires target_user_id or target_user_ids; include reason when available.",
    "mute": "Timeout one or more server members. Requires target_user_id or target_user_ids; duration_minutes is optional for the maximum timeout.",
    "unmute": "Remove a timeout from one or more server members. Requires target_user_id or target_user_ids.",
    "ban": "Ban one or more server members. Requires target_user_id or target_user_ids. Confirmation required.",
    "unban": "Unban a user by ID. Requires target_user_id or target_user_ids.",
    "kick": "Kick one or more server members. Requires target_user_id or target_user_ids. Confirmation required.",
    "delete": "Delete the explicitly identified evidence message(s). Supply evidence_message_ids or parameters.message_ids. Confirmation required.",
    "delete_by_description": "Find and delete messages matching the supplied description only after a bounded evidence-selection step and confirmation.",
    "delete_by_similarity": "Find and delete messages similar to the supplied example_message_id only after showing the exact selected messages and confirmation.",
    "create_role": "Create a server role. Required parameters.role_name. Optional color and permissions object.",
    "delete_role": "Delete an existing role by role_id or role_name. Confirmation required.",
    "modify_role": "Modify an existing role selected by role_id or role_name. Optional name, color, or permissions.",
    "assign_role": "Assign an existing role to target_user_id or target_user_ids. Requires role_name or role_id and target member IDs.",
    "remove_role": "Remove an existing role from target_user_id or target_user_ids. Requires role_name or role_id and target member IDs.",
    "list_roles": "Read-only list of all custom server roles and their IDs. No parameters required.",
    "remove_automation": "Disable one enabled TetalBot event-automation rule in this server. Supply exactly one of parameters.rule_id (the UUID from list_automations) or parameters.rule_name (resolved with ambiguity-safe fuzzy matching). Requires Manage Server and explicit confirmation. This does not affect Discord AutoMod rules.",
    "rename_server": "Change the server name. Required parameters.server_name.",
    "set_afk": "Set the server AFK voice channel. Required parameters.afk_channel_id or afk_channel_name.",
    "set_verification": "Change the server verification level. Required parameters.verification_level.",
    "create_thread": "Create a public thread in a text channel. Required thread_name; channel_id defaults to the current channel.",
    "create_forum_post": "Create a forum post. Requires channel_id, thread_name and content.",
    "archive_thread": "Archive an existing thread by thread_id.",
    "unarchive_thread": "Unarchive an existing thread by thread_id.",
    "lock_thread": "Lock an existing thread by thread_id.",
    "unlock_thread": "Unlock an existing thread by thread_id.",
    "create_event": "Create a future external scheduled event. Requires event_name, timezone-aware start_time/end_time and location.",
    "edit_event": "Edit a scheduled event by event_id. Supply at least one field to change.",
    "delete_event": "Delete a scheduled event by event_id. Confirmation required.",
    "create_invite": "Create an invite for channel_id with optional expiry/use limits.",
    "revoke_invite": "Revoke an invite by invite_code. Confirmation required.",
    "create_webhook": "Create a webhook in channel_id with webhook_name.",
    "edit_webhook": "Edit a webhook by webhook_id; webhook_name is currently required by the executor.",
    "delete_webhook": "Delete a webhook by webhook_id. Confirmation required.",
    "create_automod_rule": "Create a keyword AutoMod rule with rule_name and keywords.",
    "edit_automod_rule": "Edit a keyword AutoMod rule by rule_id. Supply at least one field to change.",
    "delete_automod_rule": "Delete an AutoMod rule by rule_id. Confirmation required.",
    "create_emoji": "Create a custom emoji from an existing image attachment identified by channel_id, message_id and attachment_id, plus asset_name.",
    "delete_emoji": "Delete a custom emoji by asset_id. Confirmation required.",
    "create_sticker": "Create a PNG sticker from an existing image attachment. Requires channel_id, message_id, attachment_id, asset_name and description.",
    "delete_sticker": "Delete a sticker by asset_id. Confirmation required.",
    "send_message": (
        "Send a custom message to a text channel in this server or as a direct message "
        "to a member of this server. Use destination='channel' with channel_id or "
        "channel_name, or destination='dm' with target_user_id, and provide content. "
        "The exact destination and message require moderator confirmation before sending."
    ),
}

PARAMETER_SCHEMA = {
    "type": "object",
    "properties": {
        "status": {"type": "string", "enum": ["proposal"]},
        "question": {"type": ["string", "null"]},
        "action": {"type": "string"},
        "target_user_id": {"type": ["string", "integer", "null"]},
        "target_user_name": {"type": ["string", "null"]},
        "target_user_names": {"type": "array", "items": {"type": "string"}},
        "target_user_ids": {
            "type": "array",
            "items": {"type": ["string", "integer"]},
        },
        "duration_minutes": {"type": ["integer", "null"]},
        "reason": {"type": ["string", "null"]},
        "rule_reference": {"type": ["string", "null"]},
        "evidence_message_ids": {
            "type": "array",
            "items": {"type": ["string", "integer"]},
        },
        "parameters": {"type": "object"},
        "preview_items": {"type": "array", "items": {"type": "string"}},
        "summary": {"type": "string"},
        "continue_after_confirmation": {"type": "boolean"},
        "continuation_depth": {"type": "integer", "minimum": 0, "maximum": 5},
    },
    "required": ["status", "action"],
    "additionalProperties": False,
}


def _risk_level(action: str) -> RiskLevel:
    risk = classify_action_risk(action)
    return risk if risk in {"READ", "LOW", "HIGH"} else "HIGH"


def build_moderation_registry(executor: RegisteredExecutor) -> ToolRegistry:
    registry = ToolRegistry()
    descriptions = {
        "create_category": (
            "Create a Discord CATEGORY (the grouping container shown above channels), "
            "not a text, voice, or forum channel. Use this action whenever the user says "
            "create/add/make a category or category section. Discord defaults are automatic. "
            "Required: parameters.category_name."
        ),
        "create_channel": (
            "Create a Discord TEXT, VOICE, or FORUM CHANNEL. This does NOT create a category. "
            "Never use this action when the user asks for a category. "
            "Required: parameters.channel_name; optional parameters.channel_type."
        ),
        "list_roles": (
            "READ-ONLY: List every custom role in this Discord server, including each role's "
            "name and ID. Use this whenever the user asks what roles exist, what roles are "
            "available, or asks to see/list the server's roles. No role ID or name is needed."
        ),
        "modify_channel": (
            "Edit or MOVE an existing Discord channel, including synchronising its permission "
            "overwrites with its actual parent category. Use parameters.sync_permissions=true "
            "when staff say sync/match/inherit the channel permissions from its category. "
            "If moving and syncing in one operation, provide category_name and sync_permissions=true. "
            "If already in a category, channel_name plus sync_permissions=true is sufficient. "
            "This changes access control and always requires explicit confirmation. "
            "Do not claim Discord lacks this API capability."
        ),
    }
    for action in sorted(ACTION_NAMES):
        async def handler(context: Any, arguments: dict[str, Any]) -> Any:
            proposal = ModerationProposal.from_payload(arguments)
            return await executor(context, proposal)

        def validate(arguments: dict[str, Any], expected: str = action) -> str | None:
            if arguments.get("action") != expected:
                return "The action name does not match the registered operation."
            proposal = ModerationProposal.from_payload(arguments)
            if expected == "remove_automation":
                has_id = bool(str(proposal.parameters.get("rule_id") or "").strip())
                has_name = bool(str(proposal.parameters.get("rule_name") or "").strip())
                if has_id == has_name:
                    return "Provide exactly one of parameters.rule_id or parameters.rule_name."
            if expected == "discord_api":
                resource_type = str(proposal.parameters.get("resource_type") or "").strip().lower()
                method_name = str(proposal.parameters.get("method") or "").strip()
                arguments = proposal.parameters.get("arguments", {})
                if resource_type not in {"guild", "channel", "category", "role", "member", "thread", "message"}:
                    return "The generic Discord operation needs a supported resource_type."
                if not method_name or method_name.startswith("_"):
                    return "The generic Discord operation needs a public method name."
                if not isinstance(arguments, dict):
                    return "Generic Discord operation arguments must be an object."
                return None
            if not proposal.is_valid_proposal():
                return "The proposal is missing required or valid arguments."
            return None

        schema = {
            **PARAMETER_SCHEMA,
            "properties": {
                **PARAMETER_SCHEMA["properties"],
                "action": {"type": "string", "enum": [action]},
                "parameters": {
                    "type": "object",
                    "properties": ACTION_PARAMETER_FIELDS.get(action, {}),
                    "additionalProperties": not bool(ACTION_PARAMETER_FIELDS.get(action, {})),
                    **(
                        {"required": ACTION_REQUIRED_PARAMETERS[action]}
                        if action in ACTION_REQUIRED_PARAMETERS
                        else {}
                    ),
                },
            },
        }
        registry.register(
            ToolDefinition(
                name=action,
                description=descriptions.get(
                    action,
                    ACTION_DESCRIPTIONS.get(
                        action,
                        f"Validated Discord operation: {action.replace('_', ' ')}. "
                        "Use only the registered fields in this tool's schema."
                    ),
                ),
                parameters=schema,
                risk_level=_risk_level(action),
                required_permissions=REQUIRED_PERMISSIONS.get(action, ()),
                validate_arguments=validate,
                handler=handler,
                automation_eligible=action in AUTOMATION_ELIGIBLE_ACTIONS,
            )
        )
    return registry
