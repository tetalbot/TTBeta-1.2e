"""Typed registry for supported Discord actions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Literal


RiskLevel = Literal["READ", "LOW", "HIGH"]
ArgumentValidator = Callable[[dict[str, Any]], str | None]
ToolHandler = Callable[[Any, dict[str, Any]], Awaitable[Any]]


class UnknownToolError(KeyError):
    pass


@dataclass(frozen=True)
class ToolDefinition:
    name: str
    description: str
    parameters: dict[str, Any]
    risk_level: RiskLevel
    required_permissions: tuple[str, ...]
    validate_arguments: ArgumentValidator
    handler: ToolHandler
    automation_eligible: bool = False


class ToolRegistry:
    def __init__(self) -> None:
        self._definitions: dict[str, ToolDefinition] = {}

    def register(self, definition: ToolDefinition) -> None:
        if not definition.name or definition.name in self._definitions:
            raise ValueError(f"Tool name is empty or already registered: {definition.name}")
        self._definitions[definition.name] = definition

    def get(self, name: str) -> ToolDefinition:
        try:
            return self._definitions[name]
        except KeyError as exc:
            raise UnknownToolError(name) from exc

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._definitions))

    def schemas(self) -> list[dict[str, Any]]:
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
                "risk_level": tool.risk_level,
                "required_permissions": list(tool.required_permissions),
                "automation_eligible": tool.automation_eligible,
            }
            for tool in sorted(self._definitions.values(), key=lambda item: item.name)
        ]

    def automation_schemas(self) -> list[dict[str, Any]]:
        """Return only tools explicitly approved for use in stored automations."""
        return [
            schema
            for schema in self.schemas()
            if schema.get("automation_eligible") is True
        ]
