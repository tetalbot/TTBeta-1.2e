"""Argument validation, registered handler execution, and result normalization."""

from __future__ import annotations

import logging
import uuid
import discord
from dataclasses import asdict, dataclass, field
from typing import Any

from .registry import ToolRegistry, UnknownToolError
from ..ai import ModerationProposal
from ..security.authorization import authorize_operation
from ..security.risk_policy import classify_action_risk
from ..entity_resolution import resolve_tool_entities


LOGGER = logging.getLogger("ai-moderator.tools")


@dataclass
class ToolResult:
    success: bool
    tool: str
    data: Any = None
    error: dict[str, str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


async def dispatch_tool(
    registry: ToolRegistry,
    name: str,
    arguments: dict[str, Any],
    context: Any,
    *,
    guild_id: int | None = None,
) -> ToolResult:
    execution_id = str(uuid.uuid4())
    metadata = {
        "guild_id": str(guild_id) if guild_id is not None else None,
        "execution_id": execution_id,
    }
    try:
        tool = registry.get(name)
    except UnknownToolError:
        return ToolResult(
            False,
            name,
            error={"code": "UNKNOWN_TOOL", "message": "This operation is not registered."},
            metadata=metadata,
        )

    if not isinstance(arguments, dict):
        return ToolResult(
            False,
            name,
            error={"code": "INVALID_ARGUMENTS", "message": "Arguments must be an object."},
            metadata=metadata,
        )
    guild = getattr(context, "guild", None)
    if guild is None or (guild_id is not None and getattr(guild, "id", None) != guild_id):
        # Return useful schema errors even when the caller omitted its guild context.
        # A well-formed request still receives the authorization error below.
        validation_error = tool.validate_arguments(arguments)
        if validation_error:
            return ToolResult(
                False, name,
                error={"code": "INVALID_ARGUMENTS", "message": validation_error},
                metadata=metadata,
            )
        return ToolResult(
            False, name,
            error={"code": "AUTHORIZATION_DENIED", "message": "A matching server context is required."},
            metadata=metadata,
        )

    # Accept the generic user_name alias, then resolve all supplied names against
    # this guild before schema validation, authorization, or handler execution.
    if arguments.get("user_name") and not arguments.get("target_user_name"):
        arguments["target_user_name"] = arguments.pop("user_name")
    resolution_error = resolve_tool_entities(guild, arguments)
    if resolution_error:
        code = (
            "ENTITY_AMBIGUOUS"
            if "several similar matches" in resolution_error
            else "ENTITY_NOT_FOUND"
        )
        return ToolResult(
            False, name,
            error={"code": code, "message": resolution_error},
            metadata=metadata,
        )

    validation_error = tool.validate_arguments(arguments)
    if validation_error:
        return ToolResult(
            False,
            name,
            error={"code": "INVALID_ARGUMENTS", "message": validation_error},
            metadata=metadata,
        )

    proposal = ModerationProposal.from_payload(arguments)
    requester = getattr(context, "requester", None)
    bot_member = getattr(context, "bot_member", None) or getattr(guild, "me", None)
    source_message = getattr(context, "source_message", None)
    decision = authorize_operation(
        guild=guild,
        requester=requester,
        bot_member=bot_member,
        tool=tool,
        proposal=proposal,
        channel=getattr(source_message, "channel", None),
    )
    if not decision.allowed:
        return ToolResult(
            False, name,
            error={"code": "AUTHORIZATION_DENIED", "message": decision.message},
            metadata=metadata,
        )
    if classify_action_risk(proposal.action, proposal) != "READ":
        return ToolResult(
            False, name,
            error={
                "code": "CONFIRMATION_REQUIRED",
                "message": "Modifying operations must use the persistent confirmation workflow.",
            },
            metadata=metadata,
        )

    try:
        data = await tool.handler(context, arguments)
        return ToolResult(True, name, data=data, metadata=metadata)
    except Exception as exc:
        LOGGER.exception("Registered tool %s failed (execution %s)", name, execution_id)
        if isinstance(exc, discord.Forbidden):
            message = "Discord denied this operation. Check the bot and moderator permissions and role hierarchy."
            code = "DISCORD_FORBIDDEN"
        elif isinstance(exc, discord.NotFound):
            message = "The Discord resource no longer exists or could not be found. Refresh the server state and resolve it again."
            code = "DISCORD_NOT_FOUND"
        elif isinstance(exc, discord.HTTPException):
            message = f"Discord API request failed (HTTP {exc.status}, error code {exc.code})."
            code = "DISCORD_API_ERROR"
        elif isinstance(exc, (ValueError, TypeError, KeyError)):
            detail = " ".join(str(exc).split())[:300]
            message = f"Invalid operation or arguments: {detail or type(exc).__name__}"
            code = "INVALID_OPERATION"
        else:
            message = f"Operation failed with {type(exc).__name__}. Check the audit log for details."
            code = "TOOL_EXECUTION_FAILED"
        return ToolResult(
            False,
            name,
            error={"code": code, "message": message},
            metadata=metadata,
        )
