"""Owner-only live source and console diagnostics tools."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..diagnostics.log_buffer import get_tail
from ..security.authorization import is_owner
from .registry import ToolDefinition, ToolRegistry

PROJECT_ROOT = Path(__file__).resolve().parents[2]

# The owner can inspect any UTF-8 text file in the project, including hidden
# config and build/output folders. Keep secrets and dependency/cache internals
# out of model context.
BLOCKED_DIRECTORIES = frozenset({
    ".git", ".secrets", ".ssh", ".aws", ".azure", ".kube", ".venv", "venv", "env",
    "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".tox", "site-packages",
})

BLOCKED_FILENAMES = frozenset({
    "ownership_public_key.py", "ownership_manifest.json",
    "credentials.json", "service-account.json", "token.json",
    "secrets.json", "id_rsa", "id_ed25519",
    ".npmrc", ".pypirc", ".netrc", ".git-credentials",
    "kubeconfig", ".dockerconfigjson",
})

BLOCKED_SUFFIXES = frozenset({
    ".pem", ".key", ".p12", ".pfx", ".p7b", ".p7c", ".der",
    ".sqlite", ".sqlite3", ".db", ".dump", ".bak",
})


def _parameters(arguments: dict[str, Any]) -> dict[str, Any]:
    value = arguments.get("parameters")
    return value if isinstance(value, dict) else {}


def _validate_read_file_args(arguments: dict[str, Any]) -> str | None:
    if arguments.get("status") != "proposal" or arguments.get("action") != "read_file":
        return "The action must be read_file."
    path = _parameters(arguments).get("path")
    if not isinstance(path, str) or not path.strip():
        return "parameters.path is required and must be a non-empty string."
    if len(path) > 240:
        return "The requested path is too long."
    parameters = _parameters(arguments)
    start_line = parameters.get("start_line", 1)
    end_line = parameters.get("end_line")
    if type(start_line) is not int or start_line < 1:
        return "parameters.start_line must be a positive integer."
    if end_line is not None and (
        type(end_line) is not int or end_line < start_line
    ):
        return "parameters.end_line must be an integer greater than or equal to start_line."
    if end_line is not None and end_line - start_line + 1 > 400:
        return "A single read is limited to 400 lines."
    return None


def _validate_read_log_args(arguments: dict[str, Any]) -> str | None:
    if arguments.get("status") != "proposal" or arguments.get("action") != "read_log":
        return "The action must be read_log."
    lines = _parameters(arguments).get("lines", 100)
    if type(lines) is not int or not 1 <= lines <= 500:
        return "parameters.lines must be an integer between 1 and 500."
    return None


async def _handle_read_file(context: Any, arguments: dict[str, Any]) -> str:
    requester_id = getattr(getattr(context, "requester", None), "id", None)
    if not is_owner(requester_id):
        return "AUTHORIZATION_DENIED: This tool is restricted to the bot owner."

    requested = _parameters(arguments).get("path", "").strip().replace("\\", "/")
    if not requested or requested.startswith("/") or any(
        part in {"", ".", ".."} for part in requested.split("/")
    ):
        return "AUTHORIZATION_DENIED: Use a project-relative file path without traversal."

    target = (PROJECT_ROOT / requested).resolve()
    if target == PROJECT_ROOT or PROJECT_ROOT not in target.parents or not target.is_file():
        return "AUTHORIZATION_DENIED: The requested path is unavailable."

    relative = target.relative_to(PROJECT_ROOT)
    lowered_parts = tuple(part.lower() for part in relative.parts)
    filename = target.name.lower()
    suffix = target.suffix.lower()
    if (
        any(part in BLOCKED_DIRECTORIES for part in lowered_parts)
        or filename.startswith(".env")
        or filename in BLOCKED_FILENAMES
        or suffix in BLOCKED_SUFFIXES
        or any("secret" in part or "credential" in part for part in lowered_parts)
    ):
        return "AUTHORIZATION_DENIED: That path may contain secrets or private runtime data."

    # Read text only. Binary assets, executables and database files are not exposed.
    try:
        raw_content = target.read_bytes()
        if b"\x00" in raw_content:
            return "AUTHORIZATION_DENIED: Binary files cannot be read."
        file_text = raw_content.decode("utf-8")
    except (OSError, UnicodeDecodeError):
        return "The requested file is unavailable or is not readable UTF-8 text."

    file_lines = file_text.splitlines()

    parameters = _parameters(arguments)
    start_line = parameters.get("start_line", 1)
    end_line = parameters.get("end_line")
    if start_line > len(file_lines):
        return f"File {requested} has {len(file_lines)} lines; start_line is beyond the end."

    selected_end = min(end_line or start_line + 199, len(file_lines))
    selected = file_lines[start_line - 1:selected_end]
    content = "\n".join(
        f"{line_number}: {line}"
        for line_number, line in enumerate(selected, start=start_line)
    )
    max_chars = 12_000
    if len(content) > max_chars:
        content = content[:max_chars] + f"\n... [truncated at {max_chars} characters]"
    return (
        f"=== {requested} (lines {start_line}-{start_line + len(selected) - 1} "
        f"of {len(file_lines)}) ===\n{content}"
    )


async def _handle_read_log(context: Any, arguments: dict[str, Any]) -> str:
    requester_id = getattr(getattr(context, "requester", None), "id", None)
    if not is_owner(requester_id):
        return "AUTHORIZATION_DENIED: This tool is restricted to the bot owner."
    lines = _parameters(arguments).get("lines", 100)
    return get_tail(lines)


def build_diagnostics_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(ToolDefinition(
        name="read_file",
        description=(
            "Owner-only READ tool. Read any UTF-8 text file anywhere inside the project root, "
            "including hidden files, source, tests, configuration, documentation and build/output "
            "folders. Use the proposal envelope with action='read_file' and project-relative "
            "parameters.path. Optional start_line/end_line select a bounded section. "
            "Secrets, private keys, databases, binary files, dependency/cache folders and "
            "paths outside the project are blocked. Without a range it returns up to 200 lines."
        ),
        parameters={
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["proposal"]},
                "action": {"type": "string", "enum": ["read_file"]},
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "start_line": {"type": "integer", "minimum": 1},
                        "end_line": {"type": "integer", "minimum": 1},
                    },
                    "required": ["path"],
                    "additionalProperties": False,
                },
            },
            "required": ["status", "action", "parameters"],
            "additionalProperties": False,
        },
        risk_level="READ",
        required_permissions=(),
        validate_arguments=_validate_read_file_args,
        handler=_handle_read_file,
    ))
    registry.register(ToolDefinition(
        name="read_log",
        description=(
            "Owner-only READ tool. Read the last 1-500 lines from the in-memory "
            "console log buffer. Arguments use action='read_log' and "
            "parameters.lines (default 100)."
        ),
        parameters={
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["proposal"]},
                "action": {"type": "string", "enum": ["read_log"]},
                "parameters": {
                    "type": "object",
                    "properties": {"lines": {"type": "integer", "minimum": 1, "maximum": 500}},
                    "additionalProperties": False,
                },
            },
            "required": ["status", "action", "parameters"],
            "additionalProperties": False,
        },
        risk_level="READ",
        required_permissions=(),
        validate_arguments=_validate_read_log_args,
        handler=_handle_read_log,
    ))
    return registry
