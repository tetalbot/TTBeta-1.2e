"""Registered Discord tools and normalized dispatch."""
