"""Fuzzy, ambiguity-aware resolution of Discord entity names."""

from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from typing import Any, Callable, Iterable, TypeVar

T = TypeVar("T")


def _normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().strip()
    value = value.lstrip("#@")
    value = re.sub(r"[^\w]+", " ", value, flags=re.UNICODE)
    return " ".join(value.split())


def _similarity(query: str, candidate: str) -> float:
    left = _normalize(query)
    right = _normalize(candidate)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    compact_left, compact_right = left.replace(" ", ""), right.replace(" ", "")
    if compact_left == compact_right:
        return 0.99

    sequence = SequenceMatcher(None, left, right).ratio()
    token_left, token_right = set(left.split()), set(right.split())
    token_score = (
        2 * len(token_left & token_right) / (len(token_left) + len(token_right))
        if token_left and token_right
        else 0.0
    )
    if compact_left in compact_right or compact_right in compact_left:
        shorter, longer = sorted((len(compact_left), len(compact_right)))
        containment = 0.82 + 0.16 * shorter / longer
    else:
        containment = 0.0
    return max(sequence, token_score * 0.92, containment)


def resolve_named_entity(
    query: str,
    candidates: Iterable[T],
    *,
    name_of: Callable[[T], str],
    minimum_score: float = 0.60,
    ambiguity_margin: float = 0.07,
) -> T | None:
    """Return the closest strong match; refuse to guess between near-ties."""
    normalized_query = _normalize(str(query))
    if not normalized_query:
        return None

    candidate_items = list(candidates)
    exact_matches = [
        item for item in candidate_items
        if (
            _normalize(name_of(item)) == normalized_query
            or _normalize(name_of(item)).replace(" ", "") == normalized_query.replace(" ", "")
        )
    ]
    if len(exact_matches) == 1:
        return exact_matches[0]
    if len(exact_matches) > 1:
        names = [name_of(item) for item in exact_matches[:5]]
        raise ValueError(
            "I found several similar matches: "
            + ", ".join(f"**{name}**" for name in names)
            + ". Which one did you mean?"
        )

    ranked = sorted(
        ((_similarity(normalized_query, name_of(item)), item) for item in candidate_items),
        key=lambda entry: entry[0],
        reverse=True,
    )
    if not ranked or ranked[0][0] < minimum_score:
        return None

    best_score, best_item = ranked[0]
    close_matches = [
        item for score, item in ranked[1:]
        if best_score - score <= ambiguity_margin
    ]
    if close_matches:
        names = [name_of(best_item), *(name_of(item) for item in close_matches[:4])]
        raise ValueError(
            "I found several similar matches: "
            + ", ".join(f"**{name}**" for name in names)
            + ". Which one did you mean?"
        )
    return best_item


def resolve_tool_entities(guild: Any, arguments: dict[str, Any]) -> str | None:
    """Resolve human-readable Discord entity names before tool validation.

    The input is updated in place so the exact resolved IDs reach both the
    authorization layer and the eventual handler. Ambiguous or missing matches
    stop execution instead of silently selecting an unrelated entity.
    """
    if not isinstance(arguments, dict):
        return "Tool arguments must be an object."
    action = str(arguments.get("action") or "")
    params = arguments.get("parameters")
    if params is None:
        params = {}
    elif not isinstance(params, dict):
        return "Tool parameters must be an object."

    def resolve(
        field: str,
        id_field: str,
        candidates: Iterable[Any],
        *,
        label: str,
    ) -> str | None:
        query = params.get(field)
        if not isinstance(query, str) or not query.strip() or params.get(id_field):
            return None
        items = list(candidates)
        if not items:
            return (
                f"I couldn't find a {label} matching **{query}** in this server. "
                "Check the name or provide its ID."
            )
        if query.strip().isdigit():
            wanted = int(query.strip())
            match = next(
                (item for item in items if int(getattr(item, "id", 0)) == wanted),
                None,
            )
        else:
            try:
                match = resolve_named_entity(
                    query,
                    items,
                    name_of=lambda item: str(getattr(item, "name", "")),
                )
            except ValueError as exc:
                return str(exc)
        if match is None:
            return (
                f"I couldn't find a {label} matching **{query}** in this server. "
                "Check the name or provide its ID."
            )
        params[id_field] = str(match.id)
        return None

    role_actions = {"delete_role", "modify_role", "assign_role", "remove_role"}
    if action in role_actions:
        error = resolve("role_name", "role_id", getattr(guild, "roles", ()), label="role")
        if error:
            return error

    channel_actions = {
        "delete_channel", "modify_channel", "lock_channel",
        "unlock_channel", "set_slowmode",
    }
    if action in channel_actions or (
        action == "send_message" and params.get("destination") == "channel"
    ):
        error = resolve("channel_name", "channel_id", getattr(guild, "channels", ()), label="channel")
        if error:
            return error

    if action == "set_afk":
        error = resolve("afk_channel_name", "afk_channel_id", getattr(guild, "voice_channels", ()), label="voice channel")
        if error:
            return error

    member_actions = {
        "warn", "mute", "unmute", "ban", "unban", "kick",
        "assign_role", "remove_role",
    }
    if action in member_actions or (
        action == "send_message" and params.get("destination") == "dm"
    ):
        members = list(getattr(guild, "members", ()))
        single_name = arguments.pop("target_user_name", None)
        multiple_names = arguments.pop("target_user_names", None)
        if single_name and not arguments.get("target_user_id"):
            try:
                member = resolve_named_entity(
                    str(single_name), members,
                    name_of=lambda item: str(
                        getattr(item, "display_name", None)
                        or getattr(item, "global_name", None)
                        or getattr(item, "name", "")
                    ),
                )
            except ValueError as exc:
                return str(exc)
            if member is None:
                return (
                    f"I couldn't find a server member matching **{single_name}**. "
                    "Mention them or provide their ID."
                )
            arguments["target_user_id"] = str(member.id)
        if isinstance(multiple_names, list) and multiple_names and not arguments.get("target_user_ids"):
            resolved_ids: list[str] = []
            for name in multiple_names:
                try:
                    member = resolve_named_entity(
                        str(name), members,
                        name_of=lambda item: str(
                            getattr(item, "display_name", None)
                            or getattr(item, "global_name", None)
                            or getattr(item, "name", "")
                        ),
                    )
                except ValueError as exc:
                    return str(exc)
                if member is None:
                    return (
                        f"I couldn't find a server member matching **{name}**. "
                        "Mention them or provide their ID."
                    )
                resolved_ids.append(str(member.id))
            arguments["target_user_ids"] = list(dict.fromkeys(resolved_ids))
            if not arguments.get("target_user_id"):
                arguments["target_user_id"] = arguments["target_user_ids"][0]

    if params:
        arguments["parameters"] = params
    return None
