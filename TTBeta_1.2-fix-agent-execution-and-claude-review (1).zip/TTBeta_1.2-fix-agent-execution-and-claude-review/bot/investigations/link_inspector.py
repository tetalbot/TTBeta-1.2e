"""Isolated, bounded HTTP(S) link inspection with DNS-level SSRF defenses."""
from __future__ import annotations
import asyncio
import ipaddress
import re
import socket
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urlsplit, urlunsplit
import aiohttp

MAX_RESPONSE_BYTES = 512 * 1024
ALLOWED_PORTS = {80, 443}
ALLOWED_CONTENT_TYPES = {"text/html", "text/plain", "application/json"}

class UnsafeURL(ValueError):
    pass

def validate_url_syntax(url: str):
    if not isinstance(url, str) or len(url) > 2048:
        raise UnsafeURL("The URL is missing or too long.")
    parsed = urlsplit(url.strip())
    if parsed.scheme.lower() not in {"http", "https"}:
        raise UnsafeURL("Only HTTP and HTTPS links can be inspected.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise UnsafeURL("The URL must have a public hostname and no embedded credentials.")
    try:
        port = parsed.port or (443 if parsed.scheme.lower() == "https" else 80)
    except ValueError as exc:
        raise UnsafeURL("The URL contains an invalid port.") from exc
    if port not in ALLOWED_PORTS:
        raise UnsafeURL("Only standard HTTP and HTTPS ports are allowed.")
    host = parsed.hostname.rstrip(".").lower()
    if host in {"localhost", "metadata.google.internal"} or host.endswith((".localhost", ".local", ".internal", ".test", ".invalid")):
        raise UnsafeURL("Local and reserved hostnames cannot be inspected.")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise UnsafeURL("Private, local, and reserved IP addresses cannot be inspected.")
    return parsed, host, port

class _PublicResolver(aiohttp.abc.AbstractResolver):
    async def resolve(self, host: str, port: int = 0, family: int = 0):
        loop = asyncio.get_running_loop()
        records = await loop.getaddrinfo(host, port, family=family, type=socket.SOCK_STREAM)
        resolved = []
        for record_family, _, proto, _, sockaddr in records:
            address = ipaddress.ip_address(sockaddr[0])
            if not address.is_global:
                raise OSError("The hostname resolves to a non-public network address.")
            resolved.append({"hostname": host, "host": str(address), "port": port, "family": record_family, "proto": proto, "flags": 0})
        if not resolved:
            raise OSError("The hostname did not resolve to a public address.")
        return resolved
    async def close(self) -> None:
        return None

class _VisibleText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.title_parts: list[str] = []
        self._hidden = 0
        self._title = False
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self._hidden += 1
        if tag == "title":
            self._title = True
    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg"} and self._hidden:
            self._hidden -= 1
        if tag == "title":
            self._title = False
    def handle_data(self, data: str) -> None:
        if self._hidden:
            return
        cleaned = re.sub(r"\s+", " ", data).strip()
        if cleaned:
            self.parts.append(cleaned)
            if self._title:
                self.title_parts.append(cleaned)

def _redacted_url(url: str) -> str:
    parsed = urlsplit(url)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, "", ""))

async def inspect_public_url(url: str) -> dict[str, Any]:
    parsed, host, port = validate_url_syntax(url)
    connector = aiohttp.TCPConnector(resolver=_PublicResolver(), use_dns_cache=False, limit=2, ssl=True)
    timeout = aiohttp.ClientTimeout(total=10, connect=3, sock_read=5)
    async with aiohttp.ClientSession(connector=connector, timeout=timeout, trust_env=False, headers={"User-Agent": "TetalBot-LinkInspector/1.0"}) as session:
        async with session.get(parsed.geturl(), allow_redirects=False, max_redirects=0) as response:
            content_type = response.headers.get("Content-Type", "").split(";", 1)[0].lower()
            if response.status in {301, 302, 303, 307, 308}:
                return {"url": _redacted_url(parsed.geturl()), "status": response.status, "redirect": "Not followed. Redirect targets require a separate safety check."}
            if content_type not in ALLOWED_CONTENT_TYPES:
                return {"url": _redacted_url(parsed.geturl()), "status": response.status, "content_type": content_type or "unknown", "message": "This content type is not downloaded or parsed."}
            if response.content_length is not None and response.content_length > MAX_RESPONSE_BYTES:
                raise UnsafeURL("The response exceeds the 512 KB inspection limit.")
            body = bytearray()
            async for chunk in response.content.iter_chunked(16 * 1024):
                body.extend(chunk)
                if len(body) > MAX_RESPONSE_BYTES:
                    raise UnsafeURL("The response exceeds the 512 KB inspection limit.")
            text = body.decode(response.charset or "utf-8", errors="replace")
            parser = _VisibleText()
            if content_type == "text/html":
                parser.feed(text)
                title = " ".join(parser.title_parts)[:300]
                visible = " ".join(parser.parts)
            else:
                title, visible = "", text
            return {"url": _redacted_url(parsed.geturl()), "host": host, "port": port, "status": response.status, "content_type": content_type, "title": title, "text_excerpt": visible[:6000], "truncated": len(visible) > 6000, "untrusted_content": True}
