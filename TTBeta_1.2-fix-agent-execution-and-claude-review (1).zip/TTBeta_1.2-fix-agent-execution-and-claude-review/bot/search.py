"""Bounded cross-channel message search used by delete proposals."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

import discord


@dataclass
class MessageCandidate:
    message: discord.Message
    image_parts: list[dict[str, Any]] = field(default_factory=list)

    def as_text(self) -> str:
        image = " [image attachment]" if self.message.attachments else ""
        return (
            f"channel=#{getattr(self.message.channel, 'name', 'unknown')} "
            f"author={self.message.author.display_name} user_id={self.message.author.id} "
            f"message_id={self.message.id}: {self.message.content[:500] or '[no text]'}{image}"
        )


async def scan_guild_messages(
    guild: discord.Guild,
    *,
    minutes: int = 60,
    example: discord.Message | None = None,
    max_channels: int = 40,
    per_channel: int = 40,
    max_results: int = 160,
) -> list[MessageCandidate]:
    """Read a bounded recent window from accessible text channels."""
    cutoff = discord.utils.utcnow() - timedelta(minutes=max(1, min(minutes, 1440)))
    channels = list(guild.text_channels)[:max_channels]
    if example is not None and isinstance(example.channel, discord.TextChannel):
        channels = [example.channel] + [c for c in channels if c.id != example.channel.id]
    candidates: list[MessageCandidate] = []
    for channel in channels:
        try:
            async for message in channel.history(limit=per_channel, after=cutoff, oldest_first=False):
                if message.author.bot:
                    continue
                if example is not None and message.id == example.id:
                    continue
                candidates.append(MessageCandidate(message))
                if len(candidates) >= max_results:
                    return candidates
        except (discord.Forbidden, discord.HTTPException):
            continue
    return candidates