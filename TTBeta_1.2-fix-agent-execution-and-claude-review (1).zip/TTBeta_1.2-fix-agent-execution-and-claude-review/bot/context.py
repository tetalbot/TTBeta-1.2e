"""Collects bounded, fresh Discord context for each AI interaction."""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import Any

import discord

from .config import GuildConfig
from .utils import is_image_attachment, mention_members


@dataclass
class MessageContext:
    channel_name: str
    author: str
    author_id: int
    message_id: int
    content: str
    created_at: str
    referenced_message_id: int | None = None
    image_urls: list[str] = field(default_factory=list)

    def as_prompt_line(self) -> str:
        images = f" [images: {', '.join(self.image_urls)}]" if self.image_urls else ""
        reply = (
            f" [reply_to_message_id={self.referenced_message_id}]"
            if self.referenced_message_id
            else ""
        )
        return (
            f"[{self.created_at}] #{self.channel_name} "
            f"{self.author} (user_id={self.author_id}, message_id={self.message_id})"
            f"{reply}: {self.content or '[no text]'}{images}"
        )


@dataclass
class AIContext:
    current_request: str
    current_channel: str
    current_user: str
    current_user_id: int
    mentioned_members: str
    current_image_urls: list[str]
    recent_messages: list[MessageContext]
    rules_messages: list[MessageContext]
    staff_messages: list[MessageContext]
    configured_channels: dict[str, str]
    current_image_parts: list[dict[str, Any]] = field(default_factory=list)
    member_directory: str = ""
    current_guild_id: int | None = None

    def as_text(self) -> str:
        def block(title: str, messages: list[MessageContext]) -> str:
            if not messages:
                return f"{title}:\n[none available]"
            return f"{title}:\n" + "\n".join(
                f"- {message.as_prompt_line()}" for message in messages
            )

        channels = ", ".join(
            f"{key}=#{value}" for key, value in self.configured_channels.items()
        ) or "none"
        return "\n\n".join(
            [
                f"Current request: {self.current_request or '[empty]'}",
                f"Current channel: #{self.current_channel}",
                f"Current user: {self.current_user} (user_id={self.current_user_id})",
                f"Explicitly mentioned members: {self.mentioned_members or 'none'}",
                f"Server member directory: {self.member_directory or '[none available]'}",
                f"Configured context channels: {channels}",
                block("Recent messages in the current channel", self.recent_messages),
                block("Current rules channel messages", self.rules_messages),
                block("Current staff channel messages", self.staff_messages),
            ]
        )

    def image_urls(self) -> list[str]:
        urls = list(self.current_image_urls)
        for message in self.recent_messages + self.rules_messages + self.staff_messages:
            for url in message.image_urls:
                if url not in urls:
                    urls.append(url)
        return urls[:6]

    def image_parts(self) -> list[dict[str, Any]]:
        return list(self.current_image_parts)


async def read_channel_messages(
    channel: discord.TextChannel | discord.Thread,
    limit: int,
) -> list[MessageContext]:
    messages: list[MessageContext] = []
    async for message in channel.history(limit=limit, oldest_first=True):
        referenced_id = message.reference.message_id if message.reference else None
        image_urls = [
            attachment.url
            for attachment in message.attachments
            if is_image_attachment(attachment)
        ]
        messages.append(
            MessageContext(
                channel_name=channel.name,
                author=message.author.display_name,
                author_id=message.author.id,
                message_id=message.id,
                content=message.content,
                created_at=message.created_at.isoformat(),
                referenced_message_id=referenced_id,
                image_urls=image_urls,
            )
        )
    return messages


MAX_IMAGE_ATTACHMENTS = 2
MAX_IMAGE_BYTES = 4_000_000
MAX_TOTAL_IMAGE_BYTES = 8_000_000


async def collect_context(
    message: discord.Message,
    request: str,
    config: GuildConfig,
    cached_rules_messages: list[MessageContext] | None = None,
) -> AIContext:
    guild = message.guild
    if guild is None:
        raise ValueError("This bot only supports server messages.")

    recent_messages = await read_channel_messages(
        message.channel, config.context_message_limit
    )

    request_lower = request.lower()
    needs_rules = any(
        word in request_lower
        for word in ["rule", "rules", "policy", "reason", "broke", "violation"]
    ) or bool(message.mentions)
    needs_staff = "staff" in request_lower

    rules_messages: list[MessageContext] = list(cached_rules_messages or [])
    staff_messages: list[MessageContext] = []
    configured_channels: dict[str, str] = {}
    if rules_messages:
        configured_channels["rules"] = rules_messages[0].channel_name

    for key, channel_id, limit, needed in (
        ("staff", config.staff_channel_id, config.staff_message_limit, needs_staff),
    ):
        if not needed or not channel_id or limit == 0:
            continue
        channel = guild.get_channel(channel_id)
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            continue
        configured_channels[key] = channel.name
        msgs = await read_channel_messages(channel, limit)
        staff_messages = msgs

    image_attachments = [
        attachment for attachment in message.attachments
        if is_image_attachment(attachment)
    ][:MAX_IMAGE_ATTACHMENTS]
    current_images = [attachment.url for attachment in image_attachments]
    current_image_parts: list[dict[str, Any]] = []
    total_image_bytes = 0
    for attachment in image_attachments:
        if int(getattr(attachment, "size", 0)) > MAX_IMAGE_BYTES:
            continue
        try:
            data = await attachment.read()
        except (discord.HTTPException, discord.Forbidden):
            continue
        if len(data) > MAX_IMAGE_BYTES or total_image_bytes + len(data) > MAX_TOTAL_IMAGE_BYTES:
            continue
        total_image_bytes += len(data)
        current_image_parts.append(
            {
                "mime_type": attachment.content_type or "application/octet-stream",
                "data": base64.b64encode(data).decode("ascii"),
            }
        )
    human_mentions = [
        member
        for member in message.mentions
        if guild.me is None or member.id != guild.me.id
    ]
    member_directory = ", ".join(
        f"{member.display_name} (username={member.name}, user_id={member.id})"
        for member in guild.members
        if not member.bot
    )[:12000]
    return AIContext(
        current_request=request,
        current_channel=getattr(message.channel, "name", "unknown"),
        current_user=message.author.display_name,
        current_user_id=message.author.id,
        current_guild_id=guild.id,
        mentioned_members=mention_members(human_mentions),
        current_image_urls=current_images,
        current_image_parts=current_image_parts,
        recent_messages=recent_messages,
        rules_messages=rules_messages,
        staff_messages=staff_messages,
        configured_channels=configured_channels,
        member_directory=member_directory,
    )
