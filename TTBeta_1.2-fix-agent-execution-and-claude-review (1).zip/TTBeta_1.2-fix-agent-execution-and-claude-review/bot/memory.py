"""Durable, bounded conversation memory for the moderation assistant."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Lock

from .config import DATA_DIR


MEMORY_PATH = DATA_DIR / "conversations.sqlite3"
MEMORY_TTL = timedelta(hours=2)
MAX_MESSAGES = 20
_lock = Lock()


class ConversationStore:
    """Stores only recent conversation turns, partitioned by server/user/channel."""

    def __init__(self, path: Path = MEMORY_PATH) -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS conversation_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    channel_id INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_conversation_key
                ON conversation_messages(guild_id, user_id, channel_id, created_at)
                """
            )
            connection.commit()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    def _clear_expired(self, connection: sqlite3.Connection) -> None:
        cutoff = (self._now() - MEMORY_TTL).isoformat()
        connection.execute(
            "DELETE FROM conversation_messages WHERE created_at < ?",
            (cutoff,),
        )

    def load(self, guild_id: int, user_id: int, channel_id: int) -> list[dict[str, str]]:
        with _lock, self._connect() as connection:
            self._clear_expired(connection)
            rows = connection.execute(
                """
                SELECT role, content
                FROM conversation_messages
                WHERE guild_id = ? AND user_id = ? AND channel_id = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (guild_id, user_id, channel_id, MAX_MESSAGES),
            ).fetchall()
            connection.commit()
        return [
            {"role": str(row["role"]), "content": str(row["content"])}
            for row in reversed(rows)
        ]

    def replace(
        self,
        guild_id: int,
        user_id: int,
        channel_id: int,
        messages: list[dict[str, str]],
    ) -> None:
        bounded = messages[-MAX_MESSAGES:]
        now = self._now()
        with _lock, self._connect() as connection:
            self._clear_expired(connection)
            connection.execute(
                """
                DELETE FROM conversation_messages
                WHERE guild_id = ? AND user_id = ? AND channel_id = ?
                """,
                (guild_id, user_id, channel_id),
            )
            for index, message in enumerate(bounded):
                created_at = (now + timedelta(microseconds=index)).isoformat()
                connection.execute(
                    """
                    INSERT INTO conversation_messages
                    (guild_id, user_id, channel_id, role, content, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        guild_id,
                        user_id,
                        channel_id,
                        message.get("role", "user"),
                        message.get("content", "")[:4000],
                        created_at,
                    ),
                )
            connection.commit()

    def clear_expired(self) -> None:
        with _lock, self._connect() as connection:
            self._clear_expired(connection)
            connection.commit()