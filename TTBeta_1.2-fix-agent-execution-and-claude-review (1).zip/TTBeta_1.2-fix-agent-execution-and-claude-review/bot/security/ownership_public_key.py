"""Pinned Ed25519 public key for TetalBot release attribution."""

PUBLIC_KEY_B64 = "K6bPIEjXUPtsytWcxtJxK9TJxTlZ7IJzOq/nXM8xZn8="
