"""Action risk classification and per-guild confirmation policy."""

from __future__ import annotations

from typing import Any

from ..ai import ModerationProposal
from ..agent.discord_api import is_read_only_operation


HIGH_RISK_ACTIONS = {
    "ban",
    "kick",
    "unban",
    "delete",
    "delete_by_description",
    "delete_by_similarity",
    "delete_role",
    "delete_channel",
    "delete_category",
    "lock_channel",
    "set_verification", "create_thread", "create_forum_post",
    "archive_thread", "unarchive_thread", "lock_thread", "unlock_thread",
    "assign_role",
    "remove_role",
    "create_role",
    "modify_role",
    "create_invite", "revoke_invite", "create_webhook", "edit_webhook", "delete_webhook",
    "create_automod_rule", "edit_automod_rule", "delete_automod_rule",
    "create_emoji", "delete_emoji", "create_sticker", "delete_sticker",
    "remove_automation",
    # Outbound messages remain HIGH risk because they create visible side effects.
    "send_message",
}

LOW_RISK_ACTIONS = {
    "warn",
    "mute",
    "unmute",
    "modify_channel",
    "unlock_channel",
    "set_slowmode",
    "rename_server",
    "set_afk",
}


READ_ONLY_ACTIONS = {"read_file", "read_log", "get_member_roles", "list_roles", "get_server_overview", "list_channels", "search_recent_messages", "inspect_link", "list_active_threads", "list_server_assets", "list_audit_log", "list_invites", "list_webhooks", "search_stored_messages", "list_automod_rules", "list_automations", "get_ai_usage", "get_bot_diagnostics"}


def classify_action_risk(
    action: str | None,
    proposal: ModerationProposal | None = None,
) -> str:
    if action in READ_ONLY_ACTIONS:
        return "READ"
    if action == "discord_api" and proposal is not None:
        resource_type = str(proposal.parameters.get("resource_type") or "").lower()
        method_name = str(proposal.parameters.get("method") or "")
        return "READ" if is_read_only_operation(resource_type, method_name) else "HIGH"
    # Permission synchronisation can grant or revoke channel access. It must
    # never inherit the ordinary low-risk auto-execution policy for channel edits.
    if action == "modify_channel" and proposal and proposal.parameters.get("sync_permissions") is True:
        return "HIGH"
    if action in HIGH_RISK_ACTIONS:
        return "HIGH"
    if action in LOW_RISK_ACTIONS:
        if proposal and len(proposal.target_user_ids) > 1:
            return "HIGH"
        return "LOW"
    return "HIGH"


def requires_confirmation(
    action: str | None,
    proposal: ModerationProposal,
    guild_config: Any,
) -> bool:
    risk = classify_action_risk(action, proposal)
    if risk == "READ":
        return False
    if risk == "HIGH":
        return True
    enabled_actions = set(
        getattr(guild_config, "auto_execute_low_risk_actions", []) or []
    )
    return action not in enabled_actions
