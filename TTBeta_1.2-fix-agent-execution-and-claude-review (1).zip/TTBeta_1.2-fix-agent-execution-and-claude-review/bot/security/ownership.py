"""Cryptographic attribution and release-integrity verification for TetalBot."""
from __future__ import annotations
import base64, hashlib, json
from pathlib import Path
from typing import Any
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .ownership_public_key import PUBLIC_KEY_B64

PROJECT_ID = "TETALBOT-TRITRAX-2026"
PROJECT_NAME = "TetalBot"
OWNER = "Tritrax"
CREATOR = "Tritrax"
ATTRIBUTION = "Made by Tritrax | Owned by Tritrax"
COPYRIGHT = "Copyright (c) 2026 Tritrax"
MANIFEST_NAME = "ownership_manifest.json"
PROTECTED_FILES = (
    "bot/main.py", "bot/ai.py", "bot/agent/orchestrator.py",
    "bot/tools/diagnostics.py", "bot/diagnostics/__init__.py",
    "bot/diagnostics/log_buffer.py",
    "bot/security/authorization.py", "bot/security/risk_policy.py",
    "bot/security/ownership.py", "bot/security/ownership_public_key.py",
    "bot/tools/dispatcher.py", "bot/tools/moderation.py",
    "bot/database/connection.py", "bot/database/proposals.py",
    "lib/db/migrations/0000_proposals.sql",
    "lib/db/migrations/0001_context_storage.sql",
    "lib/db/migrations/0002_conversation_sequence.sql",
    "lib/db/migrations/0003_investigations.sql",
    "lib/db/migrations/0004_ai_usage.sql",
    "lib/db/migrations/0005_context_controls.sql",
    "lib/db/migrations/0006_project_identity.sql",
    "scripts/ownership.py",
    "pyproject.toml",
    "uv.lock",
)

class OwnershipIntegrityError(RuntimeError):
    """Raised when attribution or protected release files fail verification."""

def _canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def verify_ownership(root: Path | None = None) -> dict[str, Any]:
    """Verify the signed identity and every protected file. Fails closed."""
    project_root = (root or Path(__file__).resolve().parents[2]).resolve()
    manifest_path = project_root / MANIFEST_NAME
    if not PUBLIC_KEY_B64:
        raise OwnershipIntegrityError("Ownership key is not initialized. Run scripts/ownership.py init, then sign.")
    try:
        public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64, validate=True))
        envelope = json.loads(manifest_path.read_text(encoding="utf-8"))
        payload = envelope["payload"]
        signature = base64.b64decode(envelope["signature"], validate=True)
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise OwnershipIntegrityError("Ownership manifest is missing or malformed. Startup refused.") from exc
    try:
        public_key.verify(signature, _canonical_json(payload))
    except (InvalidSignature, ValueError) as exc:
        raise OwnershipIntegrityError("Ownership signature is invalid. Attribution or release metadata was modified.") from exc
    expected = {"project_id": PROJECT_ID, "project_name": PROJECT_NAME, "owner": OWNER, "creator": CREATOR, "attribution": ATTRIBUTION, "copyright": COPYRIGHT}
    if payload.get("identity") != expected:
        raise OwnershipIntegrityError("Embedded ownership identity does not match Tritrax attribution.")
    hashes = payload.get("files")
    if not isinstance(hashes, dict) or set(hashes) != set(PROTECTED_FILES):
        raise OwnershipIntegrityError("Protected-file manifest is incomplete or contains unexpected paths.")
    for relative in PROTECTED_FILES:
        path = (project_root / relative).resolve()
        if project_root not in path.parents or not path.is_file():
            raise OwnershipIntegrityError(f"Protected file is missing or invalid: {relative}")
        if hashes.get(relative) != hashlib.sha256(path.read_bytes()).hexdigest():
            raise OwnershipIntegrityError(f"Integrity check failed for {relative}. Startup refused.")
    return expected

async def verify_database_identity(pool: Any) -> None:
    row = await pool.fetchrow("SELECT project_id, owner, creator, attribution, copyright FROM project_identity WHERE project_id = $1", PROJECT_ID)
    expected = {"project_id": PROJECT_ID, "owner": OWNER, "creator": CREATOR, "attribution": ATTRIBUTION, "copyright": COPYRIGHT}
    if row is None or {key: str(row[key]) for key in expected} != expected:
        raise OwnershipIntegrityError("PostgreSQL project identity is missing or differs from the signed Tritrax identity.")
