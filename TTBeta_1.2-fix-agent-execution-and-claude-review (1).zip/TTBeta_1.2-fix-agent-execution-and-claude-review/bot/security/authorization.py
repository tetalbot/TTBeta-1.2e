"""Central requester, bot, channel, target, and resource authorization."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import discord

from ..ai import ModerationProposal
from ..utils import can_moderate
from ..agent.discord_api import required_permission

# Owner identity for restricted runtime diagnostics.
OWNER_USER_ID = 1317193612538417277


def is_owner(user_id: int | None) -> bool:
    return user_id == OWNER_USER_ID


@dataclass(frozen=True)
class AuthorizationDecision:
    allowed: bool
    code: str
    message: str


def _permission_value(member: discord.Member, permission: str, channel: Any) -> bool:
    permissions = (
        channel.permissions_for(member)
        if channel is not None and hasattr(channel, "permissions_for")
        else member.guild_permissions
    )
    return bool(getattr(permissions, permission, False))


def _resource_channel(
    guild: discord.Guild, proposal: ModerationProposal
) -> Any | None:
    if proposal.action == "discord_api" and proposal.parameters.get("resource_type") == "message":
        raw_channel_id = proposal.parameters.get("channel_id")
        try:
            return guild.get_channel_or_thread(int(raw_channel_id)) if raw_channel_id is not None else None
        except (TypeError, ValueError):
            return None
    for key in ("resource_id", "channel_id", "category_id", "afk_channel_id", "forum_channel_id", "thread_id"):
        raw = proposal.parameters.get(key)
        if raw is None:
            continue
        try:
            return guild.get_channel_or_thread(int(raw))
        except (TypeError, ValueError):
            return None
    return None


def _authorize_role_hierarchy(
    guild: discord.Guild,
    requester: discord.Member,
    bot_member: discord.Member,
    proposal: ModerationProposal,
) -> AuthorizationDecision | None:
    action = proposal.action or ""
    member_target_actions = {
        "warn", "mute", "unmute", "ban", "kick", "assign_role", "remove_role",
    }
    if action in member_target_actions:
        for target_id in proposal.target_user_ids or (
            [proposal.target_user_id] if proposal.target_user_id else []
        ):
            target = guild.get_member(target_id)
            if target is None:
                return AuthorizationDecision(
                    False,
                    "TARGET_NOT_FOUND",
                    f"Member {target_id} is no longer in this server.",
                )
            allowed, reason = can_moderate(requester, target)
            if not allowed:
                return AuthorizationDecision(False, "TARGET_HIERARCHY", reason)
            if target.top_role >= bot_member.top_role:
                return AuthorizationDecision(
                    False,
                    "BOT_ROLE_HIERARCHY",
                    "The bot's highest role must be above every target member.",
                )

    if action == "discord_api" and proposal.parameters.get("resource_type") == "role":
        method_name = str(proposal.parameters.get("method") or "")
        if method_name in {"edit", "delete"}:
            raw_role_id = proposal.parameters.get("resource_id")
            role = None
            if raw_role_id is not None:
                try:
                    role = guild.get_role(int(raw_role_id))
                except (TypeError, ValueError):
                    role = None
            if role is None:
                role_name = str(proposal.parameters.get("resource_name") or "").strip().casefold()
                role = next((item for item in guild.roles if item.name.casefold() == role_name), None)
            if role is None:
                return AuthorizationDecision(False, "RESOURCE_NOT_FOUND", "The requested role was not found.")
            if role.is_default() or (requester.id != guild.owner_id and role >= requester.top_role):
                return AuthorizationDecision(False, "REQUESTER_ROLE_HIERARCHY", "Your highest role must be above the target role.")
            if role >= bot_member.top_role:
                return AuthorizationDecision(False, "BOT_ROLE_HIERARCHY", "The bot's highest role must be above the target role.")
    if action in {
        "delete_role", "modify_role", "assign_role", "remove_role",
    }:
        raw_role_id = proposal.parameters.get("role_id")
        role = None
        if raw_role_id is not None:
            try:
                role = guild.get_role(int(raw_role_id))
            except (TypeError, ValueError):
                role = None
        else:
            role_name = str(proposal.parameters.get("role_name", "")).strip().casefold()
            role = next(
                (item for item in guild.roles if item.name.casefold() == role_name),
                None,
            )
        if role is None:
            return AuthorizationDecision(
                False, "RESOURCE_NOT_FOUND", "The requested role was not found in this server."
            )
        if role.is_default():
            return AuthorizationDecision(
                False, "RESOURCE_RESTRICTED", "The @everyone role cannot be changed."
            )
        if requester.id != guild.owner_id and role >= requester.top_role:
            return AuthorizationDecision(
                False,
                "REQUESTER_ROLE_HIERARCHY",
                "Your highest role must be above the target role.",
            )
        if role >= bot_member.top_role:
            return AuthorizationDecision(
                False,
                "BOT_ROLE_HIERARCHY",
                "The bot's highest role must be above the target role.",
            )
    return None


def authorize_operation(
    *,
    guild: discord.Guild | None,
    requester: discord.Member | None,
    bot_member: discord.Member | None,
    tool: Any,
    proposal: ModerationProposal,
    channel: Any | None = None,
) -> AuthorizationDecision:
    if guild is None or requester is None or bot_member is None:
        return AuthorizationDecision(
            False,
            "GUILD_CONTEXT_REQUIRED",
            "This operation requires a current server-member context.",
        )
    if requester.guild.id != guild.id or bot_member.guild.id != guild.id:
        return AuthorizationDecision(
            False,
            "GUILD_SCOPE_MISMATCH",
            "The requester and bot must belong to the target server.",
        )
    if requester.bot:
        return AuthorizationDecision(
            False, "BOT_REQUESTER", "Bot accounts cannot request Discord operations."
        )

    required = tuple(getattr(tool, "required_permissions", ()))
    if proposal.action == "discord_api":
        resource_type = str(proposal.parameters.get("resource_type") or "").lower()
        method_name = str(proposal.parameters.get("method") or "")
        dynamic_permission = required_permission(
            resource_type, method_name, proposal.parameters.get("arguments") or {}
        )
        required = (*required, *((dynamic_permission,) if dynamic_permission else ()))
    resource_channel = _resource_channel(guild, proposal)
    check_channel = (
        None if proposal.action == "discord_api" and proposal.parameters.get("resource_type") == "guild"
        else resource_channel or channel
    )
    if proposal.action == "discord_api" and check_channel is not None:
        resource_type = str(proposal.parameters.get("resource_type") or "").lower()
        method_name = str(proposal.parameters.get("method") or "")
        if resource_type == "message" or (resource_type in {"channel", "thread"} and method_name == "fetch_message"):
            for member, label in ((requester, "You"), (bot_member, "The bot")):
                for permission in ("view_channel", "read_message_history"):
                    if not _permission_value(member, permission, check_channel):
                        return AuthorizationDecision(
                            False,
                            "REQUESTER_PERMISSION_MISSING" if member is requester else "BOT_PERMISSION_MISSING",
                            f"{label} need {permission.replace('_', ' ')} permission for message operations.",
                        )
    for permission in required:
        if not _permission_value(requester, permission, check_channel):
            return AuthorizationDecision(
                False,
                "REQUESTER_PERMISSION_MISSING",
                f"You need {permission.replace('_', ' ')} permission for this operation.",
            )
        if not _permission_value(bot_member, permission, check_channel):
            return AuthorizationDecision(
                False,
                "BOT_PERMISSION_MISSING",
                f"The bot needs {permission.replace('_', ' ')} permission for this operation.",
            )

    hierarchy = _authorize_role_hierarchy(
        guild, requester, bot_member, proposal
    )
    if hierarchy is not None:
        return hierarchy
    return AuthorizationDecision(True, "AUTHORIZED", "Authorized.")
