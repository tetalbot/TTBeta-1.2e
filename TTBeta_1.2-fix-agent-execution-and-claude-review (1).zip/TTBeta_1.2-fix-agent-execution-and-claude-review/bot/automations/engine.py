"""Validation and deterministic matching for event-driven automations."""

from __future__ import annotations

import copy
import uuid
from datetime import datetime, timezone
from typing import Any

from ..ai import ModerationProposal
from ..entity_resolution import resolve_named_entity


SUPPORTED_TRIGGER_EVENTS = {
    "member_join", "member_leave", "message_contains", "reaction_add",
    "voice_join", "voice_leave", "role_assign", "role_remove",
}

TRIGGER_CONDITIONS = {
    "member_join": {"is_bot", "min_account_age_days"},
    "member_leave": {"is_bot"},
    "message_contains": {"channel_id", "content_contains"},
    "reaction_add": {"channel_id", "emoji"},
    "voice_join": {"voice_channel_id"},
    "voice_leave": {"voice_channel_id"},
    "role_assign": {"role_id"},
    "role_remove": {"role_id"},
}

# Only bounded, event-scoped actions may run without a per-event confirmation.
AUTOMATION_ACTION_ALLOWLIST = {
    "assign_role", "remove_role", "send_message", "warn", "mute", "delete",
}
AUTOMATION_ACTION_BANLIST = {"ban", "unban", "kick"}


def resolve_automation_rule(
    rules: list[dict[str, Any]],
    *,
    rule_id: str | None = None,
    rule_name: str | None = None,
) -> dict[str, Any] | None:
    """Resolve exactly one enabled automation by UUID or ambiguity-safe name."""
    has_id = bool(str(rule_id or "").strip())
    has_name = bool(str(rule_name or "").strip())
    if has_id == has_name:
        raise ValueError("Provide exactly one of rule_id or rule_name.")
    if has_id:
        try:
            normalized_id = str(uuid.UUID(str(rule_id).strip()))
        except (ValueError, AttributeError) as exc:
            raise ValueError("rule_id must be a valid automation UUID.") from exc
        return next(
            (rule for rule in rules if str(rule.get("id") or "") == normalized_id),
            None,
        )
    try:
        return resolve_named_entity(
            str(rule_name),
            rules,
            name_of=lambda rule: str(rule.get("name") or ""),
            minimum_score=0.60,
            ambiguity_margin=0.07,
        )
    except ValueError as exc:
        raise ValueError(str(exc)) from exc


SENSITIVE_ROLE_PERMISSIONS = {
    "administrator", "manage_guild", "manage_roles", "manage_channels",
    "manage_messages", "manage_webhooks", "manage_emojis_and_stickers",
    "manage_events", "manage_threads", "ban_members", "kick_members",
    "moderate_members", "view_audit_log",
}


def ensure_automation_role_safe(role: Any | None) -> None:
    """Prevent event rules from granting or removing privileged/integration roles."""
    if role is None:
        raise ValueError("The automation role no longer exists.")
    if getattr(role, "managed", False) or (callable(getattr(role, "is_default", None)) and role.is_default()):
        raise ValueError("Managed and @everyone roles cannot be used in automations.")
    permissions = getattr(role, "permissions", None)
    if permissions is not None and any(
        bool(getattr(permissions, permission, False))
        for permission in SENSITIVE_ROLE_PERMISSIONS
    ):
        raise ValueError(
            "This role has privileged server permissions and cannot be assigned or removed automatically."
        )

EVENT_PLACEHOLDERS = {
    "$event.member_id": "123456789012345678",
    "$event.member_mention": "<@123456789012345678>",
    "$event.username": "Example member",
    "$event.is_bot": False,
    "$event.channel_id": "123456789012345678",
    "$event.role_id": "123456789012345678",
    "$event.emoji": "👍",
    "$event.content": "Example message",
    "$event.message_id": "123456789012345678",
}


def _resolve_id(
    guild: Any,
    value: Any,
    candidates: list[Any],
    *,
    label: str,
) -> str:
    if value is None:
        raise ValueError(f"A {label} is required.")
    raw = str(value).strip()
    if raw.isdigit():
        match = next((item for item in candidates if str(getattr(item, "id", "")) == raw), None)
    else:
        try:
            match = resolve_named_entity(raw, candidates, name_of=lambda item: str(item.name))
        except ValueError as exc:
            raise ValueError(str(exc)) from exc
    if match is None:
        raise ValueError(f"I couldn't find a {label} matching **{raw}** in this server.")
    return str(match.id)


def _normalize_conditions(
    raw_conditions: Any,
    *,
    trigger: str,
    guild: Any,
) -> dict[str, Any]:
    conditions = raw_conditions or {}
    if not isinstance(conditions, dict) or len(conditions) > 8:
        raise ValueError("Conditions must be a small JSON object.")
    conditions = copy.deepcopy(conditions)
    allowed_conditions = TRIGGER_CONDITIONS[trigger]
    unknown = set(conditions) - allowed_conditions
    if unknown:
        raise ValueError("Unsupported trigger condition(s): " + ", ".join(sorted(unknown)))
    if "is_bot" in conditions and type(conditions["is_bot"]) is not bool:
        raise ValueError("is_bot must be true or false.")
    if "min_account_age_days" in conditions:
        age = conditions["min_account_age_days"]
        if type(age) is not int or not 0 <= age <= 3650:
            raise ValueError("min_account_age_days must be between 0 and 3650.")
    if "content_contains" in conditions:
        phrase = str(conditions["content_contains"]).strip()
        if not phrase or len(phrase) > 150:
            raise ValueError("content_contains must be 1-150 characters.")
        conditions["content_contains"] = phrase
    if "emoji" in conditions:
        emoji = str(conditions["emoji"]).strip()
        if not emoji or len(emoji) > 100:
            raise ValueError("emoji must be 1-100 characters.")
        conditions["emoji"] = emoji
    if "channel_id" in conditions:
        conditions["channel_id"] = _resolve_id(
            guild, conditions["channel_id"],
            list(getattr(guild, "text_channels", [])) + list(getattr(guild, "threads", [])),
            label="text channel",
        )
    if "voice_channel_id" in conditions:
        conditions["voice_channel_id"] = _resolve_id(
            guild, conditions["voice_channel_id"],
            list(getattr(guild, "voice_channels", [])),
            label="voice channel",
        )
    if "role_id" in conditions:
        conditions["role_id"] = _resolve_id(
            guild, conditions["role_id"], list(getattr(guild, "roles", [])),
            label="role",
        )
    return conditions


def validate_automation_definition(
    raw: dict[str, Any],
    *,
    guild: Any,
    registry: Any,
) -> dict[str, Any]:
    """Validate an AI-generated rule against live Discord entities and an allowlist."""
    if not isinstance(raw, dict):
        raise ValueError("The automation definition must be an object.")
    trigger = str(raw.get("trigger_event") or "")
    if trigger not in SUPPORTED_TRIGGER_EVENTS:
        raise ValueError("That event trigger is not supported.")
    name = str(raw.get("name") or "").strip()[:100]
    description = str(raw.get("description") or "").strip()[:1000]
    if not name:
        name = f"{trigger.replace('_', ' ').title()} automation"
    if not description:
        raise ValueError("The automation needs a description.")

    conditions = _normalize_conditions(
        raw.get("trigger_conditions"), trigger=trigger, guild=guild
    )

    actions = raw.get("action_sequence")
    if not isinstance(actions, list) or not 1 <= len(actions) <= 5:
        raise ValueError("An automation must contain between 1 and 5 actions.")
    normalized_actions: list[dict[str, Any]] = []
    for item in actions:
        if not isinstance(item, dict):
            raise ValueError("Every automation action must be an object.")
        tool_name = str(item.get("tool_name") or "")
        if tool_name in AUTOMATION_ACTION_BANLIST:
            raise ValueError(
                f"{tool_name} is not permitted in event automations and can never be automated; "
                "it always requires manual staff confirmation."
            )
        if tool_name not in AUTOMATION_ACTION_ALLOWLIST:
            raise ValueError(
                f"{tool_name or 'An action'} is not permitted in event automations. "
                "Supported actions are role assignment/removal, channel messages, event-scoped warnings, "
                "bounded timeouts, and deletion of the triggering message."
            )
        try:
            tool = registry.get(tool_name)
        except KeyError as exc:
            raise ValueError(f"The {tool_name} tool is not registered.") from exc
        if not getattr(tool, "automation_eligible", False):
            raise ValueError(f"The {tool_name} tool is not marked automation-eligible.")
        arguments = item.get("arguments")
        if not isinstance(arguments, dict):
            raise ValueError(f"The {tool_name} action needs an arguments object.")
        arguments = copy.deepcopy(arguments)
        if arguments.get("status") != "proposal" or arguments.get("action") != tool_name:
            raise ValueError(f"The {tool_name} action has an invalid proposal envelope.")
        parameters = arguments.setdefault("parameters", {})
        if not isinstance(parameters, dict):
            raise ValueError(f"The {tool_name} parameters must be an object.")

        if tool_name in {"assign_role", "remove_role"}:
            if trigger in {"role_assign", "role_remove"}:
                raise ValueError(
                    "Role-change triggers may send a message, but cannot change roles again; "
                    "this prevents automation loops."
                )
            if trigger == "member_leave":
                raise ValueError("A departing member cannot receive or lose a server role after leaving.")
            target = arguments.get("target_user_id")
            if target != "$event.member_id":
                raise ValueError(
                    f"{tool_name} must target the member from the triggering event."
                )
            parameters["role_id"] = _resolve_id(
                guild, parameters.get("role_id") or parameters.get("role_name"),
                list(getattr(guild, "roles", [])), label="role",
            )
            role = next(
                (item for item in getattr(guild, "roles", [])
                 if str(getattr(item, "id", "")) == parameters["role_id"]),
                None,
            )
            ensure_automation_role_safe(role)
            parameters.pop("role_name", None)
        elif tool_name in {"warn", "mute"}:
            if trigger == "member_leave":
                raise ValueError("A departing member cannot be moderated after leaving the server.")
            if arguments.get("target_user_id") not in (None, "$event.member_id"):
                raise ValueError(f"{tool_name} must target the member from the triggering event.")
            arguments["target_user_id"] = "$event.member_id"
            if tool_name == "warn" and not arguments.get("reason"):
                arguments["reason"] = description[:500]
            if tool_name == "mute":
                duration = arguments.get("duration_minutes")
                if type(duration) is not int or not 1 <= duration <= 10080:
                    raise ValueError(
                        "Automated mute requires an explicit duration between 1 and 10080 minutes."
                    )
        elif tool_name == "delete":
            if trigger != "message_contains":
                raise ValueError(
                    "Automated deletion is only allowed for the message that triggered a message_contains event."
                )
            arguments["evidence_message_ids"] = ["$event.message_id"]
            parameters["message_ids"] = ["$event.message_id"]
            parameters["message_channels"] = {
                "$event.message_id": "$event.channel_id"
            }
        elif tool_name == "send_message":
            if parameters.get("destination") != "channel":
                raise ValueError("Automation messages must go to a server text channel.")
            parameters["channel_id"] = _resolve_id(
                guild, parameters.get("channel_id") or parameters.get("channel_name"),
                list(getattr(guild, "text_channels", [])),
                label="text channel",
            )
            parameters.pop("channel_name", None)
            content = str(parameters.get("content") or "")
            if not content or len(content) > 2000:
                raise ValueError("Automation message content must be 1-2000 characters.")
            if "$event.member_mention" in content and trigger != "member_leave":
                parameters["mention_user_id"] = "$event.member_id"

        sample = copy.deepcopy(arguments)
        sample["target_user_id"] = EVENT_PLACEHOLDERS.get(
            sample.get("target_user_id"), sample.get("target_user_id")
        )
        sample["evidence_message_ids"] = [
            EVENT_PLACEHOLDERS.get(str(value), value)
            for value in sample.get("evidence_message_ids", [])
        ]
        sample_parameters = sample.get("parameters", {})
        for key, value in list(sample_parameters.items()):
            if isinstance(value, str):
                sample_parameters[key] = EVENT_PLACEHOLDERS.get(value, value)
        validation_error = tool.validate_arguments(sample)
        if validation_error:
            raise ValueError(f"Invalid {tool_name} action: {validation_error}")
        proposal = ModerationProposal.from_payload(sample)
        if not proposal.is_valid_proposal():
            raise ValueError(f"The {tool_name} action is missing required fields.")
        action_conditions = _normalize_conditions(
            item.get("conditions"), trigger=trigger, guild=guild
        )
        normalized_actions.append({
            "tool_name": tool_name,
            "arguments": arguments,
            "conditions": action_conditions,
        })

    return {
        "name": name,
        "description": description,
        "trigger_event": trigger,
        "trigger_conditions": conditions,
        "action_sequence": normalized_actions,
        "use_ai_reasoning": raw.get("use_ai_reasoning") is True,
    }


def conditions_match(conditions: dict[str, Any], event_data: dict[str, Any]) -> bool:
    """Evaluate the supported event filters without invoking an AI model."""
    if not isinstance(conditions, dict):
        return False
    if "is_bot" in conditions and event_data.get("is_bot") is not conditions["is_bot"]:
        return False
    if "min_account_age_days" in conditions:
        try:
            if int(event_data.get("account_age_days", -1)) < int(conditions["min_account_age_days"]):
                return False
        except (TypeError, ValueError):
            return False
    if "channel_id" in conditions and str(event_data.get("channel_id")) != str(conditions["channel_id"]):
        return False
    if "voice_channel_id" in conditions and str(event_data.get("channel_id")) != str(conditions["voice_channel_id"]):
        return False
    if "role_id" in conditions and str(event_data.get("role_id")) != str(conditions["role_id"]):
        return False
    if "emoji" in conditions and str(event_data.get("emoji")) != str(conditions["emoji"]):
        return False
    if "content_contains" in conditions:
        content = str(event_data.get("content") or "").casefold()
        if str(conditions["content_contains"]).casefold() not in content:
            return False
    return True


def render_event_placeholders(value: Any, event_data: dict[str, Any]) -> Any:
    """Substitute only the explicitly supported event variables."""
    mapping = {
        "$event.member_id": str(event_data.get("member_id") or ""),
        "$event.member_mention": str(event_data.get("member_mention") or ""),
        "$event.username": str(event_data.get("username") or ""),
        "$event.is_bot": bool(event_data.get("is_bot", False)),
        "$event.channel_id": str(event_data.get("channel_id") or ""),
        "$event.role_id": str(event_data.get("role_id") or ""),
        "$event.emoji": str(event_data.get("emoji") or ""),
        "$event.content": str(event_data.get("content") or "")[:500],
        "$event.message_id": str(event_data.get("message_id") or ""),
    }
    if isinstance(value, dict):
        return {key: render_event_placeholders(item, event_data) for key, item in value.items()}
    if isinstance(value, list):
        return [render_event_placeholders(item, event_data) for item in value]
    if isinstance(value, str):
        if value in mapping:
            return mapping[value]
        rendered = value
        for token, replacement in mapping.items():
            if isinstance(replacement, str):
                rendered = rendered.replace(token, replacement)
        return rendered
    return value


def account_age_days(created_at: Any) -> int:
    if created_at is None:
        return -1
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    return max(0, (datetime.now(timezone.utc) - created_at).days)
