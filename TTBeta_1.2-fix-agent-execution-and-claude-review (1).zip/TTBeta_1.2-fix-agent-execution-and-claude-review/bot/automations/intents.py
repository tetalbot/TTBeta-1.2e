"""Shared intent detection for persistent event-driven automations."""

from __future__ import annotations

AUTOMATION_INTENT_PATTERNS = (
    "whenever", "every time", "when someone", "when a member",
    "when anyone", "automatically", "auto ", "if someone joins",
    "if a member joins", "if they join", "on join", "on leave",
    "when they leave", "if a user", "set up a rule", "create a rule",
    "add a rule", "monitor for", "watch for",
    "create an automation", "make an automation", "set up an automation",
    "add an automation", "automation rule", "automate this", "automate when",
    "welcome new members", "welcome new users", "every new member",
    "each new member", "every new user", "each new user",
    "every new member joins", "each new member joins",
    "welcome every member", "welcome each member", "new member joins",
    "new members join", "when a new member", "when a new user",
    "when a user joins", "on member join", "on member leave",
    "when someone posts", "when someone sends", "when someone reacts",
    "when someone joins voice", "when someone leaves voice",
    "when a role is assigned", "when a role is removed",
    "when a member gets a role", "when a member loses a role",
)


def looks_like_automation_request(text: str) -> bool:
    """Detect a persistent event-driven rule request in a staff message."""
    lowered = text.casefold()
    return any(pattern in lowered for pattern in AUTOMATION_INTENT_PATTERNS)
