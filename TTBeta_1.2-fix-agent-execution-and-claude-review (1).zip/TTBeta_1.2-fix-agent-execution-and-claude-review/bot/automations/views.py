"""Confirmation UI for natural-language automation drafts."""

from __future__ import annotations

import logging
from typing import Any

import discord

LOGGER = logging.getLogger("ai-moderator.automations")


class AutomationRuleConfirmationView(discord.ui.View):
    def __init__(
        self,
        bot: Any,
        *,
        guild_id: int,
        creator_id: int,
        draft: dict[str, Any],
    ) -> None:
        super().__init__(timeout=180)
        self.bot = bot
        self.guild_id = guild_id
        self.creator_id = creator_id
        self.draft = draft

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.creator_id:
            await interaction.response.send_message(
                "Only the moderator who drafted this automation can approve it.",
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return False
        if interaction.guild is None or interaction.guild.id != self.guild_id:
            await interaction.response.send_message(
                "This automation draft belongs to another server.",
                ephemeral=True,
            )
            return False
        if not isinstance(interaction.user, discord.Member) or not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(
                "Manage Server permission is required to approve automations.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="Approve and enable", style=discord.ButtonStyle.success)
    async def approve(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        repository = self.bot.automation_repo
        if repository is None:
            await interaction.response.edit_message(
                content="Automation storage is unavailable. Nothing was enabled.",
                view=None,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        try:
            record = await repository.create(
                guild_id=self.guild_id,
                created_by=self.creator_id,
                name=self.draft["name"],
                description=self.draft["description"],
                trigger_event=self.draft["trigger_event"],
                trigger_conditions=self.draft["trigger_conditions"],
                action_sequence=self.draft["action_sequence"],
                use_ai_reasoning=self.draft["use_ai_reasoning"],
            )
        except Exception:
            LOGGER.exception("Could not persist approved automation rule")
            await interaction.response.edit_message(
                content="I couldn't save the automation. It has not been enabled.",
                view=None,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return
        await interaction.response.edit_message(
            content=(
                f"Automation **{record['name']}** is now enabled. "
                f"Rule ID: `{record['id']}`"
            ),
            view=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        await interaction.response.edit_message(
            content="Automation draft cancelled. Nothing was saved.",
            view=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )


