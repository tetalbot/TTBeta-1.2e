"""Rolling in-memory log buffer for owner-only diagnostics."""
from __future__ import annotations

import logging
from collections import deque

_BUFFER: deque[str] = deque(maxlen=500)
_HANDLER: logging.Handler | None = None


class _BufferHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        try:
            _BUFFER.append(self.format(record))
        except Exception:
            self.handleError(record)


def install_buffer_handler() -> None:
    """Attach one rolling handler to the root logger."""
    global _HANDLER
    if _HANDLER is not None:
        return
    handler = _BufferHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    root_logger = logging.getLogger()
    if root_logger.level > logging.INFO:
        root_logger.setLevel(logging.INFO)
    root_logger.addHandler(handler)
    _HANDLER = handler


def get_tail(lines: int = 100) -> str:
    if type(lines) is not int or not 1 <= lines <= 500:
        raise ValueError("lines must be an integer between 1 and 500")
    tail = list(_BUFFER)[-lines:]
    return "\n".join(tail) if tail else "(no log output yet)"
