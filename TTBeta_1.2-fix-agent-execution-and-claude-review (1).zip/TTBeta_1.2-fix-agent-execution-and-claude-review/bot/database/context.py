"""Bounded PostgreSQL storage for Discord context and evidence metadata."""

from __future__ import annotations

import re
from urllib.parse import urlsplit, urlunsplit
from typing import Any


_URL_PATTERN = re.compile(r"https?://[^\s<>()]+", re.IGNORECASE)
MAX_MESSAGE_CHARS = 4000
MAX_ATTACHMENTS_PER_MESSAGE = 10


class ContextRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def store_message(self, message: Any) -> None:
        guild = getattr(message, "guild", None)
        if guild is None or getattr(message.author, "bot", False):
            return
        channel = message.channel
        excluded = await self.pool.fetchval(
            """
            SELECT COALESCE(excluded_channel_ids, '[]'::jsonb) @> $2::jsonb
            FROM guild_settings WHERE guild_id = $1
            """,
            str(guild.id),
            f'["{channel.id}"]',
        )
        if excluded:
            await self.mark_deleted(message.id)
            return

        await self.pool.execute(
            """
            INSERT INTO guilds (guild_id, name, updated_at)
            VALUES ($1, $2, now())
            ON CONFLICT (guild_id) DO UPDATE
            SET name = EXCLUDED.name, updated_at = now()
            """,
            str(guild.id),
            str(guild.name)[:200],
        )
        await self.pool.execute(
            """
            INSERT INTO channels (channel_id, guild_id, name, channel_type, parent_id, updated_at)
            VALUES ($1, $2, $3, $4, $5, now())
            ON CONFLICT (channel_id) DO UPDATE
            SET name = EXCLUDED.name, channel_type = EXCLUDED.channel_type,
                parent_id = EXCLUDED.parent_id, updated_at = now()
            """,
            str(channel.id),
            str(guild.id),
            str(getattr(channel, "name", "unknown"))[:100],
            type(channel).__name__[:40],
            str(channel.category_id) if getattr(channel, "category_id", None) else None,
        )
        await self.pool.execute(
            """
            INSERT INTO members (guild_id, user_id, display_name, is_bot, updated_at)
            VALUES ($1, $2, $3, FALSE, now())
            ON CONFLICT (guild_id, user_id) DO UPDATE
            SET display_name = EXCLUDED.display_name, updated_at = now()
            """,
            str(guild.id),
            str(message.author.id),
            str(message.author.display_name)[:200],
        )
        reference = getattr(getattr(message, "reference", None), "message_id", None)
        await self.pool.execute(
            """
            INSERT INTO messages
                (message_id, guild_id, channel_id, author_id, content, created_at,
                 edited_at, reference_message_id, deleted_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NULL)
            ON CONFLICT (message_id) DO UPDATE
            SET content = EXCLUDED.content, edited_at = EXCLUDED.edited_at,
                reference_message_id = EXCLUDED.reference_message_id, deleted_at = NULL
            """,
            str(message.id),
            str(guild.id),
            str(channel.id),
            str(message.author.id),
            str(message.content or "")[:MAX_MESSAGE_CHARS],
            message.created_at,
            getattr(message, "edited_at", None),
            str(reference) if reference else None,
        )
        await self.pool.execute(
            "DELETE FROM attachments WHERE message_id = $1",
            str(message.id),
        )
        for attachment in list(getattr(message, "attachments", []))[:MAX_ATTACHMENTS_PER_MESSAGE]:
            await self.pool.execute(
                """
                INSERT INTO attachments
                    (attachment_id, message_id, filename, content_type, size_bytes, source_url)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT (attachment_id) DO UPDATE
                SET filename = EXCLUDED.filename, content_type = EXCLUDED.content_type,
                    size_bytes = EXCLUDED.size_bytes, source_url = EXCLUDED.source_url
                """,
                str(attachment.id),
                str(message.id),
                str(getattr(attachment, "filename", ""))[:255],
                getattr(attachment, "content_type", None),
                int(getattr(attachment, "size", 0)),
                urlunsplit((*urlsplit(str(getattr(attachment, "url", "")))[:3], "", ""))[:2000],
            )
        await self.pool.execute(
            "DELETE FROM message_links WHERE message_id = $1",
            str(message.id),
        )
        for url in _URL_PATTERN.findall((message.content or "")[:MAX_MESSAGE_CHARS])[:20]:
            await self.pool.execute(
                "INSERT INTO message_links (message_id, url) VALUES ($1, $2) ON CONFLICT DO NOTHING",
                str(message.id),
                url[:2000],
            )

    async def mark_deleted(self, message_id: int) -> None:
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    "UPDATE messages SET deleted_at = now(), content = '' WHERE message_id = $1",
                    str(message_id),
                )
                await connection.execute(
                    "DELETE FROM attachments WHERE message_id = $1",
                    str(message_id),
                )
                await connection.execute(
                    "DELETE FROM message_links WHERE message_id = $1",
                    str(message_id),
                )

    async def search_messages(
        self,
        guild_id: int,
        query: str,
        *,
        limit: int = 20,
        channel_ids: list[int] | None = None,
    ) -> list[dict[str, Any]]:
        bounded_limit = max(1, min(int(limit), 50))
        terms = " ".join(part for part in re.findall(r"[\w-]{2,}", query)[:12])
        if not terms:
            return []
        rows = await self.pool.fetch(
            """
            SELECT m.message_id, m.channel_id, m.author_id, m.content,
                   m.created_at, m.reference_message_id, c.name AS channel_name
            FROM messages m
            JOIN channels c ON c.channel_id = m.channel_id
            WHERE m.guild_id = $1 AND m.deleted_at IS NULL
              AND m.created_at >= now() - make_interval(
                    days => COALESCE(
                        (SELECT retention_days FROM guild_settings WHERE guild_id = m.guild_id),
                        90
                    )
                  )
              AND m.content_tsv @@ plainto_tsquery('simple', $2)
              AND ($3::text[] IS NULL OR m.channel_id = ANY($3::text[]))
            ORDER BY m.created_at DESC
            LIMIT $4
            """,
            str(guild_id),
            terms,
            [str(item) for item in channel_ids] if channel_ids else None,
            bounded_limit,
        )
        return [dict(row) for row in rows]

    async def prune_expired(self, *, batch_size: int = 1000) -> int:
        batch = max(1, min(int(batch_size), 5000))
        result = await self.pool.execute(
            """
            WITH expired AS (
                SELECT m.message_id
                FROM messages m
                LEFT JOIN guild_settings s ON s.guild_id = m.guild_id
                WHERE m.created_at < now() - make_interval(days => COALESCE(s.retention_days, 90))
                ORDER BY m.created_at
                LIMIT $1
            )
            DELETE FROM messages m USING expired e
            WHERE m.message_id = e.message_id
            """,
            batch,
        )
        try:
            return int(str(result).split()[-1])
        except (ValueError, IndexError):
            return 0
