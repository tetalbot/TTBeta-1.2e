"""PostgreSQL-backed mirrors for guild configuration and moderation cases."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from ..config import CaseStore, GuildConfig, ModerationCase, ConfigStore


def _datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed


class GuildSettingsRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def load_into(self, store: ConfigStore) -> None:
        rows = await self.pool.fetch(
            """
            SELECT guild_id, rules_channel_id, logs_channel_id, staff_channel_id,
                   context_message_limit, rules_message_limit, staff_message_limit,
                   auto_execute_low_risk_actions, retention_days, excluded_channel_ids
            FROM guild_settings
            """
        )
        for row in rows:
            values = dict(row)
            raw_actions = values.get("auto_execute_low_risk_actions") or []
            if isinstance(raw_actions, str):
                raw_actions = json.loads(raw_actions)
            excluded_channels = values.get("excluded_channel_ids") or []
            if isinstance(excluded_channels, str):
                excluded_channels = json.loads(excluded_channels)
            store.guilds[str(values["guild_id"])] = GuildConfig(
                rules_channel_id=int(values["rules_channel_id"]) if values.get("rules_channel_id") else None,
                logs_channel_id=int(values["logs_channel_id"]) if values.get("logs_channel_id") else None,
                staff_channel_id=int(values["staff_channel_id"]) if values.get("staff_channel_id") else None,
                context_message_limit=int(values.get("context_message_limit", 10)),
                rules_message_limit=int(values.get("rules_message_limit", 0)),
                staff_message_limit=int(values.get("staff_message_limit", 0)),
                auto_execute_low_risk_actions=[str(item) for item in raw_actions],
                retention_days=max(1, min(int(values.get("retention_days", 90)), 3650)),
                excluded_channel_ids=[int(item) for item in excluded_channels],
            )

    async def upsert(self, guild_id: int, config: GuildConfig) -> None:
        await self.pool.execute(
            """
            INSERT INTO guilds (guild_id, name, updated_at)
            VALUES ($1, '', now())
            ON CONFLICT (guild_id) DO NOTHING
            """,
            str(guild_id),
        )
        await self.pool.execute(
            """
            INSERT INTO guild_settings (
                guild_id, rules_channel_id, logs_channel_id, staff_channel_id,
                context_message_limit, rules_message_limit, staff_message_limit,
                auto_execute_low_risk_actions, retention_days, excluded_channel_ids, updated_at
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10::jsonb,now())
            ON CONFLICT (guild_id) DO UPDATE SET
                rules_channel_id=EXCLUDED.rules_channel_id,
                logs_channel_id=EXCLUDED.logs_channel_id,
                staff_channel_id=EXCLUDED.staff_channel_id,
                context_message_limit=EXCLUDED.context_message_limit,
                rules_message_limit=EXCLUDED.rules_message_limit,
                staff_message_limit=EXCLUDED.staff_message_limit,
                auto_execute_low_risk_actions=EXCLUDED.auto_execute_low_risk_actions,
                retention_days=EXCLUDED.retention_days,
                excluded_channel_ids=EXCLUDED.excluded_channel_ids,
                updated_at=now()
            """,
            str(guild_id),
            str(config.rules_channel_id) if config.rules_channel_id else None,
            str(config.logs_channel_id) if config.logs_channel_id else None,
            str(config.staff_channel_id) if config.staff_channel_id else None,
            int(config.context_message_limit),
            int(config.rules_message_limit),
            int(config.staff_message_limit),
            json.dumps(list(config.auto_execute_low_risk_actions)),
            max(1, min(int(config.retention_days), 3650)),
            json.dumps([int(item) for item in config.excluded_channel_ids]),
        )


class ModerationCaseRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def load_into(self, store: CaseStore) -> None:
        rows = await self.pool.fetch("SELECT * FROM moderation_cases ORDER BY proposed_at")
        merged = {(case.guild_id, case.case_id): case for case in store.cases}
        for row in rows:
            value = dict(row)
            evidence = value.get("evidence_message_ids") or []
            if isinstance(evidence, str):
                evidence = json.loads(evidence)
            case = ModerationCase(
                case_id=int(value["case_id"]),
                guild_id=int(value["guild_id"]),
                moderator_id=int(value["moderator_id"]),
                target_id=int(value["target_id"]),
                action=str(value["action"]),
                reason=value.get("reason"),
                rule_reference=value.get("rule_reference"),
                evidence_message_ids=[int(item) for item in evidence],
                proposed_at=value["proposed_at"].isoformat(),
                status=str(value.get("status", "proposed")),
                confirmed_at=value["confirmed_at"].isoformat() if value.get("confirmed_at") else None,
                closed_at=value["closed_at"].isoformat() if value.get("closed_at") else None,
                outcome=value.get("outcome"),
                duration_minutes=int(value["duration_minutes"]) if value.get("duration_minutes") is not None else None,
            )
            merged[(case.guild_id, case.case_id)] = case
        store.cases = sorted(merged.values(), key=lambda item: (item.proposed_at, item.guild_id, item.case_id))

    async def upsert(self, case: ModerationCase) -> None:
        await self.pool.execute(
            """
            INSERT INTO moderation_cases (
                guild_id, case_id, moderator_id, target_id, action, reason,
                rule_reference, evidence_message_ids, proposed_at, status,
                confirmed_at, closed_at, outcome, duration_minutes
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11,$12,$13,$14)
            ON CONFLICT (guild_id, case_id) DO UPDATE SET
                moderator_id=EXCLUDED.moderator_id,
                target_id=EXCLUDED.target_id,
                action=EXCLUDED.action,
                reason=EXCLUDED.reason,
                rule_reference=EXCLUDED.rule_reference,
                evidence_message_ids=EXCLUDED.evidence_message_ids,
                proposed_at=EXCLUDED.proposed_at,
                status=EXCLUDED.status,
                confirmed_at=EXCLUDED.confirmed_at,
                closed_at=EXCLUDED.closed_at,
                outcome=EXCLUDED.outcome,
                duration_minutes=EXCLUDED.duration_minutes
            """,
            str(case.guild_id),
            int(case.case_id),
            str(case.moderator_id),
            str(case.target_id),
            case.action,
            case.reason,
            case.rule_reference,
            json.dumps(case.evidence_message_ids),
            _datetime(case.proposed_at),
            case.status,
            _datetime(case.confirmed_at),
            _datetime(case.closed_at),
            case.outcome,
            case.duration_minutes,
        )
