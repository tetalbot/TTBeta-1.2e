"""PostgreSQL-backed short-lived conversational memory."""

from __future__ import annotations

from typing import Any

MAX_MESSAGES = 20
MAX_CONTENT_CHARS = 4000


class ConversationRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def load(
        self, guild_id: int, user_id: int, channel_id: int
    ) -> list[dict[str, str]]:
        rows = await self.pool.fetch(
            """
            SELECT role, content
            FROM conversation_messages
            WHERE guild_id = $1 AND user_id = $2 AND channel_id = $3
              AND created_at >= now() - interval '2 hours'
            ORDER BY source_id DESC
            LIMIT $4
            """,
            str(guild_id), str(user_id), str(channel_id), MAX_MESSAGES,
        )
        return [
            {"role": str(row["role"]), "content": str(row["content"])}
            for row in reversed(rows)
        ]

    async def replace(
        self,
        guild_id: int,
        user_id: int,
        channel_id: int,
        messages: list[dict[str, str]],
    ) -> None:
        bounded = messages[-MAX_MESSAGES:]
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    """
                    DELETE FROM conversation_messages
                    WHERE guild_id = $1 AND user_id = $2 AND channel_id = $3
                    """,
                    str(guild_id), str(user_id), str(channel_id),
                )
                for message in bounded:
                    await connection.execute(
                        """
                        INSERT INTO conversation_messages
                            (guild_id, user_id, channel_id, role, content, created_at)
                        VALUES ($1, $2, $3, $4, $5, now())
                        """,
                        str(guild_id), str(user_id), str(channel_id),
                        str(message.get("role", "user"))[:20],
                        str(message.get("content", ""))[:MAX_CONTENT_CHARS],
                    )

    async def prune_expired(self) -> int:
        result = await self.pool.execute(
            "DELETE FROM conversation_messages WHERE created_at < now() - interval '2 hours'"
        )
        try:
            return int(str(result).split()[-1])
        except (ValueError, IndexError):
            return 0
