"""Atomic PostgreSQL proposal lifecycle with restart-safe execution claims."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any


VALID_TERMINAL_STATES = {
    "completed",
    "partially_completed",
    "failed",
    "cancelled",
    "expired",
}


class ProposalStateError(RuntimeError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class ProposalRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    @staticmethod
    def _decode(row: Any) -> dict[str, Any]:
        result = dict(row)
        for key in ("arguments", "result", "metadata"):
            value = result.get(key)
            if isinstance(value, str):
                try:
                    result[key] = json.loads(value)
                except json.JSONDecodeError:
                    result[key] = {}
        return result

    async def create(
        self,
        *,
        guild_id: int,
        user_id: int,
        operation: str,
        arguments: dict[str, Any],
        metadata: dict[str, Any],
        ttl_seconds: int = 180,
    ) -> dict[str, Any]:
        proposal_id = str(uuid.uuid4())
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
        row = await self.pool.fetchrow(
            """
            INSERT INTO proposals
                (id, guild_id, user_id, operation, arguments, status, created_at,
                 expires_at, metadata)
            VALUES ($1, $2, $3, $4, $5::jsonb, 'pending', now(), $6, $7::jsonb)
            RETURNING *
            """,
            proposal_id,
            str(guild_id),
            str(user_id),
            operation,
            json.dumps(arguments, ensure_ascii=False),
            expires_at,
            json.dumps(metadata, ensure_ascii=False),
        )
        return self._decode(row)

    async def attach_confirmation_message(
        self, proposal_id: str, channel_id: int, message_id: int
    ) -> bool:
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET metadata = metadata || $2::jsonb
            WHERE id = $1 AND status = 'pending'
            RETURNING id
            """,
            proposal_id,
            json.dumps(
                {
                    "confirmation_channel_id": str(channel_id),
                    "confirmation_message_id": str(message_id),
                }
            ),
        )
        return row is not None

    async def get(self, proposal_id: str) -> dict[str, Any] | None:
        row = await self.pool.fetchrow(
            "SELECT * FROM proposals WHERE id = $1", proposal_id
        )
        return self._decode(row) if row else None

    async def list_pending(self) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT * FROM proposals
            WHERE status = 'pending'
              AND metadata ? 'confirmation_message_id'
            ORDER BY created_at
            """
        )
        return [self._decode(row) for row in rows]

    async def get_batch(self, batch_id: str) -> list[dict[str, Any]]:
        """Return every persisted action in a confirmation batch, in execution order."""
        rows = await self.pool.fetch(
            """
            SELECT * FROM proposals
            WHERE metadata->>'batch_id' = $1
            ORDER BY (metadata->>'batch_index')::integer ASC
            """,
            batch_id,
        )
        return [self._decode(row) for row in rows]

    async def claim_for_execution(self, proposal_id: str, *, guild_id: int, user_id: int) -> dict[str, Any]:
        # A single conditional UPDATE is the claim; no intermediate state is visible.
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET status = 'executing', confirmed_at = now(), executing_at = now()
            WHERE id = $1 AND guild_id = $2 AND user_id = $3
              AND status = 'pending' AND expires_at > now()
            RETURNING *
            """,
            proposal_id, str(guild_id), str(user_id),
        )
        if row is not None:
            return self._decode(row)
        state = await self.pool.fetchrow("SELECT status, expires_at FROM proposals WHERE id = $1 AND guild_id = $2 AND user_id = $3", proposal_id, str(guild_id), str(user_id))
        if state is None:
            raise ProposalStateError("PROPOSAL_NOT_FOUND", "This proposal no longer exists.")
        if state["status"] != "pending":
            raise ProposalStateError("PROPOSAL_ALREADY_CLOSED", "This proposal has already been handled.")
        raise ProposalStateError("PROPOSAL_EXPIRED", "This proposal has expired.")

    async def finish_execution(
        self,
        proposal_id: str,
        *,
        status: str,
        result: Any,
    ) -> bool:
        if status not in VALID_TERMINAL_STATES - {"cancelled", "expired"}:
            raise ValueError(f"Invalid execution result status: {status}")
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET status = $2, result = $3::jsonb, completed_at = now()
            WHERE id = $1 AND status = 'executing'
            RETURNING id
            """,
            proposal_id,
            status,
            json.dumps(result, ensure_ascii=False, default=str),
        )
        return row is not None

    async def close(self, proposal_id: str, status: str, reason: str) -> bool:
        if status not in {"cancelled", "expired"}:
            raise ValueError(f"Invalid proposal close status: {status}")
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET status = $2, result = $3::jsonb, completed_at = now()
            WHERE id = $1 AND status = 'pending'
            RETURNING id
            """,
            proposal_id,
            status,
            json.dumps({"message": reason}),
        )
        return row is not None

    async def fail_pending(
        self, proposal_id: str, message: str
    ) -> bool:
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET status = 'failed', result = $2::jsonb, completed_at = now()
            WHERE id = $1 AND status = 'pending'
            RETURNING id
            """,
            proposal_id,
            json.dumps({"message": message}),
        )
        return row is not None

    async def fail_interrupted_execution(self, proposal_id: str) -> bool:
        row = await self.pool.fetchrow(
            """
            UPDATE proposals
            SET status = 'failed', completed_at = now(),
                result = $2::jsonb
            WHERE id = $1 AND status = 'executing'
            RETURNING id
            """,
            proposal_id,
            json.dumps(
                {
                    "code": "EXECUTION_INTERRUPTED",
                    "message": (
                        "The bot stopped while this operation was executing. "
                        "Check the Discord resource before retrying."
                    ),
                }
            ),
        )
        return row is not None
