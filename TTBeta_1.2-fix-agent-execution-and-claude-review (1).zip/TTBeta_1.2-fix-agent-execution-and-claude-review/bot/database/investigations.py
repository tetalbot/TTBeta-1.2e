"""Persistent investigation and evidence-chain storage."""

from __future__ import annotations

import uuid
from typing import Any


class InvestigationRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def create(
        self, guild_id: int, created_by: int, title: str,
        *, subject_user_id: int | None = None,
    ) -> dict[str, Any]:
        investigation_id = str(uuid.uuid4())
        row = await self.pool.fetchrow(
            """
            INSERT INTO investigations
                (investigation_id, guild_id, created_by, subject_user_id, title)
            VALUES ($1,$2,$3,$4,$5)
            RETURNING *
            """,
            investigation_id, str(guild_id), str(created_by),
            str(subject_user_id) if subject_user_id else None, title[:200],
        )
        return dict(row)

    async def add_message_evidence(
        self, investigation_id: str, guild_id: int, added_by: int,
        *, message_id: int, channel_id: int, author_id: int, excerpt: str,
    ) -> dict[str, Any]:
        row = await self.pool.fetchrow(
            """
            INSERT INTO investigation_evidence (
                evidence_id, investigation_id, guild_id, added_by,
                source_type, source_id, channel_id, author_id, excerpt
            )
            SELECT $1, i.investigation_id, i.guild_id, $3,
                   'discord_message', $4, $5, $6, $7
            FROM investigations i
            WHERE i.investigation_id = $2 AND i.guild_id = $8 AND i.status = 'open'
            RETURNING *
            """,
            str(uuid.uuid4()), investigation_id, str(added_by),
            str(message_id), str(channel_id), str(author_id), excerpt[:2000],
            str(guild_id),
        )
        if row is None:
            raise ValueError("Investigation not found, not open, or belongs to another server.")
        return dict(row)

    async def add_url_evidence(
        self, investigation_id: str, guild_id: int, added_by: int,
        *, url: str, excerpt: str,
    ) -> dict[str, Any]:
        row = await self.pool.fetchrow(
            """
            INSERT INTO investigation_evidence (
                evidence_id, investigation_id, guild_id, added_by,
                source_type, source_url, excerpt
            )
            SELECT $1, i.investigation_id, i.guild_id, $3,
                   'public_url', $4, $5
            FROM investigations i
            WHERE i.investigation_id = $2 AND i.guild_id = $6 AND i.status = 'open'
            RETURNING *
            """,
            str(uuid.uuid4()), investigation_id, str(added_by),
            url[:2000], excerpt[:2000], str(guild_id),
        )
        if row is None:
            raise ValueError("Investigation not found, not open, or belongs to another server.")
        return dict(row)

    async def add_note_evidence(
        self, investigation_id: str, guild_id: int, added_by: int,
        *, source_id: str, excerpt: str,
    ) -> dict[str, Any]:
        row = await self.pool.fetchrow(
            """
            INSERT INTO investigation_evidence (
                evidence_id, investigation_id, guild_id, added_by,
                source_type, source_id, excerpt
            )
            SELECT $1, i.investigation_id, i.guild_id, $3,
                   'note', $4, $5
            FROM investigations i
            WHERE i.investigation_id = $2 AND i.guild_id = $6 AND i.status = 'open'
            RETURNING *
            """,
            str(uuid.uuid4()), investigation_id, str(added_by),
            source_id[:200], excerpt[:2000], str(guild_id),
        )
        if row is None:
            raise ValueError("Investigation not found, not open, or belongs to another server.")
        return dict(row)

    async def list_for_guild(self, guild_id: int, limit: int = 20) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT i.*, count(e.evidence_id)::int AS evidence_count
            FROM investigations i
            LEFT JOIN investigation_evidence e USING (investigation_id)
            WHERE i.guild_id = $1
            GROUP BY i.investigation_id
            ORDER BY i.created_at DESC
            LIMIT $2
            """,
            str(guild_id), max(1, min(int(limit), 50)),
        )
        return [dict(row) for row in rows]

    async def get(self, investigation_id: str, guild_id: int) -> dict[str, Any] | None:
        row = await self.pool.fetchrow(
            """
            SELECT * FROM investigations
            WHERE investigation_id = $1 AND guild_id = $2
            """,
            investigation_id, str(guild_id),
        )
        return dict(row) if row else None

    async def evidence(self, investigation_id: str, guild_id: int) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT e.* FROM investigation_evidence e
            JOIN investigations i USING (investigation_id)
            WHERE e.investigation_id = $1 AND i.guild_id = $2
            ORDER BY e.created_at
            LIMIT 200
            """,
            investigation_id, str(guild_id),
        )
        return [dict(row) for row in rows]

    async def close(self, investigation_id: str, guild_id: int, summary: str) -> bool:
        result = await self.pool.execute(
            """
            UPDATE investigations
            SET status = 'closed', summary = $3, closed_at = now(), updated_at = now()
            WHERE investigation_id = $1 AND guild_id = $2 AND status = 'open'
            """,
            investigation_id, str(guild_id), summary[:4000],
        )
        return result.endswith("1")
