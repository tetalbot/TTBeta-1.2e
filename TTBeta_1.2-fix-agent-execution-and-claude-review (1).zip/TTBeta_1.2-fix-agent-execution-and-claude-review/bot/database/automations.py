"""PostgreSQL persistence for approved event-driven automations."""

from __future__ import annotations

import json
import uuid
from typing import Any


def _decode(row: Any) -> dict[str, Any]:
    value = dict(row)
    for key in ("trigger_conditions", "action_sequence", "trigger_data", "actions_taken"):
        item = value.get(key)
        if isinstance(item, str):
            try:
                value[key] = json.loads(item)
            except json.JSONDecodeError:
                value[key] = {} if key != "action_sequence" else []
    return value


class AutomationRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def create(
        self,
        *,
        guild_id: int,
        created_by: int,
        name: str,
        description: str,
        trigger_event: str,
        trigger_conditions: dict[str, Any],
        action_sequence: list[dict[str, Any]],
        use_ai_reasoning: bool = False,
    ) -> dict[str, Any]:
        rule_id = str(uuid.uuid4())
        row = await self.pool.fetchrow(
            """
            INSERT INTO automation_rules (
                id, guild_id, created_by, name, description, trigger_event,
                trigger_conditions, action_sequence, use_ai_reasoning
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb,$9)
            RETURNING *
            """,
            rule_id, str(guild_id), str(created_by), name[:100], description[:1000],
            trigger_event, json.dumps(trigger_conditions, ensure_ascii=False),
            json.dumps(action_sequence, ensure_ascii=False), bool(use_ai_reasoning),
        )
        return _decode(row)

    async def get(self, rule_id: str, guild_id: int) -> dict[str, Any] | None:
        row = await self.pool.fetchrow(
            "SELECT * FROM automation_rules WHERE id=$1 AND guild_id=$2",
            rule_id, str(guild_id),
        )
        return _decode(row) if row else None

    async def list_for_guild(self, guild_id: int, *, limit: int = 25) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT * FROM automation_rules
            WHERE guild_id=$1
            ORDER BY created_at DESC
            LIMIT $2
            """,
            str(guild_id), max(1, min(int(limit), 50)),
        )
        return [_decode(row) for row in rows]

    async def list_enabled_for_guild(
        self, guild_id: int, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Return enabled automation rules owned by one guild."""
        rows = await self.pool.fetch(
            """
            SELECT * FROM automation_rules
            WHERE guild_id=$1 AND enabled=TRUE
            ORDER BY created_at DESC
            LIMIT $2
            """,
            str(guild_id), max(1, min(int(limit), 50)),
        )
        return [_decode(row) for row in rows]

    async def list_for_event(self, guild_id: int, trigger_event: str) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT * FROM automation_rules
            WHERE guild_id=$1 AND trigger_event=$2 AND enabled=TRUE
            ORDER BY created_at ASC
            """,
            str(guild_id), trigger_event,
        )
        return [_decode(row) for row in rows]

    async def disable(self, rule_id: str, guild_id: int) -> bool:
        row = await self.pool.fetchrow(
            """
            UPDATE automation_rules
            SET enabled=FALSE, updated_at=NOW()
            WHERE id=$1 AND guild_id=$2 AND enabled=TRUE
            RETURNING id
            """,
            rule_id, str(guild_id),
        )
        return row is not None

    async def begin_execution(
        self,
        *,
        rule_id: str,
        guild_id: int,
        event_key: str,
        trigger_data: dict[str, Any],
    ) -> str | None:
        execution_id = str(uuid.uuid4())
        row = await self.pool.fetchrow(
            """
            INSERT INTO automation_executions (
                id, rule_id, guild_id, event_key, trigger_data, result
            )
            VALUES ($1,$2,$3,$4,$5::jsonb,'running')
            ON CONFLICT (rule_id, event_key) DO NOTHING
            RETURNING id
            """,
            execution_id, rule_id, str(guild_id), event_key[:200],
            json.dumps(trigger_data, ensure_ascii=False, default=str),
        )
        return str(row["id"]) if row else None

    async def finish_execution(
        self,
        execution_id: str,
        *,
        rule_id: str,
        guild_id: int,
        result: str,
        actions_taken: list[dict[str, Any]],
        error: str | None = None,
    ) -> None:
        if result not in {"success", "failed", "skipped", "partial"}:
            raise ValueError(f"Invalid automation execution result: {result}")
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                updated = await connection.fetchrow(
                    """
                    UPDATE automation_executions
                    SET result=$2, actions_taken=$3::jsonb, error=$4, completed_at=NOW()
                    WHERE id=$1 AND result='running'
                    RETURNING id
                    """,
                    execution_id, result,
                    json.dumps(actions_taken, ensure_ascii=False, default=str),
                    error[:1500] if error else None,
                )
                # A stale-recovery worker may have already finalized this row.
                # Do not count a completion that did not win the state transition.
                if updated is not None:
                    await connection.execute(
                        """
                        UPDATE automation_rules
                        SET last_executed_at=NOW(),
                            execution_count=execution_count+1,
                            last_error=$3,
                            updated_at=NOW()
                        WHERE id=$1 AND guild_id=$2
                        """,
                        rule_id, str(guild_id), error[:1500] if error else None,
                    )

    async def recover_stale_executions(self, *, stale_after_minutes: int = 30) -> int:
        """Mark abandoned executions terminal without replaying uncertain side effects."""
        rows = await self.pool.fetch(
            """
            UPDATE automation_executions
            SET result='failed',
                error=COALESCE(
                    error,
                    'Execution was interrupted; action completion is uncertain. '
                    'Automatic replay was suppressed to avoid duplicate side effects.'
                ),
                completed_at=NOW()
            WHERE result='running'
              AND triggered_at < NOW() - make_interval(mins => $1)
            RETURNING id
            """,
            max(1, min(int(stale_after_minutes), 1440)),
        )
        return len(rows)

    async def prune_expired(self, *, batch_size: int = 5000) -> int:
        """Prune completed execution history using each guild's configured retention."""
        rows = await self.pool.fetch(
            """
            WITH expired AS (
                SELECT e.id
                FROM automation_executions e
                JOIN automation_rules r ON r.id=e.rule_id
                LEFT JOIN guild_settings gs ON gs.guild_id=r.guild_id
                WHERE e.result <> 'running'
                  AND e.triggered_at < NOW() - make_interval(
                      days => GREATEST(1, COALESCE(gs.retention_days, 90))
                  )
                ORDER BY e.triggered_at ASC
                LIMIT $1
            )
            DELETE FROM automation_executions e
            USING expired
            WHERE e.id=expired.id
            RETURNING e.id
            """,
            max(1, min(int(batch_size), 20_000)),
        )
        return len(rows)

    async def recent_executions(
        self, rule_id: str, guild_id: int, *, limit: int = 10
    ) -> list[dict[str, Any]]:
        rows = await self.pool.fetch(
            """
            SELECT e.* FROM automation_executions e
            JOIN automation_rules r ON r.id=e.rule_id
            WHERE e.rule_id=$1 AND e.guild_id=$2 AND r.guild_id=$2
            ORDER BY e.triggered_at DESC
            LIMIT $3
            """,
            rule_id, str(guild_id), max(1, min(int(limit), 25)),
        )
        return [_decode(row) for row in rows]
