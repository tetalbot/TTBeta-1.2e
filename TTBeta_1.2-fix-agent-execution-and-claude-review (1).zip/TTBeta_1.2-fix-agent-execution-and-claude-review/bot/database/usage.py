"""Durable, content-free Gemini token usage accounting."""

from __future__ import annotations

from typing import Any


class UsageRepository:
    def __init__(self, pool: Any) -> None:
        self.pool = pool

    async def record(
        self,
        *,
        guild_id: int | None,
        user_id: int | None,
        model: str,
        operation: str,
        prompt_tokens: int,
        candidate_tokens: int,
        total_tokens: int,
    ) -> None:
        await self.pool.execute(
            """
            INSERT INTO ai_usage (
                guild_id, user_id, model, operation,
                prompt_tokens, candidate_tokens, total_tokens
            ) VALUES ($1,$2,$3,$4,$5,$6,$7)
            """,
            str(guild_id) if guild_id is not None else None,
            str(user_id) if user_id is not None else None,
            model[:120], operation[:80],
            max(0, int(prompt_tokens)), max(0, int(candidate_tokens)),
            max(0, int(total_tokens)),
        )

    async def totals(self, guild_id: int, days: int = 30) -> dict[str, int]:
        row = await self.pool.fetchrow(
            """
            SELECT count(*)::int AS requests,
                   COALESCE(sum(prompt_tokens), 0)::bigint AS prompt_tokens,
                   COALESCE(sum(candidate_tokens), 0)::bigint AS candidate_tokens,
                   COALESCE(sum(total_tokens), 0)::bigint AS total_tokens
            FROM ai_usage
            WHERE guild_id = $1
              AND created_at >= now() - ($2::int * interval '1 day')
            """,
            str(guild_id), max(1, min(int(days), 365)),
        )
        return {key: int(row[key]) for key in (
            "requests", "prompt_tokens", "candidate_tokens", "total_tokens"
        )}
