"""Managed PostgreSQL connection setup; schema changes stay outside startup."""

from __future__ import annotations

import os
from typing import Any

import asyncpg


async def create_pool() -> Any:
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise RuntimeError(
            "DATABASE_URL is required for persistent proposals; refusing local fallback."
        )
    return await asyncpg.create_pool(
        database_url,
        min_size=1,
        max_size=8,
        command_timeout=15,
    )


async def verify_schema(pool: Any) -> None:
    try:
        async with pool.acquire() as connection:
            await connection.execute("""
                SELECT id, guild_id, user_id, operation, arguments, status,
                       created_at, expires_at, confirmed_at, executing_at,
                       completed_at, result, metadata
                FROM proposals LIMIT 0
            """)
            await connection.execute("""
                SELECT guild_id, name FROM guilds LIMIT 0
            """)
            await connection.execute("""
                SELECT channel_id, guild_id, name FROM channels LIMIT 0
            """)
            await connection.execute("""
                SELECT guild_id, user_id, display_name FROM members LIMIT 0
            """)
            await connection.execute("""
                SELECT message_id, guild_id, channel_id, author_id, content,
                       created_at, deleted_at FROM messages LIMIT 0
            """)
            await connection.execute("""
                SELECT attachment_id, message_id, filename FROM attachments LIMIT 0
            """)
            await connection.execute("""
                SELECT message_id, url FROM message_links LIMIT 0
            """)
            await connection.execute("""
                SELECT guild_id, retention_days, excluded_channel_ids,
                       rules_channel_id, logs_channel_id, staff_channel_id,
                       context_message_limit, rules_message_limit, staff_message_limit,
                       auto_execute_low_risk_actions, updated_at
                FROM guild_settings LIMIT 0
            """)
            await connection.execute("""
                SELECT task_id, guild_id, user_id, status FROM agent_tasks LIMIT 0
            """)
            await connection.execute("""
                SELECT execution_id, task_id, guild_id, tool_name, risk_level, status
                FROM tool_executions LIMIT 0
            """)
            await connection.execute("""
                SELECT source_id, guild_id, user_id, channel_id, role, content, created_at
                FROM conversation_messages LIMIT 0
            """)
            await connection.execute("""
                SELECT guild_id, case_id, moderator_id, target_id, action, status
                FROM moderation_cases LIMIT 0
            """)
            await connection.execute("""
                SELECT investigation_id, guild_id, created_by, subject_user_id,
                       title, status, summary, created_at
                FROM investigations LIMIT 0
            """)
            await connection.execute("""
                SELECT evidence_id, investigation_id, guild_id, added_by,
                       source_type, source_id, channel_id, author_id, excerpt, source_url
                FROM investigation_evidence LIMIT 0
            """)
            await connection.execute("""
                SELECT usage_id, guild_id, user_id, model, operation,
                       prompt_tokens, candidate_tokens, total_tokens, created_at
                FROM ai_usage LIMIT 0
            """)
            await connection.execute("""
                SELECT project_id, owner, creator, attribution, copyright, created_at
                FROM project_identity LIMIT 0
            """)
            await connection.execute("""
                SELECT id, guild_id, created_by, name, description, trigger_event,
                       trigger_conditions, action_sequence, use_ai_reasoning, enabled,
                       created_at, updated_at, last_executed_at, execution_count, last_error
                FROM automation_rules LIMIT 0
            """)
            await connection.execute("""
                SELECT id, rule_id, guild_id, event_key, triggered_at, completed_at,
                       trigger_data, result, actions_taken, error
                FROM automation_executions LIMIT 0
            """)

    except Exception as exc:
        raise RuntimeError(
            "The PostgreSQL schema is incomplete. Apply all migrations 0000 through 0007 "
            "with the project's database workflow before starting the bot."
        ) from exc
