"""Confirmed thread and forum operations."""

from __future__ import annotations

from typing import Any

import discord

from ..ai import ModerationProposal


def _thread(guild: discord.Guild, proposal: ModerationProposal) -> discord.Thread:
    raw_id = proposal.parameters.get("thread_id")
    try:
        thread_id = int(raw_id)
    except (TypeError, ValueError) as exc:
        raise ValueError("A valid thread_id is required.") from exc
    thread = guild.get_thread(thread_id)
    if thread is None:
        raise ValueError("The requested thread is not available in this server.")
    return thread


async def execute(
    interaction: discord.Interaction,
    source_message: discord.Message,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None:
        raise ValueError("Thread operations require a server.")
    action = proposal.action
    params = proposal.parameters
    if action == "create_thread":
        channel_id = int(params.get("channel_id") or source_message.channel.id)
        channel = guild.get_channel(channel_id)
        if not isinstance(channel, discord.TextChannel):
            raise ValueError("Choose a text channel for a new thread.")
        name = str(params.get("thread_name", "")).strip()[:100]
        if not name:
            raise ValueError("A thread name is required.")
        message_id = params.get("message_id")
        if message_id:
            parent = await channel.fetch_message(int(message_id))
            thread = await parent.create_thread(
                name=name,
                auto_archive_duration=int(params.get("auto_archive_duration", 1440)),
                reason=proposal.reason,
            )
        else:
            thread = await channel.create_thread(
                name=name,
                type=discord.ChannelType.public_thread,
                auto_archive_duration=int(params.get("auto_archive_duration", 1440)),
                reason=proposal.reason,
            )
        return f"Created thread **{thread.name}** ({thread.id}) in #{channel.name}."

    if action == "create_forum_post":
        channel_id = int(params.get("channel_id"))
        channel = guild.get_channel(channel_id)
        if not isinstance(channel, discord.ForumChannel):
            raise ValueError("The selected channel is not a forum.")
        name = str(params.get("thread_name", "")).strip()[:100]
        content = str(params.get("content", "")).strip()[:1900]
        if not name or not content:
            raise ValueError("A forum post needs a title and content.")
        thread, _ = await channel.create_thread(
            name=name, content=content, reason=proposal.reason
        )
        return f"Created forum post **{thread.name}** ({thread.id}) in #{channel.name}."

    thread = _thread(guild, proposal)
    if action == "archive_thread":
        await thread.edit(archived=True, reason=proposal.reason)
        return f"Archived thread **{thread.name}**."
    if action == "unarchive_thread":
        await thread.edit(archived=False, reason=proposal.reason)
        return f"Unarchived thread **{thread.name}**."
    if action == "lock_thread":
        await thread.edit(locked=True, reason=proposal.reason)
        return f"Locked thread **{thread.name}**."
    if action == "unlock_thread":
        await thread.edit(locked=False, reason=proposal.reason)
        return f"Unlocked thread **{thread.name}**."
    raise ValueError("Unsupported thread operation.")
