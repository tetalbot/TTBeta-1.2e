from __future__ import annotations

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason, send_dm


async def execute(
    interaction: discord.Interaction,
    member: discord.Member,
    proposal: ModerationProposal,
) -> str:
    reason = moderation_reason(proposal.reason)
    await send_dm(
        member,
        f"You were warned in **{member.guild.name}**.\nReason: {reason}",
    )
    return f"warned {member.mention} with reason: {reason}"