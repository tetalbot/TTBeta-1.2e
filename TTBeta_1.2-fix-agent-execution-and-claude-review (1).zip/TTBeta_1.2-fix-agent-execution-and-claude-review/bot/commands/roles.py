"""Role management actions requested through natural language."""

from __future__ import annotations

import re
from typing import Any

import discord

from ..ai import ModerationProposal
from ..entity_resolution import resolve_named_entity
from ..utils import moderation_reason


def _color(value: Any) -> discord.Colour | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    names = {
        "red": discord.Colour.red,
        "orange": discord.Colour.orange,
        "yellow": discord.Colour.gold,
        "green": discord.Colour.green,
        "blue": discord.Colour.blue,
        "purple": discord.Colour.purple,
        "pink": discord.Colour.magenta,
        "white": discord.Colour.from_rgb,
        "black": discord.Colour.from_rgb,
    }
    if text.startswith("#"):
        text = text[1:]
    if re.fullmatch(r"[0-9a-f]{6}", text):
        return discord.Colour(int(text, 16))
    if text in names:
        if text == "white":
            return discord.Colour.from_rgb(255, 255, 255)
        if text == "black":
            return discord.Colour.from_rgb(0, 0, 0)
        return names[text]()
    return None


def _permissions(
    value: Any,
    *,
    base: discord.Permissions | None = None,
) -> discord.Permissions | None:
    if not isinstance(value, dict):
        return None
    permissions = discord.Permissions(base.value if base is not None else 0)
    valid_flags = set(discord.Permissions.VALID_FLAGS)
    for name, enabled in value.items():
        key = str(name)
        if key not in valid_flags:
            raise ValueError(f"Unknown Discord permission: {key}.")
        if not isinstance(enabled, bool):
            raise ValueError(f"Permission {key} must be true or false.")
        setattr(permissions, key, enabled)
    return permissions


def resolve_role(guild: discord.Guild, parameters: dict[str, Any]) -> discord.Role | None:
    role_id = parameters.get("role_id")
    if role_id is not None:
        try:
            role = guild.get_role(int(role_id))
            if role:
                return role
        except (TypeError, ValueError):
            pass
    name = str(parameters.get("role_name", "")).strip()
    return resolve_named_entity(name, guild.roles, name_of=lambda role: role.name)


def list_roles(guild: discord.Guild) -> str:
    visible = [role for role in reversed(guild.roles) if not role.is_default()]
    if not visible:
        return "There are no custom roles."
    return "roles: " + ", ".join(f"{role.name} (`{role.id}`)" for role in visible)


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None:
        raise ValueError("This action must be used in a server.")
    params = proposal.parameters
    reason = moderation_reason(proposal.reason)
    action = proposal.action

    if action == "create_role":
        name = str(params.get("role_name", "")).strip()
        if not name:
            raise ValueError("A role name is required.")
        requested_permissions = _permissions(params.get("permissions")) or discord.Permissions.none()
        if requested_permissions.administrator and interaction.user.id != guild.owner_id:
            raise ValueError("Only the server owner can create an Administrator role.")
        role = await guild.create_role(
            name=name,
            colour=_color(params.get("color") or params.get("colour")) or discord.Colour.default(),
            permissions=requested_permissions,
            reason=reason,
        )
        return f"created role {role.mention}"
    if action == "list_roles":
        return list_roles(guild)

    role = resolve_role(guild, params)
    if role is None:
        requested = str(params.get("role_name", "")).strip()
        raise ValueError(
            f"I couldn't find a role close enough to **{requested}**. "
            "Tell me the role's name as it appears in the server."
        )
    if role.is_default():
        raise ValueError("The @everyone role cannot be changed or deleted.")
    if guild.me and role >= guild.me.top_role:
        raise ValueError("My highest role must be above the target role.")

    if action == "delete_role":
        name = role.name
        await role.delete(reason=reason)
        return f"deleted role **{name}**"
    if action == "modify_role":
        changes: dict[str, Any] = {}
        if params.get("name") or params.get("role_name_new"):
            changes["name"] = str(params.get("name") or params["role_name_new"]).strip()
        new_color = _color(params.get("color") or params.get("colour"))
        if new_color is not None:
            changes["colour"] = new_color
        requested_permissions = params.get("permissions")
        new_permissions = _permissions(requested_permissions, base=role.permissions)
        if new_permissions is not None:
            if (
                isinstance(requested_permissions, dict)
                and requested_permissions.get("administrator") is True
                and interaction.user.id != guild.owner_id
            ):
                raise ValueError("Only the server owner can grant the Administrator permission.")
            changes["permissions"] = new_permissions
        if not changes:
            raise ValueError("No role changes were specified.")
        await role.edit(reason=reason, **changes)
        return f"modified role **{role.name}**"

    members: list[discord.Member] = []
    ids = proposal.target_user_ids or ([proposal.target_user_id] if proposal.target_user_id else [])
    for member_id in ids:
        member = guild.get_member(member_id)
        if member is not None:
            members.append(member)
    if not members:
        raise ValueError("I could not find any target members.")
    if action == "assign_role":
        if role.permissions.administrator and interaction.user.id != guild.owner_id:
            raise ValueError("Only the server owner can assign an Administrator role.")
        for member in members:
            await member.add_roles(role, reason=reason)
        return f"assigned {role.mention} to {len(members)} member(s)"
    if action == "remove_role":
        for member in members:
            await member.remove_roles(role, reason=reason)
        return f"removed {role.mention} from {len(members)} member(s)"
    raise ValueError("Unsupported role action.")
