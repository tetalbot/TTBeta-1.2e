"""Confirmed invite and webhook administration."""

from __future__ import annotations

from typing import Any

import discord

from ..ai import ModerationProposal


async def execute(interaction: discord.Interaction, proposal: ModerationProposal) -> str:
    guild = interaction.guild
    requester = interaction.user
    bot_member = guild.me if guild else None
    if guild is None or not isinstance(requester, discord.Member) or bot_member is None:
        raise ValueError("This operation requires a current server context.")

    action = proposal.action
    params = proposal.parameters
    reason = proposal.reason

    if action == "create_invite":
        try:
            channel_id = int(params.get("channel_id"))
        except (TypeError, ValueError) as exc:
            raise ValueError("A valid channel_id is required.") from exc
        channel = guild.get_channel_or_thread(channel_id)
        if channel is None or not hasattr(channel, "create_invite"):
            raise ValueError("The invite channel is unavailable.")
        if not channel.permissions_for(requester).create_instant_invite:
            raise ValueError("You need Create Invite permission in that channel.")
        if not channel.permissions_for(bot_member).create_instant_invite:
            raise ValueError("The bot needs Create Invite permission in that channel.")
        max_age = max(0, min(int(params.get("max_age", 86400)), 604800))
        max_uses = max(0, min(int(params.get("max_uses", 0)), 100))
        invite = await channel.create_invite(
            max_age=max_age,
            max_uses=max_uses,
            temporary=bool(params.get("temporary", False)),
            unique=True,
            reason=reason,
        )
        return f"Created invite https://discord.gg/{invite.code} (expires in {max_age or 'never'} seconds; max uses {max_uses or 'unlimited'})."

    if action == "revoke_invite":
        code = str(params.get("invite_code", "")).strip()
        if not code or len(code) > 64:
            raise ValueError("A valid invite_code is required.")
        for invite in await guild.invites():
            if invite.code == code:
                await invite.delete(reason=reason)
                return f"Revoked invite {code}."
        raise ValueError("The invite was not found in this server.")

    if action == "create_webhook":
        try:
            channel_id = int(params.get("channel_id"))
        except (TypeError, ValueError) as exc:
            raise ValueError("A valid channel_id is required.") from exc
        channel = guild.get_channel_or_thread(channel_id)
        if channel is None or not hasattr(channel, "create_webhook"):
            raise ValueError("The webhook channel is unavailable.")
        if not channel.permissions_for(requester).manage_webhooks:
            raise ValueError("You need Manage Webhooks in that channel.")
        if not channel.permissions_for(bot_member).manage_webhooks:
            raise ValueError("The bot needs Manage Webhooks in that channel.")
        name = str(params.get("webhook_name", "")).strip()[:80]
        if not name:
            raise ValueError("A webhook name is required.")
        webhook = await channel.create_webhook(name=name, reason=reason)
        return f"Created webhook **{webhook.name}** ({webhook.id}) in #{channel.name}."

    if action in {"edit_webhook", "delete_webhook"}:
        try:
            webhook_id = int(params.get("webhook_id"))
        except (TypeError, ValueError) as exc:
            raise ValueError("A valid webhook_id is required.") from exc
        webhook = None
        for channel in guild.text_channels:
            if not channel.permissions_for(requester).manage_webhooks or not channel.permissions_for(bot_member).manage_webhooks:
                continue
            try:
                matches = await channel.webhooks()
            except (discord.Forbidden, discord.HTTPException):
                continue
            webhook = next((item for item in matches if item.id == webhook_id), None)
            if webhook is not None:
                break
        if webhook is None:
            raise ValueError("The webhook was not found in a channel both you and the bot can manage.")
        if action == "delete_webhook":
            await webhook.delete(reason=reason)
            return f"Deleted webhook {webhook_id}."
        name = str(params.get("webhook_name", "")).strip()[:80]
        if not name:
            raise ValueError("A webhook_name is required.")
        await webhook.edit(name=name, reason=reason)
        return f"Renamed webhook {webhook_id} to **{name}**."

    raise ValueError("Unsupported invite or webhook operation.")
