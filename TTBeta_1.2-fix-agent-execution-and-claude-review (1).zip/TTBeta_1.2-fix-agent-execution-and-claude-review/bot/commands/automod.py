"""Confirmed keyword-based AutoMod rule administration."""

from __future__ import annotations

from typing import Any

import discord

from ..ai import ModerationProposal


def _keywords(value: Any) -> list[str]:
    if isinstance(value, str):
        values = [item.strip() for item in value.split(",")]
    elif isinstance(value, list):
        values = [str(item).strip() for item in value]
    else:
        raise ValueError("keywords must be a comma-separated string or a list.")
    result = list(dict.fromkeys(item for item in values if item))
    if not result or len(result) > 100:
        raise ValueError("Provide between 1 and 100 unique keywords.")
    if any(len(item) > 60 for item in result):
        raise ValueError("Each AutoMod keyword must be 60 characters or fewer.")
    return result


def _actions(custom_message: str | None) -> list[discord.AutoModRuleAction]:
    message = (custom_message or "").strip()[:150]
    return [discord.AutoModRuleAction(custom_message=message or None)]


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None or not isinstance(interaction.user, discord.Member):
        raise ValueError("AutoMod administration requires a server member.")
    if not interaction.user.guild_permissions.manage_guild:
        raise ValueError("Manage Server permission is required.")
    bot_member = guild.me
    if bot_member is None or not bot_member.guild_permissions.manage_guild:
        raise ValueError("The bot needs Manage Server permission.")

    params = proposal.parameters
    action = proposal.action
    reason = proposal.reason

    if action == "create_automod_rule":
        name = str(params.get("rule_name", "")).strip()[:100]
        if not name:
            raise ValueError("A rule_name is required.")
        keywords = _keywords(params.get("keywords"))
        custom_message = params.get("custom_message")
        rule = await guild.create_automod_rule(
            name=name,
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=discord.AutoModTrigger(keyword_filter=keywords),
            actions=_actions(str(custom_message) if custom_message else None),
            enabled=bool(params.get("enabled", True)),
            reason=reason,
        )
        return f"Created AutoMod keyword rule **{rule.name}** ({rule.id}) with {len(keywords)} keyword(s)."

    try:
        rule_id = int(params.get("rule_id"))
    except (TypeError, ValueError) as exc:
        raise ValueError("A valid rule_id is required.") from exc
    rules = await guild.fetch_automod_rules()
    rule = next((item for item in rules if item.id == rule_id), None)
    if rule is None:
        raise ValueError("The AutoMod rule was not found in this server.")

    if action == "delete_automod_rule":
        await rule.delete(reason=reason)
        return f"Deleted AutoMod rule **{rule.name}** ({rule.id})."

    if action == "edit_automod_rule":
        if rule.trigger.type is not discord.AutoModRuleTriggerType.keyword:
            raise ValueError("Only keyword-based AutoMod rules can be edited by this operation.")
        changes: dict[str, Any] = {}
        if params.get("rule_name"):
            changes["name"] = str(params["rule_name"]).strip()[:100]
        if params.get("keywords") is not None:
            changes["trigger"] = discord.AutoModTrigger(
                keyword_filter=_keywords(params["keywords"]),
                allow_list=list(rule.trigger.allow_list),
                regex_patterns=list(rule.trigger.regex_patterns),
            )
        if params.get("custom_message") is not None:
            changes["actions"] = _actions(str(params["custom_message"]))
        if params.get("enabled") is not None:
            changes["enabled"] = bool(params["enabled"])
        if not changes:
            raise ValueError("Provide at least one AutoMod field to change.")
        await rule.edit(reason=reason, **changes)
        return f"Updated AutoMod rule **{rule.name}** ({rule.id})."

    raise ValueError("Unsupported AutoMod operation.")
