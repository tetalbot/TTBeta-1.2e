from __future__ import annotations

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason, send_dm


async def execute(
    interaction: discord.Interaction,
    member: discord.Member,
    proposal: ModerationProposal,
) -> str:
    reason = moderation_reason(proposal.reason)
    await send_dm(
        member,
        f"You were banned from **{member.guild.name}**.\nReason: {reason}",
    )
    await member.ban(reason=reason, delete_message_seconds=0)
    return f"banned {member.mention} with reason: {reason}"