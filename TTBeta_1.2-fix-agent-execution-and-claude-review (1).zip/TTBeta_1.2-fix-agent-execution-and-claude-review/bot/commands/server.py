"""Server-level administration actions."""

from __future__ import annotations

from typing import Any

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None:
        raise ValueError("This action must be used in a server.")
    params = proposal.parameters
    reason = moderation_reason(proposal.reason)
    action = proposal.action
    if action == "rename_server":
        name = str(params.get("server_name") or params.get("name") or "").strip()
        if not name:
            raise ValueError("A server name is required.")
        await guild.edit(name=name, reason=reason)
        return f"renamed the server to **{name}**"
    if action == "set_verification":
        value = str(params.get("verification_level", "")).lower()
        levels = {
            "none": discord.VerificationLevel.none,
            "low": discord.VerificationLevel.low,
            "medium": discord.VerificationLevel.medium,
            "high": discord.VerificationLevel.high,
            "highest": discord.VerificationLevel.highest,
        }
        if value not in levels:
            raise ValueError("Verification level must be none, low, medium, high, or highest.")
        await guild.edit(verification_level=levels[value], reason=reason)
        return f"set verification level to {value}"
    if action == "set_afk":
        channel = None
        value = params.get("afk_channel_id")
        if value is not None:
            channel = guild.get_channel(int(value))
        if channel is None and params.get("afk_channel_name"):
            name = str(params["afk_channel_name"]).casefold()
            channel = next((c for c in guild.voice_channels if c.name.casefold() == name), None)
        timeout = max(60, min(int(params.get("afk_timeout_seconds", guild.afk_timeout)), 900))
        if channel is not None and not isinstance(channel, discord.VoiceChannel):
            raise ValueError("The AFK channel must be a voice channel.")
        await guild.edit(afk_channel=channel, afk_timeout=timeout, reason=reason)
        return f"set AFK settings to {channel.name if channel else 'disabled'} and {timeout} seconds"
    raise ValueError("Unsupported server action.")