from __future__ import annotations

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason


async def execute(
    interaction: discord.Interaction,
    message: discord.Message,
    proposal: ModerationProposal,
) -> str:
    reason = moderation_reason(proposal.reason)
    await message.delete()
    return f"deleted message `{message.id}` with reason: {reason}"