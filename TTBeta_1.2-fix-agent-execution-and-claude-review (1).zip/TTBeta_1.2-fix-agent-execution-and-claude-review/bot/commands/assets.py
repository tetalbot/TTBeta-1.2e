"""Confirmed emoji and sticker management using visible Discord attachments."""

from __future__ import annotations

import io

import discord

from ..ai import ModerationProposal

MAX_EMOJI_BYTES = 256 * 1024
MAX_STICKER_BYTES = 512 * 1024


async def _attachment(
    guild: discord.Guild,
    requester: discord.Member,
    bot_member: discord.Member,
    params: dict,
    *,
    sticker: bool,
) -> tuple[bytes, str]:
    try:
        channel_id = int(params.get("channel_id"))
        message_id = int(params.get("message_id"))
        attachment_id = int(params.get("attachment_id"))
    except (TypeError, ValueError) as exc:
        raise ValueError("channel_id, message_id, and attachment_id are required.") from exc
    channel = guild.get_channel_or_thread(channel_id)
    if channel is None or not hasattr(channel, "fetch_message"):
        raise ValueError("The source channel is unavailable in this server.")
    for member, label in ((requester, "You"), (bot_member, "The bot")):
        permissions = channel.permissions_for(member)
        if not permissions.view_channel or not permissions.read_message_history:
            raise ValueError(f"{label} needs View Channel and Read Message History in the source channel.")
    message = await channel.fetch_message(message_id)
    if message.guild is None or message.guild.id != guild.id:
        raise ValueError("The source message is outside this server.")
    attachment = next((item for item in message.attachments if item.id == attachment_id), None)
    if attachment is None:
        raise ValueError("The attachment was not found on that message.")
    maximum = MAX_STICKER_BYTES if sticker else MAX_EMOJI_BYTES
    if attachment.size <= 0 or attachment.size > maximum:
        raise ValueError(f"The attachment must be between 1 byte and {maximum // 1024} KB.")
    content_type = (attachment.content_type or "").lower()
    if not content_type.startswith("image/"):
        raise ValueError("Only image attachments can be used.")
    if sticker and not attachment.filename.lower().endswith(".png"):
        raise ValueError("Sticker creation currently accepts PNG attachments only.")
    data = await attachment.read()
    if len(data) > maximum:
        raise ValueError("The downloaded attachment exceeds the asset size limit.")
    return data, attachment.filename


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    requester = interaction.user
    bot_member = guild.me if guild else None
    if guild is None or not isinstance(requester, discord.Member) or bot_member is None:
        raise ValueError("Server asset management requires a server member.")
    if not requester.guild_permissions.manage_emojis_and_stickers:
        raise ValueError("Manage Emojis and Stickers permission is required.")
    if not bot_member.guild_permissions.manage_emojis_and_stickers:
        raise ValueError("The bot needs Manage Emojis and Stickers permission.")

    params = proposal.parameters
    action = proposal.action
    reason = proposal.reason

    if action in {"create_emoji", "create_sticker"}:
        sticker = action == "create_sticker"
        data, filename = await _attachment(
            guild, requester, bot_member, params, sticker=sticker
        )
        name = str(params.get("asset_name", "")).strip()[:32]
        if not name or not name.replace("_", "").isalnum():
            raise ValueError("asset_name must contain only letters, numbers, or underscores.")
        if sticker:
            description = str(params.get("description", "")).strip()[:100]
            emoji = str(params.get("emoji", "✨")).strip()[:2]
            if not description:
                raise ValueError("A sticker description is required.")
            file = discord.File(io.BytesIO(data), filename=filename)
            sticker_obj = await guild.create_sticker(
                name=name, description=description, emoji=emoji,
                file=file, reason=reason,
            )
            return f"Created sticker **{sticker_obj.name}** ({sticker_obj.id})."
        emoji_obj = await guild.create_custom_emoji(name=name, image=data, reason=reason)
        return f"Created emoji :{emoji_obj.name}: ({emoji_obj.id})."

    try:
        asset_id = int(params.get("asset_id"))
    except (TypeError, ValueError) as exc:
        raise ValueError("A valid asset_id is required.") from exc

    if action == "delete_emoji":
        emoji_obj = guild.get_emoji(asset_id)
        if emoji_obj is None:
            raise ValueError("The emoji was not found in this server.")
        await emoji_obj.delete(reason=reason)
        return f"Deleted emoji **{emoji_obj.name}** ({asset_id})."

    if action == "delete_sticker":
        stickers = await guild.fetch_stickers()
        sticker_obj = next((item for item in stickers if item.id == asset_id), None)
        if sticker_obj is None:
            raise ValueError("The sticker was not found in this server.")
        await sticker_obj.delete(reason=reason)
        return f"Deleted sticker **{sticker_obj.name}** ({asset_id})."

    raise ValueError("Unsupported server asset operation.")
