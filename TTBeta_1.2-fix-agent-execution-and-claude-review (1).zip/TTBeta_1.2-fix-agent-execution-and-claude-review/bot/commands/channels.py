"""Channel and category management actions."""

from __future__ import annotations

from typing import Any

import discord

from ..ai import ModerationProposal
from ..entity_resolution import resolve_named_entity
from ..utils import moderation_reason


def _channel(guild: discord.Guild, params: dict[str, Any]) -> discord.abc.GuildChannel | None:
    value = params.get("channel_id")
    if value is not None:
        try:
            channel = guild.get_channel(int(value))
            if channel:
                return channel
        except (TypeError, ValueError):
            pass
    name = str(params.get("channel_name", "")).strip().lstrip("#")
    return resolve_named_entity(name, guild.channels, name_of=lambda channel: channel.name)


def _category(guild: discord.Guild, params: dict[str, Any]) -> discord.CategoryChannel | None:
    value = params.get("category_id")
    if value is not None:
        try:
            category = guild.get_channel(int(value))
            if isinstance(category, discord.CategoryChannel):
                return category
        except (TypeError, ValueError):
            pass
    name = str(params.get("category_name", "")).strip()
    return resolve_named_entity(name, guild.categories, name_of=lambda category: category.name)


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None:
        raise ValueError("This action must be used in a server.")
    params = proposal.parameters
    reason = moderation_reason(proposal.reason)
    action = proposal.action

    if action == "create_category":
        name = str(params.get("category_name") or params.get("name") or "").strip()
        if not name:
            raise ValueError("A category name is required.")
        category = await guild.create_category(name=name, reason=reason)
        return f"created category **{category.name}**"
    if action == "delete_category":
        category = _category(guild, params)
        if category is None:
            raise ValueError("I couldn't find a category close enough to that name.")
        await category.delete(reason=reason)
        return f"deleted category **{category.name}**"
    if action == "create_channel":
        name = str(params.get("channel_name") or params.get("name") or "").strip()
        channel_type = str(params.get("channel_type", "text")).lower()
        category_name = str(params.get("category_name", "")).strip()
        category = _category(guild, params)
        if not name:
            raise ValueError("A channel name is required.")
        if category_name and category is None:
            raise ValueError(f"I couldn't find a category close enough to **{category_name}**.")
        if channel_type == "voice":
            channel = await guild.create_voice_channel(name, category=category, reason=reason)
        elif channel_type == "forum" and hasattr(guild, "create_forum"):
            channel = await guild.create_forum(name, category=category, reason=reason)
        else:
            channel = await guild.create_text_channel(
                name,
                category=category,
                topic=params.get("topic"),
                reason=reason,
            )
        return f"created {channel_type} channel {channel.mention}"

    channel = _channel(guild, params)
    if channel is None:
        requested = str(params.get("channel_name", "")).strip()
        raise ValueError(f"I couldn't find a channel close enough to **{requested}**.")
    if action == "delete_channel":
        name = channel.name
        await channel.delete(reason=reason)
        return f"deleted channel **{name}**"
    if action in {"lock_channel", "unlock_channel"}:
        everyone = guild.default_role
        overwrite = channel.overwrites_for(everyone)
        overwrite.send_messages = action == "unlock_channel"
        await channel.set_permissions(everyone, overwrite=overwrite, reason=reason)
        return f"{'unlocked' if action == 'unlock_channel' else 'locked'} #{channel.name}"
    if action == "set_slowmode":
        seconds = max(0, min(int(params.get("slowmode_seconds", 0)), 21600))
        if not isinstance(channel, discord.TextChannel):
            raise ValueError("Slowmode is only supported on text channels.")
        await channel.edit(slowmode_delay=seconds, reason=reason)
        return f"set slowmode for #{channel.name} to {seconds} seconds"
    if action == "modify_channel":
        changes: dict[str, Any] = {}
        if params.get("name"):
            changes["name"] = str(params["name"]).strip()
        if "topic" in params and isinstance(channel, discord.TextChannel):
            changes["topic"] = params["topic"]
        sync_permissions = params.get("sync_permissions") is True
        category = None
        if params.get("category_name") or params.get("category_id"):
            category = _category(guild, params)
            if category is None:
                requested = str(params.get("category_name", "")).strip()
                raise ValueError(f"I couldn't find a category close enough to **{requested}**.")
            changes["category"] = category
        if sync_permissions:
            # Sync only with the channel's actual parent (or the parent being
            # assigned in this same edit). Never accept an arbitrary overwrite source.
            parent = category or getattr(channel, "category", None)
            if parent is None:
                raise ValueError(
                    "This channel is not inside a category. Move it into a category first, "
                    "or specify its category in the same request."
                )
            changes["sync_permissions"] = True
        if not changes:
            raise ValueError("No channel changes were specified.")
        updated = await channel.edit(reason=reason, **changes)
        if sync_permissions and not getattr(updated, "permissions_synced", False):
            raise RuntimeError(
                f"Discord accepted the edit but permission synchronisation could not be verified for #{channel.name}."
            )
        if sync_permissions:
            parent_name = (category or getattr(channel, "category", None)).name
            return f"synchronised permissions for #{updated.name} with category **{parent_name}**"
        return f"modified #{updated.name}"
    raise ValueError("Unsupported channel action.")
