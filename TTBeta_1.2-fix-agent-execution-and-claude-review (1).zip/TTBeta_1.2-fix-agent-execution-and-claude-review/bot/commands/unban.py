from __future__ import annotations

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason


async def execute(
    interaction: discord.Interaction,
    user: discord.User,
    proposal: ModerationProposal,
) -> str:
    reason = moderation_reason(proposal.reason)
    await interaction.guild.unban(user, reason=reason)  # type: ignore[union-attr]
    return f"unbanned {user.mention} with reason: {reason}"