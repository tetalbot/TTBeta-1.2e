from __future__ import annotations

import discord

from ..ai import ModerationProposal
from ..utils import moderation_reason, send_dm


async def execute(
    interaction: discord.Interaction,
    member: discord.Member,
    proposal: ModerationProposal,
) -> str:
    reason = moderation_reason(proposal.reason)
    await member.timeout(None, reason=reason)
    await send_dm(
        member,
        f"Your mute was removed in **{member.guild.name}**.\nReason: {reason}",
    )
    return f"unmuted {member.mention} with reason: {reason}"