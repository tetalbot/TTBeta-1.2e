"""Confirmed scheduled-event administration."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import discord

from ..ai import ModerationProposal


def _parse_datetime(value: Any, field: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be an ISO-8601 datetime.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} must be a valid ISO-8601 datetime.") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field} must include a timezone offset.")
    return parsed


async def execute(
    interaction: discord.Interaction,
    proposal: ModerationProposal,
) -> str:
    guild = interaction.guild
    if guild is None:
        raise ValueError("Scheduled events require a server.")
    params = proposal.parameters
    action = proposal.action

    if action == "create_event":
        name = str(params.get("event_name", "")).strip()[:100]
        location = str(params.get("location", "")).strip()[:100]
        description = str(params.get("description", "")).strip()[:1000]
        start = _parse_datetime(params.get("start_time"), "start_time")
        end = _parse_datetime(params.get("end_time"), "end_time")
        if not name or not location:
            raise ValueError("An event name and external location are required.")
        if end <= start:
            raise ValueError("The event end time must be after its start time.")
        if start <= discord.utils.utcnow():
            raise ValueError("The event start time must be in the future.")
        event = await guild.create_scheduled_event(
            name=name,
            description=description or None,
            start_time=start,
            end_time=end,
            entity_type=discord.EntityType.external,
            privacy_level=discord.PrivacyLevel.guild_only,
            location=location,
            reason=proposal.reason,
        )
        return f"Created scheduled event **{event.name}** ({event.id})."

    try:
        event_id = int(params.get("event_id"))
    except (TypeError, ValueError) as exc:
        raise ValueError("A valid event_id is required.") from exc
    event = next((item for item in await guild.fetch_scheduled_events() if item.id == event_id), None)
    if event is None:
        raise ValueError("The scheduled event was not found in this server.")

    if action == "delete_event":
        await event.delete(reason=proposal.reason)
        return f"Deleted scheduled event **{event.name}**."
    if action == "edit_event":
        changes: dict[str, Any] = {}
        if params.get("event_name"):
            changes["name"] = str(params["event_name"]).strip()[:100]
        if params.get("description") is not None:
            changes["description"] = str(params["description"])[:1000]
        if params.get("start_time"):
            changes["start_time"] = _parse_datetime(params["start_time"], "start_time")
        if params.get("end_time"):
            changes["end_time"] = _parse_datetime(params["end_time"], "end_time")
        if params.get("location"):
            changes["location"] = str(params["location"]).strip()[:100]
        if not changes:
            raise ValueError("Provide at least one event field to change.")
        if "start_time" in changes and "end_time" in changes:
            if changes["end_time"] <= changes["start_time"]:
                raise ValueError("The event end time must be after its start time.")
        await event.edit(reason=proposal.reason, **changes)
        return f"Updated scheduled event **{event.name}**."
    raise ValueError("Unsupported scheduled-event operation.")
