from __future__ import annotations

from datetime import timedelta

import discord

from ..ai import ModerationProposal
from ..utils import clamp_timeout, format_duration, moderation_reason, send_dm


async def execute(
    interaction: discord.Interaction,
    member: discord.Member,
    proposal: ModerationProposal,
) -> str:
    minutes = clamp_timeout(proposal.duration_minutes)
    reason = moderation_reason(proposal.reason)
    await member.timeout(timedelta(minutes=minutes), reason=reason)
    await send_dm(
        member,
        f"You were muted in **{member.guild.name}** for {format_duration(minutes)}.\n"
        f"Reason: {reason}",
    )
    return (
        f"muted {member.mention} for {format_duration(minutes)} "
        f"with reason: {reason}"
    )