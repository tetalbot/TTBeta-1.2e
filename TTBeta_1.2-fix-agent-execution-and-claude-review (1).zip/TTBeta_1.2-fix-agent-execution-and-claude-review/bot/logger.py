"""Moderation audit log delivery."""

from __future__ import annotations

import discord

from .ai import ModerationProposal
from .config import GuildConfig


async def post_log(
    guild: discord.Guild,
    config: GuildConfig,
    moderator: discord.abc.User,
    proposal: ModerationProposal,
    outcome: str,
) -> None:
    if not config.logs_channel_id:
        return
    channel = guild.get_channel(config.logs_channel_id)
    if not isinstance(channel, discord.TextChannel):
        return

    embed = discord.Embed(
        title="AI moderation action",
        description=outcome,
        color=discord.Color.blurple(),
        timestamp=discord.utils.utcnow(),
    )
    embed.add_field(name="Moderator", value=f"{moderator} (`{moderator.id}`)", inline=False)
    embed.add_field(
        name="AI proposal",
        value=proposal.summary or "No summary provided",
        inline=False,
    )
    embed.add_field(
        name="Rule reference",
        value=proposal.rule_reference or "Not specified",
        inline=True,
    )
    embed.add_field(
        name="Evidence",
        value=", ".join(str(item) for item in proposal.evidence_message_ids)
        or "None recorded",
        inline=True,
    )
    await channel.send(embed=embed)