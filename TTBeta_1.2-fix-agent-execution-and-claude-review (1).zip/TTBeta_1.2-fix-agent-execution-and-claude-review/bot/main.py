"""Discord gateway entry point and conversational moderation flow."""

from __future__ import annotations

import asyncio
import re
import json
import logging
import os
import traceback
import uuid
from dataclasses import dataclass, field
from types import SimpleNamespace
from datetime import datetime, timedelta, timezone
from typing import Any

import asyncpg
import discord
from discord import app_commands

from .ai import GeminiInterpreter, ModerationProposal
from .capabilities import generate_agent_capabilities
from .agent.orchestrator import AgentOrchestrator
from .agent.discord_api import execute_discord_api_operation, is_read_only_operation
from .commands import assets, automod, ban, channels, delete, events, kick, mute, resources, roles, server, threads, unban, unmute, warn
from .config import (
    CaseStore,
    ConfigStore,
    GuildConfig,
    ModerationCase,
    load_case_store,
    load_store,
)
from .context import MessageContext, read_channel_messages
from .database.connection import create_pool, verify_schema
from .database.proposals import ProposalRepository, ProposalStateError
from .database.automations import AutomationRepository
from .automations.engine import (
    account_age_days,
    conditions_match,
    render_event_placeholders,
    ensure_automation_role_safe,
    validate_automation_definition,
    resolve_automation_rule,
    SUPPORTED_TRIGGER_EVENTS,
)
from .automations.views import AutomationRuleConfirmationView
from .database.context import ContextRepository
from .database.settings import GuildSettingsRepository, ModerationCaseRepository
from .database.conversations import ConversationRepository
from .database.investigations import InvestigationRepository
from .database.usage import UsageRepository
from .investigations.link_inspector import inspect_public_url
from .logger import post_log
from .memory import ConversationStore
from .search import MessageCandidate, scan_guild_messages
from .security.authorization import authorize_operation, OWNER_USER_ID
from .security.ownership import verify_ownership, verify_database_identity, OwnershipIntegrityError
from .security.risk_policy import (
    LOW_RISK_ACTIONS,
    classify_action_risk,
    requires_confirmation,
)
from .tools.dispatcher import ToolResult
from .tools.moderation import build_moderation_registry
from .tools.diagnostics import build_diagnostics_registry
from .diagnostics.log_buffer import install_buffer_handler
from .tools.discord_read import register_read_tools
from .utils import (
    ACTION_NAMES,
    can_moderate,
    format_duration,
    moderation_reason,
    safe_reason,
    strip_bot_mention,
)


from .automations.intents import (
    AUTOMATION_INTENT_PATTERNS,
    looks_like_automation_request as _looks_like_automation_request,
)


LOGGER = logging.getLogger("ai-moderator")
MAX_BATCH_TARGETS = 20

INTENTS = discord.Intents.default()
INTENTS.message_content = True
INTENTS.members = True
INTENTS.reactions = True
INTENTS.voice_states = True


@dataclass
class Conversation:
    messages: list[dict[str, str]] = field(default_factory=list)
    last_channel_id: int | None = None
    last_bot_message_id: int | None = None
    pending_proposal: ModerationProposal | None = None


@dataclass
class ToolExecutionContext:
    bot: "ModerationBot"
    interaction: discord.Interaction | None
    source_message: discord.Message
    guild: discord.Guild | None = None
    requester: discord.Member | None = None
    bot_member: discord.Member | None = None
    auto_executor: Any | None = None


def pending_proposal_for_turn(
    conversation: Conversation, *, is_reply_to_bot: bool
) -> ModerationProposal | None:
    """Carry a clarification forward only for a direct reply in this process."""
    if not is_reply_to_bot:
        conversation.pending_proposal = None
        return None
    return conversation.pending_proposal


def _discord_failure_reason(exc: Exception) -> str:
    if isinstance(exc, discord.Forbidden):
        return "Discord denied the operation (check bot permissions and target access)."
    if isinstance(exc, discord.NotFound):
        return "The target no longer exists."
    if isinstance(exc, discord.HTTPException):
        return f"Discord API request failed (HTTP {exc.status})."
    if isinstance(exc, ValueError):
        return str(exc)
    return "The operation failed unexpectedly."


def _batch_outcome(
    successes: list[str],
    failures: list[tuple[str, str]],
) -> str:
    grouped_failures: dict[str, list[str]] = {}
    for target, reason in failures:
        grouped_failures.setdefault(reason, []).append(target)
    failure_lines = [
        f"{reason} Targets: {', '.join(targets)}"
        for reason, targets in grouped_failures.items()
    ]
    total = len(successes) + len(failures)
    if not successes:
        details = "; ".join(failure_lines)
        raise ValueError(f"No targets were changed ({total} failed). {details}"[:1800])

    status = "Completed successfully" if not failures else "Partially completed"
    lines = [f"{status}: {len(successes)}/{total} succeeded."]
    if successes:
        lines.append("Succeeded: " + ", ".join(successes))
    if failures:
        lines.append("Failed: " + "; ".join(failure_lines))
    return "\n".join(lines)[:1850]


class ConfirmationView(discord.ui.View):
    def __init__(
        self,
        bot: "ModerationBot",
        proposal_id: str,
        initiator_id: int,
        guild_id: int,
    ) -> None:
        super().__init__(timeout=None)
        self.bot = bot
        self.proposal_id = proposal_id
        self.initiator_id = initiator_id
        self.guild_id = guild_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.initiator_id:
            await interaction.response.send_message(
                "Only the moderator who requested this action can confirm it.",
                ephemeral=True,
            )
            return False
        if interaction.guild is None or interaction.guild.id != self.guild_id:
            await interaction.response.send_message(
                "This proposal can only be used in its original server.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(
        label="Confirm action",
        style=discord.ButtonStyle.danger,
        custom_id="tetal:proposal:confirm",
    )
    async def confirm(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        await interaction.response.defer()
        repository = self.bot.proposal_repo
        if repository is None:
            await interaction.followup.send(
                "Persistent proposal storage is unavailable. No action was taken.",
                ephemeral=True,
            )
            return
        try:
            record = await repository.claim_for_execution(
                self.proposal_id,
                guild_id=self.guild_id,
                user_id=interaction.user.id,
            )
        except ProposalStateError as exc:
            await interaction.followup.send(str(exc), ephemeral=True)
            if interaction.message:
                await interaction.message.edit(view=None)
            return

        metadata = record.get("metadata") or {}
        case_id = metadata.get("case_id")
        proposal = ModerationProposal.from_payload(record.get("arguments") or {})
        try:
            source_message = await self.bot.fetch_source_message(
                interaction.guild,
                metadata,
            )
        except (discord.Forbidden, discord.HTTPException):
            LOGGER.exception("Could not recover source message for proposal %s", self.proposal_id)
            source_message = None
        if source_message is None:
            reason = "The original request message is unavailable; no action was taken."
            await repository.finish_execution(
                self.proposal_id,
                status="failed",
                result={"message": reason},
            )
            await self.bot.close_case_if_present(case_id, "failed", reason)
            if interaction.message:
                await interaction.message.edit(content=reason, view=None)
            return

        try:
            outcome = await self.bot.execute_proposal(
                interaction, source_message, proposal
            )
        except (discord.Forbidden, discord.HTTPException, ValueError) as exc:
            reason = _discord_failure_reason(exc)
            LOGGER.warning("Moderation action failed: %s", reason)
            await repository.finish_execution(
                self.proposal_id,
                status="failed",
                result={"message": reason},
            )
            await self.bot.close_case_if_present(case_id, "failed", reason)
            if interaction.message:
                await interaction.message.edit(
                    content=f"I could not complete that action: {reason}", view=None
                )
            return
        except Exception:
            LOGGER.exception("Unexpected error executing moderation proposal")
            reason = "An unexpected error occurred; check the server before retrying."
            await repository.finish_execution(
                self.proposal_id,
                status="failed",
                result={"message": reason},
            )
            await self.bot.close_case_if_present(case_id, "failed", reason)
            if interaction.message:
                await interaction.message.edit(content=reason, view=None)
            return

        status = (
            "partially_completed"
            if outcome.startswith("Partially completed:")
            else "completed"
        )
        await repository.finish_execution(
            self.proposal_id,
            status=status,
            result={"outcome": outcome},
        )
        await self.bot.confirm_case_if_present(case_id, outcome, status)
        try:
            if interaction.message:
                await interaction.message.edit(content=f"Confirmed. {outcome}", view=None)
        except discord.HTTPException:
            LOGGER.exception("Could not update confirmation message for proposal %s", self.proposal_id)
        try:
            await post_log(
                interaction.guild,
                self.bot.config_store.get(self.guild_id),
                interaction.user,
                proposal,
                outcome,
            )
        except discord.HTTPException:
            LOGGER.exception("Could not write Discord log for proposal %s", self.proposal_id)

        if proposal.continue_after_confirmation and proposal.continuation_depth < 4:
            try:
                await self.bot._resume_agent_after_confirmation(
                    interaction, source_message, proposal, outcome
                )
            except Exception:
                LOGGER.exception("Failed to resume confirmed multi-step proposal")
                await interaction.channel.send(
                    "The confirmed step succeeded, but I could not safely continue. Please submit the remaining step separately.",
                    allowed_mentions=discord.AllowedMentions.none(),
                )
        elif proposal.continue_after_confirmation:
            await interaction.channel.send(
                "The confirmed action succeeded, but I reached the safe multi-step continuation limit. "
                "Please submit the remaining steps as a separate request.",
                allowed_mentions=discord.AllowedMentions.none(),
            )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        await interaction.response.defer()
        repository = self.bot.proposal_repo
        if repository is None:
            await interaction.followup.send(
                "Persistent proposal storage is unavailable.", ephemeral=True
            )
            return
        record = await repository.get(self.proposal_id)
        if record is None:
            await interaction.followup.send(
                "This proposal no longer exists.", ephemeral=True
            )
            return
        closed = await repository.close(
            self.proposal_id,
            "cancelled",
            "Cancelled by the initiating moderator.",
        )
        if not closed:
            await interaction.followup.send(
                "This proposal has already been handled.", ephemeral=True
            )
            return
        await self.bot.close_case_if_present(
            (record.get("metadata") or {}).get("case_id"),
            "cancelled",
            "Cancelled by the initiating moderator.",
        )
        if interaction.message:
            await interaction.message.edit(
                content="Cancelled. No action was taken.", view=None
            )


class BatchConfirmationView(discord.ui.View):
    """Persistent per-action controls for one ordered multi-action plan."""

    def __init__(
        self,
        bot: "ModerationBot",
        batch_id: str,
        initiator_id: int,
        guild_id: int,
        records: list[dict[str, Any]],
    ) -> None:
        super().__init__(timeout=None)
        self.bot = bot
        self.batch_id = batch_id
        self.initiator_id = initiator_id
        self.guild_id = guild_id
        previous_complete = True
        for index, record in enumerate(records):
            status = str(record.get("status", "pending"))
            row = index // 2
            proposal = ModerationProposal.from_payload(record.get("arguments") or {})
            confirm = discord.ui.Button(
                label=f"Confirm {index + 1}",
                style=discord.ButtonStyle.success,
                custom_id=f"tetal:batch:{batch_id}:{index}:confirm",
                row=row,
                disabled=(status != "pending" or not previous_complete),
            )
            confirm.callback = self._confirm_callback(str(record["id"]), index)
            self.add_item(confirm)
            cancel = discord.ui.Button(
                label=f"Cancel {index + 1}",
                style=discord.ButtonStyle.secondary,
                custom_id=f"tetal:batch:{batch_id}:{index}:cancel",
                row=row,
                disabled=(status != "pending"),
            )
            cancel.callback = self._cancel_callback(str(record["id"]), index)
            self.add_item(cancel)
            previous_complete = previous_complete and status == "completed"

        cancel_all = discord.ui.Button(
            label="Cancel remaining",
            style=discord.ButtonStyle.danger,
            custom_id=f"tetal:batch:{batch_id}:cancel-all",
            row=4,
            disabled=not any(record.get("status") == "pending" for record in records),
        )
        cancel_all.callback = self._cancel_all_callback()
        self.add_item(cancel_all)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.initiator_id:
            await interaction.response.send_message(
                "Only the moderator who requested this plan can approve or cancel it.",
                ephemeral=True,
            )
            return False
        if interaction.guild is None or interaction.guild.id != self.guild_id:
            await interaction.response.send_message(
                "This plan can only be used in its original server.",
                ephemeral=True,
            )
            return False
        return True

    def _confirm_callback(self, proposal_id: str, index: int):
        async def callback(interaction: discord.Interaction) -> None:
            await self._confirm_action(interaction, proposal_id, index)
        return callback

    def _cancel_callback(self, proposal_id: str, index: int):
        async def callback(interaction: discord.Interaction) -> None:
            await self._cancel_action(interaction, proposal_id, index)
        return callback

    def _cancel_all_callback(self):
        async def callback(interaction: discord.Interaction) -> None:
            await self._cancel_remaining(interaction)
        return callback

    async def _refresh(self, interaction: discord.Interaction) -> None:
        repository = self.bot.proposal_repo
        if repository is None or interaction.message is None:
            return
        records = await repository.get_batch(self.batch_id)
        if not records:
            await interaction.message.edit(content="This action queue no longer exists.", view=None)
            return
        lines = ["**Action queue**"]
        for index, record in enumerate(records):
            proposal = ModerationProposal.from_payload(record.get("arguments") or {})
            status = str(record.get("status", "pending"))
            result = record.get("result") or {}
            outcome = result.get("outcome") or result.get("message")
            if status == "pending" and index and any(
                previous.get("status") != "completed" for previous in records[:index]
            ):
                display_status = "Blocked until earlier steps complete"
            else:
                display_status = status.replace("_", " ").title()
            detail = str(outcome or "")
            lines.append(f"{index + 1}. **{proposal.action or 'Action'}**: {display_status}" + (f" · {detail[:100]}" if detail else ""))
        terminal = {"completed", "partially_completed", "failed", "cancelled", "expired"}
        is_finished = all(record.get("status") in terminal for record in records)
        view = None if is_finished else BatchConfirmationView(
            self.bot, self.batch_id, self.initiator_id, self.guild_id, records
        )
        await interaction.message.edit(content="\n".join(lines)[:1900], view=view)

    async def _confirm_action(
        self,
        interaction: discord.Interaction,
        proposal_id: str,
        index: int,
    ) -> None:
        await interaction.response.defer()
        repository = self.bot.proposal_repo
        if repository is None:
            await interaction.followup.send("Persistent proposal storage is unavailable. No action was taken.", ephemeral=True)
            return
        records = await repository.get_batch(self.batch_id)
        if index >= len(records) or str(records[index].get("id")) != proposal_id:
            await interaction.followup.send("This queued action could not be verified.", ephemeral=True)
            return
        if any(record.get("status") != "completed" for record in records[:index]):
            await interaction.followup.send("Complete the earlier queued actions first. Dependent actions cannot run out of order.", ephemeral=True)
            return
        try:
            record = await repository.claim_for_execution(
                proposal_id, guild_id=self.guild_id, user_id=interaction.user.id
            )
        except ProposalStateError as exc:
            await interaction.followup.send(str(exc), ephemeral=True)
            await self._refresh(interaction)
            return

        metadata = record.get("metadata") or {}
        case_id = metadata.get("case_id")
        proposal = ModerationProposal.from_payload(record.get("arguments") or {})
        try:
            source_message = await self.bot.fetch_source_message(interaction.guild, metadata)
        except Exception:
            LOGGER.exception("Could not recover source message for queued action %s", proposal_id)
            source_message = None
        if source_message is None:
            reason = "The original request message is unavailable; no action was taken."
            await repository.finish_execution(proposal_id, status="failed", result={"message": reason})
            await self.bot.close_case_if_present(case_id, "failed", reason)
            await self._block_following(records, index, reason)
            await self._refresh(interaction)
            return
        try:
            outcome = await self.bot.execute_proposal(interaction, source_message, proposal)
        except Exception as exc:
            reason = _discord_failure_reason(exc)
            LOGGER.warning("Queued action %s failed: %s", proposal_id, reason, exc_info=True)
            await repository.finish_execution(proposal_id, status="failed", result={"message": reason})
            await self.bot.close_case_if_present(case_id, "failed", reason)
            await self._block_following(records, index, f"Blocked because action {index + 1} failed: {reason}")
            await self._refresh(interaction)
            return

        status = "partially_completed" if outcome.startswith("Partially completed:") else "completed"
        await repository.finish_execution(proposal_id, status=status, result={"outcome": outcome})
        await self.bot.confirm_case_if_present(case_id, outcome, status)
        try:
            await post_log(
                interaction.guild,
                self.bot.config_store.get(self.guild_id),
                interaction.user,
                proposal,
                outcome,
            )
        except discord.HTTPException:
            LOGGER.exception("Could not write Discord log for queued action %s", proposal_id)
        await self._refresh(interaction)

    async def _block_following(
        self,
        records: list[dict[str, Any]],
        index: int,
        reason: str,
    ) -> None:
        repository = self.bot.proposal_repo
        if repository is None:
            return
        for record in records[index + 1:]:
            if record.get("status") != "pending":
                continue
            proposal_id = str(record["id"])
            if await repository.close(proposal_id, "cancelled", reason):
                await self.bot.close_case_if_present(
                    (record.get("metadata") or {}).get("case_id"),
                    "cancelled",
                    reason,
                )

    async def _cancel_action(
        self,
        interaction: discord.Interaction,
        proposal_id: str,
        index: int,
    ) -> None:
        await interaction.response.defer()
        repository = self.bot.proposal_repo
        if repository is None:
            await interaction.followup.send("Persistent proposal storage is unavailable.", ephemeral=True)
            return
        records = await repository.get_batch(self.batch_id)
        if index >= len(records) or str(records[index].get("id")) != proposal_id:
            await interaction.followup.send("This queued action could not be verified.", ephemeral=True)
            return
        reason = f"Action {index + 1} and its dependent steps were cancelled by the initiating moderator."
        for record in records[index:]:
            if record.get("status") == "pending":
                if await repository.close(str(record["id"]), "cancelled", reason):
                    await self.bot.close_case_if_present(
                        (record.get("metadata") or {}).get("case_id"),
                        "cancelled",
                        reason,
                    )
        await self._refresh(interaction)

    async def _cancel_remaining(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        repository = self.bot.proposal_repo
        if repository is None:
            await interaction.followup.send("Persistent proposal storage is unavailable.", ephemeral=True)
            return
        records = await repository.get_batch(self.batch_id)
        for record in records:
            if record.get("status") == "pending":
                if await repository.close(
                    str(record["id"]), "cancelled", "Remaining actions cancelled by the initiating moderator."
                ):
                    await self.bot.close_case_if_present(
                        (record.get("metadata") or {}).get("case_id"),
                        "cancelled",
                        "Remaining actions cancelled by the initiating moderator.",
                    )
        await self._refresh(interaction)


class ModerationBot(discord.Client):
    def __init__(self) -> None:
        super().__init__(intents=INTENTS)
        self.tree = app_commands.CommandTree(self)
        self.tree.on_error = self._on_app_command_error
        self.config_store = load_store()
        self.case_store: CaseStore = load_case_store()
        self.memory_store = ConversationStore()  # legacy SQLite importer/source only
        capability_reference = generate_agent_capabilities()
        self.interpreter = GeminiInterpreter(capability_reference=capability_reference)
        self.database_pool: Any | None = None
        self.proposal_repo: ProposalRepository | None = None
        self.context_repo: ContextRepository | None = None
        self.settings_repo: GuildSettingsRepository | None = None
        self.case_repo: ModerationCaseRepository | None = None
        self.conversation_repo: ConversationRepository | None = None
        self.investigation_repo: InvestigationRepository | None = None
        self.automation_repo: AutomationRepository | None = None
        self.usage_repo: UsageRepository | None = None
        self.proposal_expiry_tasks: set[asyncio.Task[None]] = set()
        self.tool_registry = build_moderation_registry(self._execute_registered_proposal)
        diagnostics_registry = build_diagnostics_registry()
        for tool_name in diagnostics_registry.names():
            self.tool_registry.register(diagnostics_registry.get(tool_name))
        register_read_tools(self.tool_registry)
        self.orchestrator = AgentOrchestrator(
            self.interpreter,
            tool_registry=self.tool_registry,
        )
        self.conversations: dict[tuple[int, int, int], Conversation] = {}
        self.rules_cache: dict[int, list[MessageContext]] = {}
        self.rules_refresh_task: asyncio.Task[None] | None = None
        self.context_cleanup_task: asyncio.Task[None] | None = None
        self.automation_recovery_task: asyncio.Task[None] | None = None

    async def setup_hook(self) -> None:
        install_buffer_handler()
        try:
            identity = verify_ownership()
            LOGGER.info(
                "Verified %s attribution: %s (owner: %s)",
                identity["project_name"],
                identity["attribution"],
                identity["owner"],
            )
        except OwnershipIntegrityError:
            LOGGER.critical(
                "TETALBOT OWNERSHIP INTEGRITY FAILURE. "
                "Attribution verification failed; startup has been refused.",
                exc_info=True,
            )
            raise

        self.database_pool = await create_pool()
        await verify_schema(self.database_pool)
        await verify_database_identity(self.database_pool)
        self.proposal_repo = ProposalRepository(self.database_pool)
        self.context_repo = ContextRepository(self.database_pool)
        self.conversation_repo = ConversationRepository(self.database_pool)
        self.investigation_repo = InvestigationRepository(self.database_pool)
        self.automation_repo = AutomationRepository(self.database_pool)
        recovered = await self.automation_repo.recover_stale_executions(
            stale_after_minutes=30
        )
        if recovered:
            LOGGER.warning("Marked %s stale automation executions as interrupted", recovered)
        self.automation_recovery_task = asyncio.create_task(
            self._automation_recovery_loop()
        )
        self.usage_repo = UsageRepository(self.database_pool)
        self.interpreter.usage_callback = self._record_gemini_usage
        self.settings_repo = GuildSettingsRepository(self.database_pool)
        self.case_repo = ModerationCaseRepository(self.database_pool)
        await self.settings_repo.load_into(self.config_store)
        await self.case_repo.load_into(self.case_store)
        self.context_cleanup_task = asyncio.create_task(self._context_retention_loop())
        await self.restore_pending_proposals()
        self._register_investigation_commands()
        await self.tree.sync()
        LOGGER.info("Slash commands synced.")

    async def _record_gemini_usage(self, context: Any, usage: Any, operation: str, model: str) -> None:
        if self.usage_repo is None:
            return
        await self.usage_repo.record(
            guild_id=getattr(context, "current_guild_id", None),
            user_id=getattr(context, "current_user_id", None),
            model=model,
            operation=operation,
            prompt_tokens=getattr(usage, "prompt_token_count", 0) or 0,
            candidate_tokens=getattr(usage, "candidates_token_count", 0) or 0,
            total_tokens=getattr(usage, "total_token_count", 0) or 0,
        )

    def _register_investigation_commands(self) -> None:
        """Register server-scoped investigation and evidence commands."""
        group = app_commands.Group(
            name="investigation",
            description="Create and manage persistent moderation investigations.",
        )

        def require_manager(interaction: discord.Interaction) -> tuple[discord.Guild, discord.Member]:
            guild = interaction.guild
            requester = interaction.user
            if guild is None or not isinstance(requester, discord.Member):
                raise app_commands.CheckFailure("This command must be used inside a server.")
            bot_member = guild.me
            if not requester.guild_permissions.manage_messages:
                raise app_commands.CheckFailure("Manage Messages permission is required.")
            if bot_member is None or not bot_member.guild_permissions.manage_messages:
                raise app_commands.CheckFailure("The bot needs Manage Messages permission.")
            return guild, requester

        @group.command(name="create", description="Create a persistent investigation.")
        @app_commands.describe(title="Short investigation title", subject_user_id="Optional Discord user ID")
        async def create(
            interaction: discord.Interaction,
            title: str,
            subject_user_id: str | None = None,
        ) -> None:
            guild, requester = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            parsed_subject = None
            if subject_user_id:
                try:
                    parsed_subject = int(subject_user_id)
                except ValueError:
                    await interaction.response.send_message("subject_user_id must be a numeric Discord ID.", ephemeral=True)
                    return
            record = await self.investigation_repo.create(
                guild.id, requester.id, title, subject_user_id=parsed_subject
            )
            await interaction.response.send_message(
                f"Created investigation `{record['investigation_id']}`: **{record['title']}**",
                ephemeral=True,
            )

        @group.command(name="list", description="List recent investigations.")
        async def list_investigations(interaction: discord.Interaction) -> None:
            guild, _ = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            records = await self.investigation_repo.list_for_guild(guild.id, limit=15)
            if not records:
                await interaction.response.send_message("No investigations found.", ephemeral=True)
                return
            lines = [
                f"`{item['investigation_id']}` | **{item['title']}** | {item['status']} | {item.get('evidence_count', 0)} evidence"
                for item in records
            ]
            await interaction.response.send_message("\n".join(lines)[:1900], ephemeral=True)

        @group.command(name="add-message", description="Attach a Discord message as investigation evidence.")
        @app_commands.describe(investigation_id="Investigation UUID", channel_id="Channel containing the message", message_id="Message ID")
        async def add_message(
            interaction: discord.Interaction,
            investigation_id: str,
            channel_id: str,
            message_id: str,
        ) -> None:
            guild, requester = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            try:
                channel = guild.get_channel_or_thread(int(channel_id))
                target_message_id = int(message_id)
            except ValueError:
                channel = None
                target_message_id = 0
            if channel is None or not hasattr(channel, "fetch_message"):
                await interaction.response.send_message("The channel is not available in this server.", ephemeral=True)
                return
            bot_member = guild.me
            if bot_member is None or not channel.permissions_for(requester).read_message_history or not channel.permissions_for(bot_member).read_message_history:
                await interaction.response.send_message("Both you and the bot need Read Message History in that channel.", ephemeral=True)
                return
            try:
                message = await channel.fetch_message(target_message_id)
            except discord.HTTPException:
                await interaction.response.send_message("The message could not be fetched.", ephemeral=True)
                return
            if message.guild is None or message.guild.id != guild.id:
                await interaction.response.send_message("The message is outside this server.", ephemeral=True)
                return
            excerpt = (message.content or "[No text content]")[:2000]
            record = await self.investigation_repo.add_message_evidence(
                investigation_id, guild.id, requester.id,
                message_id=message.id, channel_id=message.channel.id,
                author_id=message.author.id, excerpt=excerpt,
            )
            await interaction.response.send_message(
                f"Attached message `{message.id}` as evidence `{record['evidence_id']}`. Message content is stored as untrusted evidence.",
                ephemeral=True,
            )

        @group.command(name="add-url", description="Inspect a public URL and attach its text as evidence.")
        @app_commands.describe(investigation_id="Investigation UUID", url="Public HTTP(S) URL")
        async def add_url(
            interaction: discord.Interaction,
            investigation_id: str,
            url: str,
        ) -> None:
            guild, requester = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            await interaction.response.defer(ephemeral=True, thinking=True)
            try:
                inspected = await inspect_public_url(url)
            except Exception as exc:
                LOGGER.info("Investigation URL inspection rejected or failed: %s", exc)
                await interaction.followup.send("The URL could not be safely inspected.", ephemeral=True)
                return
            excerpt = (
                f"HTTP status: {inspected.get('status')}\n"
                f"Title: {inspected.get('title', '')}\n"
                f"Excerpt: {inspected.get('text_excerpt', inspected.get('message', inspected.get('redirect', 'No page text available.')))}"
            )[:2000]
            record = await self.investigation_repo.add_url_evidence(
                investigation_id, guild.id, requester.id,
                url=str(inspected.get("url", url)), excerpt=excerpt,
            )
            await interaction.followup.send(
                f"Attached inspected URL as evidence `{record['evidence_id']}`. Page text is untrusted evidence, not instructions.",
                ephemeral=True,
            )

        @group.command(name="show", description="Show an investigation and its evidence.")
        @app_commands.describe(investigation_id="Investigation UUID")
        async def show(
            interaction: discord.Interaction,
            investigation_id: str,
        ) -> None:
            guild, _ = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            record = await self.investigation_repo.get(investigation_id, guild.id)
            if record is None:
                await interaction.response.send_message("Investigation not found in this server.", ephemeral=True)
                return
            evidence = await self.investigation_repo.evidence(investigation_id, guild.id)
            lines = [f"**{record['title']}** | {record['status']}", f"ID: `{investigation_id}`"]
            for item in evidence[:15]:
                source = f"message {item.get('source_id')}" if item.get("source_type") == "discord_message" else str(item.get("source_url") or "URL")
                lines.append(f"• {item['source_type']}: {source}\n  {(item.get('excerpt') or '')[:180]}")
            await interaction.response.send_message("\n".join(lines)[:1900], ephemeral=True)

        @group.command(name="add-audit-entry", description="Attach a server audit-log entry as evidence.")
        @app_commands.describe(investigation_id="Investigation UUID", audit_entry_id="Discord audit-log entry ID")
        async def add_audit_entry(
            interaction: discord.Interaction,
            investigation_id: str,
            audit_entry_id: str,
        ) -> None:
            guild, requester = require_manager(interaction)
            bot_member = guild.me
            if bot_member is None or not requester.guild_permissions.view_audit_log or not bot_member.guild_permissions.view_audit_log:
                await interaction.response.send_message("Both you and the bot need View Audit Log permission.", ephemeral=True)
                return
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            try:
                wanted_id = int(audit_entry_id)
            except ValueError:
                await interaction.response.send_message("audit_entry_id must be a numeric Discord ID.", ephemeral=True)
                return
            entry = None
            async for candidate in guild.audit_logs(limit=100):
                if candidate.id == wanted_id:
                    entry = candidate
                    break
            if entry is None:
                await interaction.response.send_message("The audit-log entry was not found in the latest 100 entries.", ephemeral=True)
                return
            target_id = getattr(entry.target, "id", None)
            actor_id = getattr(entry.user, "id", None)
            excerpt = (
                f"Action: {entry.action}\nActor ID: {actor_id}\n"
                f"Target ID: {target_id}\nReason: {entry.reason or 'No reason recorded'}\n"
                f"Created at: {entry.created_at.isoformat()}"
            )
            record = await self.investigation_repo.add_note_evidence(
                investigation_id, guild.id, requester.id,
                source_id=f"audit_log:{entry.id}", excerpt=excerpt,
            )
            await interaction.response.send_message(
                f"Attached audit-log entry `{entry.id}` as evidence `{record['evidence_id']}`.",
                ephemeral=True,
            )

        @group.command(name="close", description="Close an investigation with a summary.")
        @app_commands.describe(investigation_id="Investigation UUID", summary="Closing summary")
        async def close_investigation(
            interaction: discord.Interaction,
            investigation_id: str,
            summary: str,
        ) -> None:
            guild, _ = require_manager(interaction)
            if self.investigation_repo is None:
                await interaction.response.send_message("Investigation storage is unavailable.", ephemeral=True)
                return
            closed = await self.investigation_repo.close(investigation_id, guild.id, summary)
            await interaction.response.send_message(
                "Investigation closed." if closed else "Investigation not found, already closed, or outside this server.",
                ephemeral=True,
            )

        self.tree.add_command(group)

    async def _on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        LOGGER.exception("Slash command failed", exc_info=(type(error), error, error.__traceback__))
        if interaction.user.id == OWNER_USER_ID:
            details = "".join(traceback.format_exception(type(error), error, error.__traceback__))
            message = f"Owner diagnostic:\n```\n{details[-1800:]}\n```"
        else:
            message = "The command could not be completed. Please try again."
        try:
            if interaction.response.is_done():
                await interaction.followup.send(message, ephemeral=True)
            else:
                await interaction.response.send_message(message, ephemeral=True)
        except discord.HTTPException:
            LOGGER.exception("Could not report slash command failure to the user")

    async def close(self) -> None:
        for task in self.proposal_expiry_tasks:
            task.cancel()
        if self.context_cleanup_task is not None:
            self.context_cleanup_task.cancel()
            self.context_cleanup_task = None
        if self.automation_recovery_task is not None:
            self.automation_recovery_task.cancel()
            self.automation_recovery_task = None
        self.proposal_expiry_tasks.clear()
        if self.database_pool is not None:
            await self.database_pool.close()
            self.database_pool = None
        await super().close()

    async def _automation_recovery_loop(self) -> None:
        """Periodically close executions abandoned by crashed workers."""
        while not self.is_closed():
            try:
                if self.automation_repo is not None:
                    recovered = await self.automation_repo.recover_stale_executions(
                        stale_after_minutes=30
                    )
                    if recovered:
                        LOGGER.warning(
                            "Marked %s stale automation executions as interrupted",
                            recovered,
                        )
            except Exception:
                LOGGER.exception("Automation stale-execution recovery failed")
            await asyncio.sleep(60)

    async def _context_retention_loop(self) -> None:
        while not self.is_closed():
            try:
                if self.context_repo is not None:
                    removed = await self.context_repo.prune_expired(batch_size=5000)
                    if removed:
                        LOGGER.info("Pruned %s expired context messages", removed)
                if self.automation_repo is not None:
                    removed_automations = await self.automation_repo.prune_expired(batch_size=5000)
                    if removed_automations:
                        LOGGER.info("Pruned %s expired automation executions", removed_automations)
            except Exception:
                LOGGER.exception("Database retention cleanup failed")
            await asyncio.sleep(86_400)
    async def restore_pending_proposals(self) -> None:
        if self.proposal_repo is None:
            return
        records = await self.proposal_repo.list_pending()
        restored_batches: set[str] = set()
        for record in records:
            metadata = record.get("metadata") or {}
            message_id = metadata.get("confirmation_message_id")
            if not message_id:
                continue
            batch_id = metadata.get("batch_id")
            if batch_id:
                batch_id = str(batch_id)
                if batch_id not in restored_batches:
                    batch_records = await self.proposal_repo.get_batch(batch_id)
                    view = BatchConfirmationView(
                        self,
                        batch_id,
                        int(record["user_id"]),
                        int(record["guild_id"]),
                        batch_records,
                    )
                    self.add_view(view, message_id=int(message_id))
                    restored_batches.add(batch_id)
            else:
                view = ConfirmationView(
                    self,
                    str(record["id"]),
                    int(record["user_id"]),
                    int(record["guild_id"]),
                )
                self.add_view(view, message_id=int(message_id))
            channel_id = metadata.get("confirmation_channel_id")
            if channel_id:
                self._schedule_proposal_expiration(
                    str(record["id"]),
                    int(record["guild_id"]),
                    int(channel_id),
                    int(message_id),
                    record["expires_at"],
                )
        LOGGER.info("Restored pending confirmation views.")

    def _schedule_proposal_expiration(
        self,
        proposal_id: str,
        guild_id: int,
        channel_id: int,
        message_id: int,
        expires_at: datetime,
    ) -> None:
        task = asyncio.create_task(
            self._expire_proposal_after(
                proposal_id, guild_id, channel_id, message_id, expires_at
            )
        )
        self.proposal_expiry_tasks.add(task)
        task.add_done_callback(self.proposal_expiry_tasks.discard)

    async def _expire_proposal_after(
        self,
        proposal_id: str,
        guild_id: int,
        channel_id: int,
        message_id: int,
        expires_at: datetime,
    ) -> None:
        delay = max(
            0.0,
            (expires_at - datetime.now(timezone.utc)).total_seconds(),
        )
        await asyncio.sleep(delay)
        if self.proposal_repo is None:
            return
        closed = await self.proposal_repo.close(
            proposal_id, "expired", "Confirmation window expired."
        )
        if not closed:
            return
        record = await self.proposal_repo.get(proposal_id)
        if record:
            await self.close_case_if_present(
                (record.get("metadata") or {}).get("case_id"),
                "expired",
                "Confirmation window expired.",
            )
        guild = self.get_guild(guild_id)
        channel = guild.get_channel_or_thread(channel_id) if guild else None
        if channel is None:
            return
        try:
            confirmation = await channel.fetch_message(message_id)
            metadata = (record or {}).get("metadata") or {}
            batch_id = metadata.get("batch_id")
            if batch_id:
                batch_records = await self.proposal_repo.get_batch(str(batch_id))
                lines = ["**Tetalbot action queue**"]
                for index, item in enumerate(batch_records):
                    proposal = ModerationProposal.from_payload(item.get("arguments") or {})
                    status = str(item.get("status", "pending")).replace("_", " ").title()
                    if item.get("status") == "pending" and any(
                        previous.get("status") != "completed"
                        for previous in batch_records[:index]
                    ):
                        status = "Blocked until earlier steps complete"
                    lines.append(f"{index + 1}. **{proposal.action or 'Action'}**: {status}")
                terminal = {"completed", "partially_completed", "failed", "cancelled", "expired"}
                view = None if all(item.get("status") in terminal for item in batch_records) else BatchConfirmationView(
                    self, str(batch_id), int(batch_records[0]["user_id"]),
                    guild_id, batch_records
                )
                await confirmation.edit(content="\n".join(lines)[:1900], view=view)
            else:
                await confirmation.edit(
                    content="This proposal expired. No action was taken.", view=None
                )
        except discord.HTTPException:
            LOGGER.info("Expired proposal %s could not update its Discord message.", proposal_id)

    async def fetch_source_message(
        self,
        guild: discord.Guild | None,
        metadata: dict[str, Any],
    ) -> discord.Message | None:
        if guild is None:
            return None
        try:
            channel_id = int(metadata["source_channel_id"])
            message_id = int(metadata["source_message_id"])
        except (KeyError, TypeError, ValueError):
            return None
        channel = guild.get_channel_or_thread(channel_id)
        if channel is None or not hasattr(channel, "fetch_message"):
            return None
        try:
            return await channel.fetch_message(message_id)
        except discord.HTTPException:
            return None

    async def persist_guild_config(self, guild_id: int) -> bool:
        if self.settings_repo is None:
            return False
        try:
            await self.settings_repo.upsert(guild_id, self.config_store.get(guild_id))
            return True
        except Exception:
            LOGGER.exception("Could not persist guild settings for %s", guild_id)
            return False

    async def persist_case(self, case_id: Any) -> None:
        if case_id is None or self.case_repo is None:
            return
        try:
            case = next(
                (item for item in self.case_store.cases if item.case_id == int(case_id)),
                None,
            )
            if case is not None:
                await self.case_repo.upsert(case)
        except Exception:
            LOGGER.exception("Could not mirror moderation case %s to PostgreSQL", case_id)

    async def close_case_if_present(
        self,
        case_id: Any,
        status: str,
        outcome: str,
    ) -> None:
        if case_id is None:
            return
        try:
            self.case_store.mark_closed(int(case_id), status, outcome)
            await self.persist_case(case_id)
        except (TypeError, ValueError):
            LOGGER.exception("Could not close moderation case %s", case_id)

    async def confirm_case_if_present(
        self,
        case_id: Any,
        outcome: str,
        status: str,
    ) -> None:
        if case_id is None:
            return
        try:
            self.case_store.mark_confirmed(int(case_id), outcome, status=status)
            await self.persist_case(case_id)
        except (TypeError, ValueError):
            LOGGER.exception("Could not complete moderation case %s", case_id)

    async def on_ready(self) -> None:
        LOGGER.info("Logged in as %s (%s)", self.user, self.user.id if self.user else "unknown")
        if self.rules_refresh_task is None or self.rules_refresh_task.done():
            self.rules_refresh_task = asyncio.create_task(self._rules_refresh_loop())
        await self.refresh_rules_cache()

    async def refresh_rules_cache(self) -> None:
        for guild in self.guilds:
            await self.refresh_rules_for_guild(guild)

    async def refresh_rules_for_guild(self, guild: discord.Guild) -> None:
        config = self.config_store.get(guild.id)
        if not config.rules_channel_id:
            self.rules_cache.pop(guild.id, None)
            return
        channel = guild.get_channel(config.rules_channel_id)
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            return
        # A zero config means "not fetched on demand"; the cache still keeps a
        # bounded copy so rules are available without putting them in every API call.
        limit = config.rules_message_limit or 50
        try:
            self.rules_cache[guild.id] = await read_channel_messages(channel, min(limit, 50))
        except (discord.Forbidden, discord.HTTPException):
            LOGGER.warning("Could not refresh rules cache for guild %s", guild.id)

    async def _rules_refresh_loop(self) -> None:
        while not self.is_closed():
            await asyncio.sleep(3600)
            try:
                await self.refresh_rules_cache()
            except Exception:
                LOGGER.exception("Rules cache refresh failed")

    async def _dispatch_automation_event(
        self,
        guild: discord.Guild,
        trigger_event: str,
        event_data: dict[str, Any],
        event_key: str,
        *,
        source_channel: Any | None = None,
    ) -> None:
        """Run matching, explicitly approved event rules through registered tools."""
        repository = self.automation_repo
        if repository is None:
            return
        try:
            rules = await repository.list_for_event(guild.id, trigger_event)
        except Exception:
            LOGGER.exception("Could not load %s automation rules for guild %s", trigger_event, guild.id)
            return

        for rule in rules:
            conditions = rule.get("trigger_conditions") or {}
            if not conditions_match(conditions, event_data):
                continue
            try:
                execution_id = await repository.begin_execution(
                    rule_id=str(rule["id"]),
                    guild_id=guild.id,
                    event_key=event_key,
                    trigger_data=event_data,
                )
            except Exception:
                LOGGER.exception("Could not record automation event for rule %s", rule.get("id"))
                continue
            if execution_id is None:
                continue

            actions_taken: list[dict[str, Any]] = []
            successful_actions = 0
            error: str | None = None
            result_status = "success"
            try:
                try:
                    creator_id = int(rule["created_by"])
                except (KeyError, TypeError, ValueError):
                    creator_id = 0
                creator = guild.get_member(creator_id)
                if (
                    creator is None
                    or creator.bot
                    or not creator.guild_permissions.manage_guild
                ):
                    result_status = "skipped"
                    error = "The automation creator is no longer a server member with Manage Server permission."
                    await repository.finish_execution(
                        execution_id,
                        rule_id=str(rule["id"]),
                        guild_id=guild.id,
                        result=result_status,
                        actions_taken=actions_taken,
                        error=error,
                    )
                    continue
                if rule.get("use_ai_reasoning") is True:
                    should_run, reason = await self.interpreter.evaluate_automation_event(
                        str(rule.get("description") or ""),
                        event_data,
                        guild_id=guild.id,
                    )
                    if not should_run:
                        result_status = "skipped"
                        error = reason or "The optional AI event check did not approve this event."
                        await repository.finish_execution(
                            execution_id,
                            rule_id=str(rule["id"]),
                            guild_id=guild.id,
                            result=result_status,
                            actions_taken=actions_taken,
                            error=error,
                        )
                        continue

                if guild.me is None:
                    raise RuntimeError("The bot's server-member context is unavailable.")

                fallback_channel = source_channel or guild.system_channel
                if fallback_channel is None:
                    fallback_channel = guild.get_channel(
                        self.config_store.get(guild.id).staff_channel_id or 0
                    )
                source_message = SimpleNamespace(
                    guild=guild,
                    channel=fallback_channel,
                    author=creator,
                )
                interaction_proxy = SimpleNamespace(
                    guild=guild,
                    user=creator,
                    channel=fallback_channel,
                    channel_id=getattr(fallback_channel, "id", None),
                )
                tool_context = SimpleNamespace(
                    bot=self,
                    interaction=interaction_proxy,
                    source_message=source_message,
                    guild=guild,
                    requester=creator,
                    bot_member=guild.me,
                    auto_executor=None,
                )

                for action_index, action_item in enumerate(rule.get("action_sequence") or []):
                    tool_name = str(action_item.get("tool_name") or "")
                    if tool_name not in {"assign_role", "remove_role", "send_message"}:
                        raise ValueError(f"Action {tool_name or action_index + 1} is not permitted in event automations.")
                    tool = self.tool_registry.get(tool_name)
                    if not tool.automation_eligible:
                        raise ValueError(f"Action {tool_name} is no longer automation-eligible.")
                    action_conditions = action_item.get("conditions") or {}
                    if not conditions_match(action_conditions, event_data):
                        actions_taken.append({
                            "tool": tool_name,
                            "success": True,
                            "skipped": True,
                            "result": "This action's conditions did not match the event.",
                        })
                        continue
                    arguments = render_event_placeholders(
                        action_item.get("arguments") or {},
                        event_data,
                    )
                    validation_error = tool.validate_arguments(arguments)
                    if validation_error:
                        raise ValueError(f"{tool_name} validation failed: {validation_error}")
                    proposal = ModerationProposal.from_payload(arguments)
                    if tool_name in {"assign_role", "remove_role"}:
                        role = guild.get_role(int(proposal.parameters.get("role_id", 0)))
                        ensure_automation_role_safe(role)
                    authorization = authorize_operation(
                        guild=guild,
                        requester=creator,
                        bot_member=guild.me,
                        tool=tool,
                        proposal=proposal,
                        channel=source_channel,
                    )
                    if not authorization.allowed:
                        raise ValueError(f"{tool_name} was blocked: {authorization.message}")
                    try:
                        outcome = await tool.handler(tool_context, arguments)
                    except Exception as exc:
                        raise RuntimeError(
                            f"{tool_name} failed: {_discord_failure_reason(exc)}"
                        ) from exc
                    actions_taken.append({
                        "tool": tool_name,
                        "success": True,
                        "result": str(outcome)[:500],
                    })
                    successful_actions += 1

                if successful_actions == 0 and actions_taken:
                    result_status = "skipped"

            except Exception as exc:
                error = str(exc)[:1500]
                result_status = "partial" if successful_actions else "failed"
                LOGGER.warning(
                    "Automation rule %s failed on %s: %s",
                    rule.get("id"), trigger_event, error,
                )
                if actions_taken:
                    actions_taken.append({
                        "success": False,
                        "error": error,
                    })
            try:
                await repository.finish_execution(
                    execution_id,
                    rule_id=str(rule["id"]),
                    guild_id=guild.id,
                    result=result_status,
                    actions_taken=actions_taken,
                    error=error,
                )
            except Exception:
                LOGGER.exception("Could not finalize automation execution %s", execution_id)
            if error:
                config = self.config_store.get(guild.id)
                staff_channel = guild.get_channel(config.staff_channel_id or 0)
                if isinstance(staff_channel, (discord.TextChannel, discord.Thread)):
                    try:
                        await staff_channel.send(
                            f"Automation **{str(rule.get('name') or rule['id'])[:100]}** "
                            f"({str(rule['id'])[:8]}) failed: {error[:1000]}",
                            allowed_mentions=discord.AllowedMentions.none(),
                        )
                    except discord.HTTPException:
                        LOGGER.exception("Could not report automation failure to staff channel")

    async def on_member_join(self, member: discord.Member) -> None:
        data = {
            "event": "member_join",
            "member_id": str(member.id),
            "member_mention": member.mention,
            "username": member.display_name[:100],
            "is_bot": bool(member.bot),
            "account_age_days": account_age_days(member.created_at),
        }
        joined = member.joined_at.isoformat() if member.joined_at else "unknown"
        await self._dispatch_automation_event(
            member.guild, "member_join", data,
            f"member_join:{member.id}:{joined}",
        )

    async def on_member_remove(self, member: discord.Member) -> None:
        data = {
            "event": "member_leave",
            "member_id": str(member.id),
            "member_mention": member.mention,
            "username": member.display_name[:100],
            "is_bot": bool(member.bot),
            "account_age_days": account_age_days(member.created_at),
        }
        await self._dispatch_automation_event(
            member.guild, "member_leave", data,
            f"member_leave:{member.id}:{member.joined_at.isoformat() if member.joined_at else int(datetime.now(timezone.utc).timestamp()) // 10}",
        )

    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent) -> None:
        if payload.guild_id is None or (self.user and payload.user_id == self.user.id):
            return
        guild = self.get_guild(payload.guild_id)
        if guild is None:
            return
        member = payload.member or guild.get_member(payload.user_id)
        if member is None:
            try:
                member = await guild.fetch_member(payload.user_id)
            except discord.HTTPException:
                return
        if member.bot:
            return
        channel = guild.get_channel_or_thread(payload.channel_id)
        emoji = str(payload.emoji)
        data = {
            "event": "reaction_add",
            "member_id": str(member.id),
            "member_mention": member.mention,
            "username": member.display_name[:100],
            "is_bot": bool(member.bot),
            "channel_id": str(payload.channel_id),
            "emoji": emoji[:100],
        }
        source = SimpleNamespace(guild=guild, channel=channel, author=member)
        await self._dispatch_automation_event(
            guild, "reaction_add", data,
            f"reaction_add:{payload.message_id}:{member.id}:{emoji}",
            source_channel=channel,
        )

    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ) -> None:
        if member.bot:
            return
        timestamp_bucket = int(datetime.now(timezone.utc).timestamp()) // 10
        common = {
            "member_id": str(member.id),
            "member_mention": member.mention,
            "username": member.display_name[:100],
            "is_bot": bool(member.bot),
        }
        if before.channel is not None and (
            after.channel is None or before.channel.id != after.channel.id
        ):
            data = {
                **common,
                "event": "voice_leave",
                "channel_id": str(before.channel.id),
            }
            await self._dispatch_automation_event(
                member.guild,
                "voice_leave",
                data,
                f"voice_leave:{member.guild.id}:{member.id}:{before.channel.id}:{timestamp_bucket}",
                source_channel=before.channel,
            )
        if after.channel is not None and (
            before.channel is None or before.channel.id != after.channel.id
        ):
            data = {
                **common,
                "event": "voice_join",
                "channel_id": str(after.channel.id),
            }
            await self._dispatch_automation_event(
                member.guild,
                "voice_join",
                data,
                f"voice_join:{member.guild.id}:{member.id}:{after.channel.id}:{timestamp_bucket}",
                source_channel=after.channel,
            )

    async def on_member_update(self, before: discord.Member, after: discord.Member) -> None:
        if after.bot:
            return
        before_ids = {role.id for role in before.roles}
        after_ids = {role.id for role in after.roles}
        added = after_ids - before_ids
        removed = before_ids - after_ids
        for role_id in sorted(added):
            data = {
                "event": "role_assign",
                "member_id": str(after.id),
                "member_mention": after.mention,
                "username": after.display_name[:100],
                "is_bot": bool(after.bot),
                "role_id": str(role_id),
            }
            await self._dispatch_automation_event(
                after.guild, "role_assign", data,
                f"role_assign:{after.id}:{role_id}:{','.join(map(str, sorted(after_ids)))}",
            )
        for role_id in sorted(removed):
            data = {
                "event": "role_remove",
                "member_id": str(after.id),
                "member_mention": after.mention,
                "username": after.display_name[:100],
                "is_bot": bool(after.bot),
                "role_id": str(role_id),
            }
            await self._dispatch_automation_event(
                after.guild, "role_remove", data,
                f"role_remove:{after.id}:{role_id}:{','.join(map(str, sorted(after_ids)))}",
            )

    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        if after.guild is None or after.author.bot or self.context_repo is None:
            return
        try:
            await self.context_repo.store_message(after)
        except Exception:
            LOGGER.exception("Could not persist edited message %s", after.id)

    async def on_message_delete(self, message: discord.Message) -> None:
        if message.guild is None or self.context_repo is None:
            return
        try:
            await self.context_repo.mark_deleted(message.id)
        except Exception:
            LOGGER.exception("Could not mark deleted message %s", message.id)
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent) -> None:
        if payload.guild_id is None or self.context_repo is None:
            return
        try:
            await self.context_repo.mark_deleted(payload.message_id)
        except Exception:
            LOGGER.exception("Could not mark raw-deleted message %s", payload.message_id)

    async def on_raw_bulk_message_delete(self, payload: discord.RawBulkMessageDeleteEvent) -> None:
        if payload.guild_id is None or self.context_repo is None:
            return
        for message_id in payload.message_ids:
            try:
                await self.context_repo.mark_deleted(message_id)
            except Exception:
                LOGGER.exception("Could not mark bulk-deleted message %s", message_id)

    async def _handle_automation_request(
        self,
        message: discord.Message,
        request: str,
        conversation: Conversation,
    ) -> None:
        """Draft a persistent automation from a normal staff conversation."""
        guild = message.guild
        requester = message.author
        if guild is None or not isinstance(requester, discord.Member):
            return
        if not requester.guild_permissions.manage_guild:
            response = await message.reply(
                "You need the Manage Server permission to create automation rules.",
                mention_author=False,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            conversation.last_bot_message_id = response.id
            return
        if self.automation_repo is None:
            response = await message.reply(
                "Automation storage is unavailable. No rule was created.",
                mention_author=False,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            conversation.last_bot_message_id = response.id
            return

        thinking = await message.reply(
            "Let me turn that into a rule and check that its actions are safe...",
            mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        guild_context = {
            "roles": [
                {"id": str(role.id), "name": role.name}
                for role in guild.roles
                if not role.is_default() and not role.managed
            ][:100],
            "text_channels": [
                {"id": str(channel.id), "name": channel.name}
                for channel in guild.text_channels
            ][:100],
            "voice_channels": [
                {"id": str(channel.id), "name": channel.name}
                for channel in guild.voice_channels
            ][:100],
        }
        try:
            raw = await self.interpreter.generate_automation_rule(
                request,
                guild_id=guild.id,
                user_id=requester.id,
                guild_context=guild_context,
                tool_definitions=self.tool_registry.automation_schemas(),
                allowed_triggers=sorted(SUPPORTED_TRIGGER_EVENTS),
            )
            clarification = raw.get("clarification")
            if clarification:
                await thinking.edit(
                    content=str(clarification)[:1500],
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                conversation.last_bot_message_id = thinking.id
                return
            draft = validate_automation_definition(
                raw, guild=guild, registry=self.tool_registry
            )
        except ValueError as exc:
            await thinking.edit(
                content=str(exc)[:1700],
                allowed_mentions=discord.AllowedMentions.none(),
            )
            conversation.last_bot_message_id = thinking.id
            return
        except Exception:
            LOGGER.exception("Natural-language automation draft failed")
            await thinking.edit(
                content="I couldn't safely draft that automation. No rule was created.",
                allowed_mentions=discord.AllowedMentions.none(),
            )
            conversation.last_bot_message_id = thinking.id
            return

        conditions = json.dumps(draft["trigger_conditions"], ensure_ascii=False)
        actions: list[str] = []
        for item in draft["action_sequence"]:
            parameters = item["arguments"].get("parameters") or {}
            tool_name = item["tool_name"]
            summary = f"**{tool_name.replace('_', ' ')}**"
            if tool_name in {"assign_role", "remove_role"}:
                role = guild.get_role(int(parameters["role_id"]))
                summary += f" {role.mention if role else parameters['role_id']} for the triggering member"
            elif tool_name in {"warn", "mute"}:
                summary += " the triggering member"
            elif tool_name == "delete":
                summary += " the triggering message only"
            elif tool_name == "send_message":
                channel = guild.get_channel(int(parameters["channel_id"]))
                summary += f" in {channel.mention if channel else parameters['channel_id']}: {parameters['content'][:350]}"
            action_conditions = item.get("conditions") or {}
            if action_conditions:
                summary += f" (when {json.dumps(action_conditions, ensure_ascii=False)[:140]})"
            actions.append(summary)
        preview = (
            f"**Automation draft: {draft['name']}**\n"
            f"Trigger: `{draft['trigger_event']}`\n"
            f"Conditions: `{conditions[:350]}`\n"
            f"AI event reasoning: {'enabled' if draft['use_ai_reasoning'] else 'disabled'}\n"
            f"Actions:\n" + "\n".join(f"{index + 1}. {item}" for index, item in enumerate(actions))
            + "\n\nApproving enables this rule immediately. It will run automatically when its trigger "
            "and conditions match. Permissions are rechecked at execution time. Ban, unban, and kick "
            "are never eligible for automatic execution and always require manual staff confirmation."
        )
        if len(preview) > 1850:
            preview = (
                "This automation draft is too long to display safely. Shorten the message content "
                "or simplify the rule and try again. Nothing was enabled."
            )
            await thinking.edit(
                content=preview,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        else:
            await thinking.edit(
                content=preview,
                view=AutomationRuleConfirmationView(
                    self, guild_id=guild.id, creator_id=requester.id, draft=draft
                ),
                allowed_mentions=discord.AllowedMentions.none(),
            )
        conversation.last_bot_message_id = thinking.id

    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or not message.guild:
            return
        if self.context_repo is not None:
            try:
                await self.context_repo.store_message(message)
            except Exception:
                LOGGER.exception("Could not persist context message %s", message.id)
        await self._dispatch_automation_event(
            message.guild,
            "message_contains",
            {
                "event": "message_contains",
                "member_id": str(message.author.id),
                "member_mention": message.author.mention,
                "username": message.author.display_name[:100],
                "is_bot": bool(message.author.bot),
                "channel_id": str(message.channel.id),
                "message_id": str(message.id),
                "content": (message.content or "")[:500],
            },
            f"message:{message.id}",
            source_channel=message.channel,
        )
        if not self.user:
            return
        key = (message.guild.id, message.author.id, message.channel.id)
        conversation = self.conversations.setdefault(key, Conversation())
        if self.conversation_repo is not None:
            conversation.messages = await self.conversation_repo.load(*key)
        else:
            conversation.messages = self.memory_store.load(*key)
        is_reply_to_bot = (
            message.reference is not None
            and message.reference.message_id == conversation.last_bot_message_id
        )
        if self.user not in message.mentions and not is_reply_to_bot:
            return
        pending_proposal = pending_proposal_for_turn(
            conversation, is_reply_to_bot=is_reply_to_bot
        )

        request = strip_bot_mention(message.content, self.user.id)
        conversation.last_channel_id = message.channel.id
        if _looks_like_automation_request(request):
            await self._handle_automation_request(message, request, conversation)
            return

        try:
            config = self.config_store.get(message.guild.id)
            agent_result = await self.orchestrator.run_agent_task(
                message,
                request,
                config,
                self.rules_cache.get(message.guild.id, []),
                conversation.messages[-20:],
                ToolExecutionContext(
                    self,
                    interaction=None,
                    source_message=message,
                    guild=message.guild,
                    requester=message.author,
                    bot_member=message.guild.me,
                    auto_executor=self._execute_low_risk_tool,
                ),
            )
            if agent_result.proposals:
                await self._create_action_batch(
                    message, request, conversation,
                    agent_result.proposals, agent_result.tool_results or [],
                )
                return
            proposal = agent_result.proposal
            if proposal is None:
                final_response = agent_result.final_response or "I could not complete that request."
                conversation.messages.extend(
                    [
                        {"role": "user", "content": request},
                        {
                            "role": "assistant",
                            "content": json.dumps(
                                {
                                    "response": final_response,
                                    "tool_results": agent_result.tool_results or [],
                                },
                                ensure_ascii=False,
                            ),
                        },
                    ]
                )
                conversation.messages = conversation.messages[-20:]
                if self.conversation_repo is not None:
                    await self.conversation_repo.replace(*key, conversation.messages)
                else:
                    self.memory_store.replace(*key, conversation.messages)
                conversation.pending_proposal = None
                response = await message.reply(final_response, mention_author=False)
                conversation.last_bot_message_id = response.id
                return
            proposal = self.merge_proposals(pending_proposal, proposal)
            mass_actions = {"warn", "mute", "ban", "kick", "unmute"}
            mass_requested = (
                proposal.action in mass_actions
                and re.search(
                    r"\b(all|everyone|everybody|multiple|users)\b",
                    request.casefold(),
                )
                is not None
            )
            explicit_targets = [
                member for member in message.mentions
                if member.id != self.user.id
            ]
            if mass_requested and not explicit_targets:
                # A mass intent must use bounded evidence selection, not a
                # possibly ambiguous name picked from the member directory.
                proposal.target_user_id = None
                proposal.target_user_ids = []
                proposal = await self.prepare_mass_targets(
                    message.guild,
                    request,
                    proposal,
                    requester_id=message.author.id,
                )
            else:
                proposal = self.resolve_target(
                    message.guild, message, request, conversation.messages, proposal
                )
            if (
                proposal.action in {"warn", "mute", "ban", "kick", "unmute"}
                and not proposal.target_user_id
                and not proposal.target_user_ids
                and not mass_requested
            ):
                # Leave normal single-target requests for clarification rather
                # than attempting a broad history search.
                proposal.status = "question"
            proposal = self.complete_required_fields(proposal)
            if (
                proposal.action == "delete_by_description"
                and proposal.parameters.get("description")
            ) or (
                proposal.action == "delete_by_similarity"
                and proposal.parameters.get("example_message_id")
            ):
                proposal = await self.prepare_search_proposal(message.guild, message, proposal)
        except Exception as exc:
            LOGGER.exception("Could not interpret moderation request")
            if message.author.id == OWNER_USER_ID:
                details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
                error_text = f"**Error (owner view):**\n```\n{details[-1800:]}\n```"
            else:
                error_text = "Something went wrong while processing that request. Please try again."
            response = await message.reply(error_text, mention_author=False)
            conversation.last_bot_message_id = response.id
            return

        conversation.messages.extend(
            [
                {"role": "user", "content": request},
                {
                    "role": "assistant",
                    "content": json.dumps(
                        {
                            "status": proposal.status,
                            "question": proposal.question,
                            "action": proposal.action,
                            "target_user_id": proposal.target_user_id,
                            "target_user_ids": proposal.target_user_ids,
                            "duration_minutes": proposal.duration_minutes,
                            "reason": proposal.reason,
                            "rule_reference": proposal.rule_reference,
                            "evidence_message_ids": proposal.evidence_message_ids,
                            "parameters": proposal.parameters,
                            "preview_items": proposal.preview_items,
                            "summary": proposal.summary,
                            "tool_results": agent_result.tool_results or [],
                        }
                    ),
                },
            ]
        )
        conversation.messages = conversation.messages[-20:]
        if self.conversation_repo is not None:
            await self.conversation_repo.replace(*key, conversation.messages)
        else:
            self.memory_store.replace(*key, conversation.messages)

        if not proposal.is_valid_proposal():
            conversation.pending_proposal = proposal
            question = proposal.question or self.missing_fields_question(proposal)
            response = await message.reply(question, mention_author=False)
            conversation.last_bot_message_id = response.id
            return

        member_actions = {"warn", "mute", "unmute", "ban", "unban", "kick"}
        needs_member_target = proposal.action in member_actions or proposal.action in {
            "assign_role", "remove_role"
        }
        if proposal.target_user_ids:
            proposal.target_user_ids = list(dict.fromkeys(proposal.target_user_ids))
            proposal.target_user_id = proposal.target_user_ids[0]
        target = message.guild.get_member(proposal.target_user_id or 0)
        if target is None and proposal.action == "unban":
            try:
                target = await message.guild.fetch_user(proposal.target_user_id or 0)
            except discord.HTTPException:
                target = None
        if needs_member_target and target is None:
            conversation.pending_proposal = proposal
            response = await message.reply(
                "I could not find a unique server member with that name. Mention the user directly or use their exact username.",
                mention_author=False,
            )
            conversation.last_bot_message_id = response.id
            return
        if proposal.target_user_ids:
            if len(proposal.target_user_ids) > MAX_BATCH_TARGETS:
                proposal.status = "question"
                proposal.question = (
                    f"That request includes more than {MAX_BATCH_TARGETS} members. "
                    "Please split it into smaller, clearly listed groups."
                )
                proposal.target_user_ids = []
                proposal.target_user_id = None
                proposal.preview_items = []
                response = await message.reply(proposal.question, mention_author=False)
                conversation.pending_proposal = proposal
                conversation.last_bot_message_id = response.id
                return
            missing_ids = [
                user_id for user_id in proposal.target_user_ids
                if message.guild.get_member(user_id) is None
                and proposal.action != "unban"
            ]
            if missing_ids:
                conversation.pending_proposal = proposal
                response = await message.reply(
                    "I could not resolve every target in this server. Please mention the intended members directly.",
                    mention_author=False,
                )
                conversation.last_bot_message_id = response.id
                return
            proposal.target_user_ids = list(dict.fromkeys(proposal.target_user_ids))
            if not proposal.preview_items:
                proposal.preview_items = [
                    f"{member.display_name} (`{member.id}`)"
                    for user_id in proposal.target_user_ids
                    if (member := message.guild.get_member(user_id)) is not None
                ][:MAX_BATCH_TARGETS]

        conversation.pending_proposal = None
        summary = self.proposal_text(proposal, target)
        case = self.case_store.record_proposal(
            guild_id=message.guild.id,
            moderator_id=message.author.id,
            target_id=proposal.target_user_id or 0,
            action=proposal.action,
            reason=proposal.reason,
            rule_reference=proposal.rule_reference,
            evidence_message_ids=proposal.evidence_message_ids,
            duration_minutes=proposal.duration_minutes,
        )
        await self.persist_case(case.case_id)
        if self.proposal_repo is None:
            self.case_store.mark_closed(
                case.case_id, "failed", "Persistent proposal storage is unavailable."
            )
            await self.persist_case(case.case_id)
            response = await message.reply(
                "I cannot safely create a confirmation right now; no action was taken.",
                mention_author=False,
            )
            conversation.last_bot_message_id = response.id
            return
        try:
            stored = await self.proposal_repo.create(
                guild_id=message.guild.id,
                user_id=message.author.id,
                operation=proposal.action or "",
                arguments=proposal.to_payload(),
                metadata={
                    "source_channel_id": str(message.channel.id),
                    "source_message_id": str(message.id),
                    "case_id": case.case_id,
                },
                ttl_seconds=180,
            )
        except (asyncpg.PostgresError, asyncpg.InterfaceError, TimeoutError, OSError):
            LOGGER.exception("Could not persist confirmation proposal")
            self.case_store.mark_closed(
                case.case_id, "failed", "Persistent proposal storage failed."
            )
            await self.persist_case(case.case_id)
            response = await message.reply(
                "I could not save this confirmation safely; no action was taken.",
                mention_author=False,
            )
            conversation.last_bot_message_id = response.id
            return

        proposal_id = str(stored["id"])
        view = ConfirmationView(
            self,
            proposal_id,
            message.author.id,
            message.guild.id,
        )
        try:
            response = await message.reply(summary, view=view, mention_author=False)
            attached = await self.proposal_repo.attach_confirmation_message(
                proposal_id,
                response.channel.id,
                response.id,
            )
            if not attached:
                raise RuntimeError("The stored proposal was no longer pending.")
        except (discord.HTTPException, asyncpg.PostgresError, asyncpg.InterfaceError, TimeoutError, OSError, RuntimeError):
            LOGGER.exception("Could not attach Discord confirmation for proposal %s", proposal_id)
            await self.proposal_repo.fail_pending(
                proposal_id, "Discord confirmation could not be created."
            )
            self.case_store.mark_closed(
                case.case_id, "failed", "Discord confirmation could not be created."
            )
            await self.persist_case(case.case_id)
            return
        self._schedule_proposal_expiration(
            proposal_id,
            message.guild.id,
            response.channel.id,
            response.id,
            stored["expires_at"],
        )
        conversation.last_bot_message_id = response.id

    async def _create_action_batch(
        self,
        message: discord.Message,
        request: str,
        conversation: Conversation,
        proposals: list[ModerationProposal],
        tool_results: list[dict[str, Any]],
    ) -> None:
        """Validate and persist an ordered multi-action plan before showing controls."""
        if self.proposal_repo is None:
            await message.reply(
                "I cannot safely create this action queue because persistent storage is unavailable. No actions were taken.",
                mention_author=False,
            )
            return
        if not 2 <= len(proposals) <= 10:
            await message.reply("I can queue between 2 and 10 actions at a time. No actions were taken.", mention_author=False)
            return

        resolved: list[ModerationProposal] = []
        for proposal in proposals:
            proposal = self.resolve_target(
                message.guild, message, request, conversation.messages, proposal
            )
            proposal = self.complete_required_fields(proposal)
            if not proposal.is_valid_proposal():
                question = proposal.question or self.missing_fields_question(proposal)
                await message.reply(
                    f"I could not safely prepare the complete action queue: {question} No actions were taken.",
                    mention_author=False,
                )
                return
            if proposal.action in {"delete_by_description", "delete_by_similarity"}:
                await message.reply(
                    "Message-cleanup searches need their own evidence-selection step. Submit that operation separately; no queued actions were created.",
                    mention_author=False,
                )
                return
            member_actions = {"warn", "mute", "unmute", "ban", "unban", "kick", "assign_role", "remove_role"}
            if proposal.action in member_actions:
                target_ids = proposal.target_user_ids or ([proposal.target_user_id] if proposal.target_user_id else [])
                missing = [
                    int(user_id) for user_id in target_ids
                    if message.guild.get_member(int(user_id)) is None and proposal.action != "unban"
                ]
                if missing or not target_ids:
                    await message.reply(
                        "I could not resolve every member target in the action queue. Mention the intended members directly. No actions were taken.",
                        mention_author=False,
                    )
                    return
                proposal.target_user_ids = list(dict.fromkeys(int(user_id) for user_id in target_ids))
                proposal.target_user_id = proposal.target_user_ids[0]
                if not proposal.preview_items:
                    proposal.preview_items = [
                        f"{member.display_name} ({member.id})"
                        for user_id in proposal.target_user_ids
                        if (member := message.guild.get_member(user_id)) is not None
                    ][:MAX_BATCH_TARGETS]
            tool = self.tool_registry.get(proposal.action or "")
            validation_error = tool.validate_arguments(proposal.to_payload())
            if validation_error:
                await message.reply(
                    f"I could not validate one of the planned actions: {validation_error} No actions were taken.",
                    mention_author=False,
                )
                return
            decision = authorize_operation(
                guild=message.guild,
                requester=message.author,
                bot_member=message.guild.me,
                tool=tool,
                proposal=proposal,
                channel=message.channel,
            )
            if not decision.allowed:
                await message.reply(
                    f"I cannot queue one of those actions: {decision.message} No actions were taken.",
                    mention_author=False,
                )
                return
            resolved.append(proposal)

        batch_id = str(uuid.uuid4())
        created: list[dict[str, Any]] = []
        cases: list[int] = []
        try:
            for index, proposal in enumerate(resolved):
                case = self.case_store.record_proposal(
                    guild_id=message.guild.id,
                    moderator_id=message.author.id,
                    target_id=proposal.target_user_id or 0,
                    action=proposal.action or "",
                    reason=proposal.reason,
                    rule_reference=proposal.rule_reference,
                    evidence_message_ids=proposal.evidence_message_ids,
                    duration_minutes=proposal.duration_minutes,
                )
                cases.append(case.case_id)
                await self.persist_case(case.case_id)
                stored = await self.proposal_repo.create(
                    guild_id=message.guild.id,
                    user_id=message.author.id,
                    operation=proposal.action or "",
                    arguments=proposal.to_payload(),
                    metadata={
                        "source_channel_id": str(message.channel.id),
                        "source_message_id": str(message.id),
                        "case_id": case.case_id,
                        "batch_id": batch_id,
                        "batch_index": index,
                        "batch_size": len(resolved),
                    },
                    ttl_seconds=300,
                )
                created.append(stored)
        except Exception:
            LOGGER.exception("Could not persist complete action batch %s", batch_id)
            for record in created:
                await self.proposal_repo.fail_pending(
                    str(record["id"]), "The complete action queue could not be persisted."
                )
            for case_id in cases:
                await self.close_case_if_present(
                    case_id, "failed", "The complete action queue could not be persisted."
                )
            await message.reply(
                "I could not save the complete action queue. No actions were executed.",
                mention_author=False,
            )
            return

        lines = ["**Tetalbot action queue**", "Each step requires its own confirmation. Steps run in order; later steps unlock only after earlier steps succeed."]
        for index, proposal in enumerate(resolved):
            params = json.dumps(proposal.parameters, ensure_ascii=False, default=str)
            if proposal.target_user_ids:
                params = f"targets={proposal.target_user_ids}; " + params
            lines.append(f"{index + 1}. **{(proposal.action or 'action').replace('_', ' ')}** · \`{params[:100]}\`")
        lines.append("Use the matching Confirm button for each step, or Cancel to remove that step and everything depending on it.")
        view = BatchConfirmationView(
            self, batch_id, message.author.id, message.guild.id, created
        )
        try:
            response = await message.reply(
                "\n".join(lines)[:1900],
                view=view,
                mention_author=False,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            for record in created:
                attached = await self.proposal_repo.attach_confirmation_message(
                    str(record["id"]), response.channel.id, response.id
                )
                if not attached:
                    raise RuntimeError("A queued action stopped being pending before confirmation was attached.")
            for record in created:
                self._schedule_proposal_expiration(
                    str(record["id"]),
                    message.guild.id,
                    response.channel.id,
                    response.id,
                    record["expires_at"],
                )
        except Exception:
            LOGGER.exception("Could not publish action batch %s", batch_id)
            for record in created:
                await self.proposal_repo.fail_pending(
                    str(record["id"]), "The Discord confirmation message could not be created."
                )
            for case_id in cases:
                await self.close_case_if_present(
                    case_id, "failed", "The Discord confirmation message could not be created."
                )
            return

        conversation.messages.extend([
            {"role": "user", "content": request},
            {
                "role": "assistant",
                "content": json.dumps({
                    "queued_actions": [proposal.to_payload() for proposal in resolved],
                    "tool_results": tool_results,
                    "batch_id": batch_id,
                }, ensure_ascii=False),
            },
        ])
        conversation.messages = conversation.messages[-20:]
        key = (message.guild.id, message.author.id, message.channel.id)
        if self.conversation_repo is not None:
            await self.conversation_repo.replace(*key, conversation.messages)
        else:
            self.memory_store.replace(*key, conversation.messages)
        conversation.pending_proposal = None
        conversation.last_bot_message_id = response.id

    @staticmethod
    def merge_proposals(
        previous: ModerationProposal | None,
        current: ModerationProposal,
    ) -> ModerationProposal:
        if previous is None:
            return current
        return ModerationProposal(
            status=current.status,
            question=current.question,
            action=current.action or previous.action,
            target_user_id=current.target_user_id or previous.target_user_id,
            target_user_ids=current.target_user_ids or previous.target_user_ids,
            duration_minutes=(
                current.duration_minutes
                if current.duration_minutes is not None
                else previous.duration_minutes
            ),
            reason=current.reason or previous.reason,
            rule_reference=current.rule_reference or previous.rule_reference,
            evidence_message_ids=(
                current.evidence_message_ids or previous.evidence_message_ids
            ),
            parameters=current.parameters or previous.parameters,
            preview_items=current.preview_items or previous.preview_items,
            summary=current.summary or previous.summary,
            continue_after_confirmation=current.continue_after_confirmation,
            continuation_depth=max(current.continuation_depth, previous.continuation_depth),
        )

    @staticmethod
    def complete_required_fields(proposal: ModerationProposal) -> ModerationProposal:
        member_target = proposal.target_user_id is not None or bool(proposal.target_user_ids)
        needs_target = proposal.action in {
            "warn", "mute", "unmute", "ban", "unban", "kick",
            "assign_role", "remove_role",
        }
        has_required_fields = proposal.action is not None and (
            not needs_target or member_target
        ) and (
            proposal.action != "mute" or proposal.duration_minutes is not None
        )
        required_parameters = {
            "create_role": ("role_name", "name"),
            "delete_role": ("role_id", "role_name"),
            "modify_role": ("role_id", "role_name"),
            "assign_role": ("role_id", "role_name"),
            "remove_role": ("role_id", "role_name"),
            "create_channel": ("channel_name", "name"),
            "delete_channel": ("channel_id", "channel_name"),
            "modify_channel": ("channel_id", "channel_name"),
            "lock_channel": ("channel_id", "channel_name"),
            "unlock_channel": ("channel_id", "channel_name"),
            "set_slowmode": ("channel_id", "channel_name"),
            "create_category": ("category_name", "name"),
            "delete_category": ("category_id", "category_name"),
            "rename_server": ("server_name", "name"),
            "set_verification": ("verification_level",),
            "set_afk": ("afk_channel_id", "afk_channel_name"),
            "create_invite": ("channel_id",),
            "revoke_invite": ("invite_code",),
            "create_webhook": ("channel_id", "webhook_name"),
            "edit_webhook": ("webhook_id", "webhook_name"),
            "delete_webhook": ("webhook_id",),
            "create_automod_rule": ("rule_name", "keywords"),
            "edit_automod_rule": ("rule_id",),
            "delete_automod_rule": ("rule_id",),
            "create_emoji": ("channel_id", "message_id", "attachment_id", "asset_name"),
            "delete_emoji": ("asset_id",),
            "create_sticker": ("channel_id", "message_id", "attachment_id", "asset_name", "description"),
            "delete_sticker": ("asset_id",),
            "delete_by_description": ("description",),
            "delete_by_similarity": ("example_message_id",),
            "send_message": ("destination", "content"),
        }
        if proposal.action in required_parameters:
            required_all = {
                "create_forum_post": ("channel_id", "thread_name", "content"),
                "create_event": ("event_name", "start_time", "end_time", "location"),
                "create_webhook": ("channel_id", "webhook_name"),
                "create_automod_rule": ("rule_name", "keywords"),
                "create_emoji": ("channel_id", "message_id", "attachment_id", "asset_name"),
                "create_sticker": (
                    "channel_id", "message_id", "attachment_id", "asset_name", "description"
                ),
                "send_message": ("destination", "content"),
            }
            if proposal.action in required_all:
                fields_present = all(
                    proposal.parameters.get(key)
                    for key in required_all[proposal.action]
                )
            else:
                fields_present = any(
                    proposal.parameters.get(key)
                    for key in required_parameters[proposal.action]
                )
            has_required_fields = has_required_fields and fields_present
        if proposal.action == "delete":
            has_required_fields = has_required_fields and bool(
                proposal.evidence_message_ids or proposal.parameters.get("message_ids")
            )
        if has_required_fields:
            proposal.status = "proposal"
            proposal.question = None
        return proposal

    @staticmethod
    def missing_fields_question(proposal: ModerationProposal) -> str:
        if proposal.action is None:
            return (
                "What moderation action would you like to take? "
                "For example: warn, mute, kick, or ban."
            )
        if proposal.action in {
            "warn", "mute", "unmute", "ban", "unban", "kick",
            "assign_role", "remove_role",
        } and not (proposal.target_user_id or proposal.target_user_ids):
            return "Which server member should I moderate? Mention them or use their username."
        if proposal.action == "mute" and proposal.duration_minutes is None:
            return (
                "How long should I mute this user? "
                "You can say “2 minutes”, “2 hours”, or “indefinitely”."
            )
        if proposal.action in {"delete_by_description", "delete_by_similarity"}:
            return "What messages should I search for, and what time range should I use?"
        return "I need one more detail before I can prepare the confirmation."

    async def prepare_mass_targets(
        self,
        guild: discord.Guild,
        request: str,
        proposal: ModerationProposal,
        *,
        requester_id: int = 0,
    ) -> ModerationProposal:
        params = proposal.parameters
        try:
            minutes = int(params.get("time_range_minutes", 60))
        except (TypeError, ValueError):
            minutes = 60
        candidates = await scan_guild_messages(guild, minutes=minutes, max_results=160)
        description = str(params.get("target_description") or request)
        selected = await self.orchestrator.select_message_ids(
            guild_id=guild.id,
            user_id=requester_id,
            instruction=description,
            candidates=[candidate.as_text() for candidate in candidates],
        )
        # Empty/failed model selection is not evidence. Never broaden a mass
        # moderation request into a keyword guess.
        candidates = [
            candidate
            for candidate in candidates
            if candidate.message.id in selected
        ]
        if not candidates:
            proposal.target_user_id = None
            proposal.target_user_ids = []
            proposal.status = "question"
            proposal.question = (
                "I could not verify matching messages for those members. "
                "Please narrow the request or mention the intended members."
            )
            proposal.preview_items = []
            return proposal

        target_ids = list(dict.fromkeys(candidate.message.author.id for candidate in candidates))
        if len(target_ids) > MAX_BATCH_TARGETS:
            proposal.target_user_id = None
            proposal.target_user_ids = []
            proposal.status = "question"
            proposal.question = (
                f"I found {len(target_ids)} possible members, which exceeds the "
                f"{MAX_BATCH_TARGETS}-member limit for one action. "
                "Please narrow the time range or describe the targets more specifically."
            )
            proposal.preview_items = []
            return proposal
        if not target_ids:
            proposal.target_user_id = None
            proposal.target_user_ids = []
            proposal.status = "question"
            proposal.question = (
                "I could not verify any matching members from recent server messages. "
                "Please narrow the request or mention the intended members."
            )
            proposal.preview_items = []
            return proposal

        proposal.target_user_ids = target_ids
        proposal.target_user_id = target_ids[0] if target_ids else None
        members_by_id = {
            member.id: member
            for member in guild.members
            if member.id in set(target_ids)
        }
        proposal.preview_items = [
            f"{members_by_id[user_id].display_name} (`{user_id}`)"
            for user_id in target_ids[:MAX_BATCH_TARGETS]
            if user_id in members_by_id
        ]
        selected_message_ids = {
            candidate.message.id
            for candidate in candidates
            if candidate.message.author.id in set(target_ids)
        }
        proposal.evidence_message_ids = list(selected_message_ids)
        proposal.summary = (
            f"Selected {len(target_ids)} member(s) from {len(candidates)} matching message(s)."
        )
        return proposal

    @staticmethod
    def resolve_target(
        guild: discord.Guild,
        message: discord.Message,
        request: str,
        history: list[dict[str, str]],
        proposal: ModerationProposal,
    ) -> ModerationProposal:
        if proposal.target_user_id is not None or proposal.target_user_ids:
            return proposal

        mentioned_members = [
            member
            for member in message.mentions
            if guild.me is None or member.id != guild.me.id
        ]
        if len(mentioned_members) == 1:
            proposal.target_user_id = mentioned_members[0].id
            return proposal
        if len(mentioned_members) > 1:
            proposal.target_user_ids = [member.id for member in mentioned_members]
            proposal.target_user_id = mentioned_members[0].id
            return proposal

        searchable_text = " ".join(
            [request]
            + [
                item["content"]
                for item in history
                if item.get("role") == "user"
            ]
        ).lower()
        searchable_text = re.sub(r"[^a-z0-9_ ]+", " ", searchable_text)
        tokens = set(searchable_text.split())
        ignored = {
            "what", "which", "action", "would", "like", "take", "warn", "mute",
            "unmute", "kick", "ban", "unban", "delete", "user", "member", "them",
            "him", "her", "this", "that", "with", "because", "reason", "testing",
            "test", "minutes", "minute", "hours", "hour", "indefinitely", "please",
        }
        tokens.difference_update(ignored)

        matches: dict[int, discord.Member] = {}
        for member in guild.members:
            if member.bot or (guild.me and member.id == guild.me.id):
                continue
            aliases = {
                re.sub(r"[^a-z0-9_]+", "", alias.casefold())
                for alias in (
                    member.name,
                    member.display_name,
                    getattr(member, "global_name", None),
                )
                if alias
            }
            for alias in aliases:
                if len(alias) < 4:
                    continue
                alias_tokens = set(alias.split("_"))
                if alias in searchable_text or alias_tokens.intersection(tokens):
                    matches[member.id] = member
                    break

        if len(matches) == 1:
            proposal.target_user_id = next(iter(matches))
        return proposal

    async def prepare_search_proposal(
        self,
        guild: discord.Guild,
        source_message: discord.Message,
        proposal: ModerationProposal,
    ) -> ModerationProposal:
        """Find a bounded set of messages before showing a destructive preview."""
        params = proposal.parameters
        try:
            minutes = int(params.get("time_range_minutes", 60))
        except (TypeError, ValueError):
            minutes = 60
        example: discord.Message | None = None
        if proposal.action == "delete_by_similarity":
            raw_id = params.get("example_message_id")
            if raw_id is not None:
                try:
                    example = await source_message.channel.fetch_message(int(raw_id))
                except (discord.HTTPException, ValueError, TypeError):
                    for channel in guild.text_channels[:40]:
                        try:
                            example = await channel.fetch_message(int(raw_id))
                            break
                        except (discord.HTTPException, ValueError, TypeError):
                            continue
            if example is None:
                proposal.status = "question"
                proposal.question = "Please provide a message ID I can use as the similarity example."
                return proposal

        candidates = await scan_guild_messages(
            guild,
            minutes=minutes,
            example=example,
            max_results=160,
        )
        if example is not None:
            reference = set(re.findall(r"[a-z0-9]{3,}", example.content.casefold()))
            scored = []
            for candidate in candidates:
                words = set(re.findall(r"[a-z0-9]{3,}", candidate.message.content.casefold()))
                overlap = len(reference & words) / max(1, len(reference | words))
                if example.attachments and candidate.message.attachments:
                    overlap = max(overlap, 0.35)
                if overlap >= 0.25:
                    scored.append((overlap, candidate))
            candidates = [item[1] for item in sorted(scored, key=lambda item: item[0], reverse=True)]
        else:
            description = str(params.get("description") or proposal.reason or "").casefold()
            words = {
                word for word in re.findall(r"[a-z0-9]{3,}", description)
                if word not in {"delete", "remove", "messages", "message", "last", "minutes"}
            }
            if words:
                candidates = [
                    candidate for candidate in candidates
                    if words.intersection(
                        set(re.findall(r"[a-z0-9]{3,}", candidate.message.content.casefold()))
                    )
                ]

        if candidates:
            instruction = (
                str(params.get("description") or "")
                if example is None
                else f"Find messages similar to this example: {example.content[:500]}"
            )
            selected_ids = await self.orchestrator.select_message_ids(
                guild_id=guild.id,
                user_id=getattr(source_message.author, "id", 0),
                instruction=instruction,
                candidates=[candidate.as_text() for candidate in candidates],
            )
            candidates = [
                candidate
                for candidate in candidates
                if candidate.message.id in selected_ids
            ]
        if not candidates:
            proposal.parameters["message_ids"] = []
            proposal.parameters["message_channels"] = {}
            proposal.evidence_message_ids = []
            proposal.preview_items = []
            proposal.status = "question"
            proposal.question = (
                "I could not verify any messages matching that description. "
                "Please make the description more specific or adjust the time range."
            )
            return proposal
        candidates = candidates[:50]
        proposal.parameters["message_ids"] = [candidate.message.id for candidate in candidates]
        proposal.parameters["message_channels"] = {
            str(candidate.message.id): candidate.message.channel.id for candidate in candidates
        }
        proposal.evidence_message_ids = [candidate.message.id for candidate in candidates]
        proposal.preview_items = [candidate.as_text() for candidate in candidates[:20]]
        proposal.summary = (
            f"Found {len(candidates)} matching message(s) across "
            f"{len({candidate.message.channel.id for candidate in candidates})} channel(s)."
        )
        proposal.status = "proposal"
        proposal.question = None
        return proposal

    @staticmethod
    def proposal_text(
        proposal: ModerationProposal,
        target: discord.abc.User | None,
    ) -> str:
        reason = proposal.reason or "No reason provided"
        rule = f" under {proposal.rule_reference}" if proposal.rule_reference else ""
        duration = (
            f" for {format_duration(proposal.duration_minutes)}"
            if proposal.action == "mute"
            else ""
        )
        target_text = f" {target.mention}" if target else ""
        if proposal.target_user_ids and len(proposal.target_user_ids) > 1:
            target_text = f" {len(proposal.target_user_ids)} members"
        lines = [
            f"I propose to **{proposal.action}{target_text}**{duration}{rule}.",
            f"Reason: {reason}",
            proposal.summary or "No additional explanation provided.",
        ]
        if proposal.preview_items:
            lines.append("\n".join(f"• {item[:100]}" for item in proposal.preview_items))
            item_count = (
                len(proposal.target_user_ids)
                if proposal.target_user_ids
                else len(proposal.evidence_message_ids)
            )
            if item_count > len(proposal.preview_items):
                lines.append(
                    f"...and {item_count - len(proposal.preview_items)} more."
                )
        lines.extend(["", "Confirm this action?"])
        return "\n".join(lines)

    async def execute_proposal(
        self,
        interaction: discord.Interaction,
        source_message: discord.Message,
        proposal: ModerationProposal,
    ) -> str | dict[str, Any]:
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            raise ValueError("This action must run in a server.")
        tool = self.tool_registry.get(proposal.action or "")
        validation_error = tool.validate_arguments(proposal.to_payload())
        if validation_error:
            raise ValueError(validation_error)
        decision = authorize_operation(
            guild=interaction.guild,
            requester=interaction.user,
            bot_member=interaction.guild.me,
            tool=tool,
            proposal=proposal,
            channel=source_message.channel,
        )
        if not decision.allowed:
            raise ValueError(decision.message)
        return await self._execute_proposal_impl(
            interaction,
            source_message,
            proposal,
        )

    async def _resume_agent_after_confirmation(
        self,
        interaction: discord.Interaction,
        source_message: discord.Message,
        completed_proposal: ModerationProposal,
        outcome: str,
    ) -> None:
        """Continue a bounded multi-step request after one confirmed action.

        Continuation intent is persisted in the proposal payload. Each new
        modifying step receives its own proposal and confirmation, including
        when the bot was restarted between steps.
        """
        guild = interaction.guild
        requester = interaction.user
        if guild is None or not isinstance(requester, discord.Member):
            return
        key = (guild.id, requester.id, source_message.channel.id)
        conversation = self.conversations.setdefault(key, Conversation())
        if self.conversation_repo is not None:
            conversation.messages = await self.conversation_repo.load(*key)
        else:
            conversation.messages = self.memory_store.load(*key)

        original_request = strip_bot_mention(source_message.content, self.user.id if self.user else 0)
        continuation_request = (
            "Continue the original multi-step request: " + original_request
            + "\nThe previously confirmed action " + str(completed_proposal.action)
            + " succeeded. Its result was: " + outcome[:1200]
            + "\nContinue with the next dependent step only. Do not repeat completed work. "
            + "Every further modifying action must be proposed for a separate confirmation."
        )
        conversation.messages.append({
            "role": "assistant",
            "content": json.dumps({"confirmed_action": completed_proposal.action, "outcome": outcome}),
        })
        config = self.config_store.get(guild.id)
        try:
            result = await self.orchestrator.run_agent_task(
                source_message,
                continuation_request,
                config,
                self.rules_cache.get(guild.id, []),
                conversation.messages[-20:],
                ToolExecutionContext(
                    self, interaction, source_message, guild, requester, guild.me,
                    self._execute_low_risk_tool,
                ),
            )
        except Exception:
            LOGGER.exception("Could not continue confirmed multi-step request")
            await interaction.channel.send(
                "The confirmed step succeeded, but I could not safely continue the remaining work. "
                "You can issue the remaining instruction separately.",
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return

        proposal = result.proposal
        if proposal is None:
            response_text = result.final_response or "The remaining steps are complete."
            conversation.messages.append({"role": "assistant", "content": response_text})
            conversation.messages = conversation.messages[-20:]
            if self.conversation_repo is not None:
                await self.conversation_repo.replace(*key, conversation.messages)
            else:
                self.memory_store.replace(*key, conversation.messages)
            response = await interaction.channel.send(
                response_text, allowed_mentions=discord.AllowedMentions.none()
            )
            conversation.last_bot_message_id = response.id
            return

        proposal.continuation_depth = completed_proposal.continuation_depth + 1
        proposal = self.resolve_target(
            guild, source_message, continuation_request, conversation.messages, proposal
        )
        proposal = self.complete_required_fields(proposal)
        if not proposal.is_valid_proposal():
            question = proposal.question or self.missing_fields_question(proposal)
            response = await interaction.channel.send(
                question, allowed_mentions=discord.AllowedMentions.none()
            )
            conversation.messages.append({"role": "assistant", "content": question})
            conversation.messages = conversation.messages[-20:]
            if self.conversation_repo is not None:
                await self.conversation_repo.replace(*key, conversation.messages)
            else:
                self.memory_store.replace(*key, conversation.messages)
            conversation.last_bot_message_id = response.id
            return

        target = guild.get_member(proposal.target_user_id or 0)
        case = self.case_store.record_proposal(
            guild_id=guild.id, moderator_id=requester.id,
            target_id=proposal.target_user_id or 0, action=proposal.action,
            reason=proposal.reason, rule_reference=proposal.rule_reference,
            evidence_message_ids=proposal.evidence_message_ids,
            duration_minutes=proposal.duration_minutes,
        )
        await self.persist_case(case.case_id)
        if self.proposal_repo is None:
            await self.close_case_if_present(case.case_id, "failed", "Proposal storage unavailable.")
            await interaction.channel.send("I could not save the next confirmation. No further action was taken.")
            return
        stored = await self.proposal_repo.create(
            guild_id=guild.id, user_id=requester.id, operation=proposal.action or "",
            arguments=proposal.to_payload(),
            metadata={
                "source_channel_id": str(source_message.channel.id),
                "source_message_id": str(source_message.id),
                "case_id": case.case_id,
                "continuation": True,
            },
            ttl_seconds=180,
        )
        proposal_id = str(stored["id"])
        view = ConfirmationView(self, proposal_id, requester.id, guild.id)
        summary = self.proposal_text(proposal, target)
        try:
            response = await interaction.channel.send(
                summary, view=view, allowed_mentions=discord.AllowedMentions.none()
            )
            attached = await self.proposal_repo.attach_confirmation_message(
                proposal_id, response.channel.id, response.id
            )
            if not attached:
                raise RuntimeError("The stored continuation proposal was no longer pending.")
        except Exception:
            LOGGER.exception("Could not create continuation confirmation for proposal %s", proposal_id)
            await self.proposal_repo.fail_pending(proposal_id, "Continuation confirmation could not be created.")
            await self.close_case_if_present(case.case_id, "failed", "Continuation confirmation could not be created.")
            return
        self._schedule_proposal_expiration(
            proposal_id, guild.id, response.channel.id, response.id, stored["expires_at"]
        )
        conversation.messages.append({
            "role": "assistant",
            "content": json.dumps({"confirmation_required": proposal.to_payload(), "tool_results": result.tool_results or []}, ensure_ascii=False),
        })
        conversation.messages = conversation.messages[-20:]
        if self.conversation_repo is not None:
            await self.conversation_repo.replace(*key, conversation.messages)
        else:
            self.memory_store.replace(*key, conversation.messages)
        conversation.last_bot_message_id = response.id

    async def _execute_low_risk_tool(
        self,
        tool_name: str,
        proposal: ModerationProposal,
        tool_context: ToolExecutionContext,
    ) -> ToolResult:
        guild = tool_context.guild
        requester = tool_context.requester
        source_message = tool_context.source_message
        if guild is None or requester is None or self.proposal_repo is None:
            return ToolResult(
                False,
                tool_name,
                error={
                    "code": "PERSISTENCE_OR_GUILD_UNAVAILABLE",
                    "message": "Automatic execution is unavailable; no action was taken.",
                },
            )
        config = self.config_store.get(guild.id)
        if requires_confirmation(proposal.action, proposal, config):
            return ToolResult(
                False,
                tool_name,
                error={
                    "code": "CONFIRMATION_REQUIRED",
                    "message": "This action is not enabled for automatic execution.",
                },
            )
        tool = self.tool_registry.get(tool_name)
        authorization = authorize_operation(
            guild=guild,
            requester=requester,
            bot_member=guild.me,
            tool=tool,
            proposal=proposal,
            channel=source_message.channel,
        )
        if not authorization.allowed:
            return ToolResult(
                False,
                tool_name,
                error={"code": authorization.code, "message": authorization.message},
            )

        case = self.case_store.record_proposal(
            guild_id=guild.id,
            moderator_id=requester.id,
            target_id=proposal.target_user_id or 0,
            action=proposal.action or tool_name,
            reason=proposal.reason,
            rule_reference=proposal.rule_reference,
            evidence_message_ids=proposal.evidence_message_ids,
            duration_minutes=proposal.duration_minutes,
        )
        await self.persist_case(case.case_id)
        try:
            stored = await self.proposal_repo.create(
                guild_id=guild.id,
                user_id=requester.id,
                operation=tool_name,
                arguments=proposal.to_payload(),
                metadata={
                    "source_channel_id": str(source_message.channel.id),
                    "source_message_id": str(source_message.id),
                    "case_id": case.case_id,
                    "automatic": True,
                },
            )
            claimed = await self.proposal_repo.claim_for_execution(
                str(stored["id"]),
                guild_id=guild.id,
                user_id=requester.id,
            )
        except (asyncpg.PostgresError, asyncpg.InterfaceError, TimeoutError, OSError, ProposalStateError) as exc:
            LOGGER.exception("Could not persist automatic tool execution")
            await self.close_case_if_present(
                case.case_id, "failed", "Automatic execution could not be recorded."
            )
            return ToolResult(
                False,
                tool_name,
                error={
                    "code": "PERSISTENCE_FAILED",
                    "message": "The action was not run because it could not be recorded.",
                },
            )

        try:
            interaction_proxy = type(
                "MessageActionContext",
                (),
                {"guild": guild, "user": requester},
            )()
            outcome = await self.execute_proposal(
                interaction_proxy,
                source_message,
                proposal,
            )
        except Exception as exc:
            # Catch execution failures only. Database finalization below must not
            # be swallowed or mistaken for a Discord action failure.
            reason = _discord_failure_reason(exc)
            LOGGER.warning("Automatic low-risk operation failed: %s", reason)
            await self.proposal_repo.finish_execution(
                str(claimed["id"]),
                status="failed",
                result={"message": reason},
            )
            await self.close_case_if_present(case.case_id, "failed", reason)
            return ToolResult(
                False,
                tool_name,
                error={"code": "TOOL_EXECUTION_FAILED", "message": reason},
                metadata={
                    "guild_id": str(guild.id),
                    "proposal_id": str(claimed["id"]),
                },
            )

        status = (
            "partially_completed"
            if outcome.startswith("Partially completed:")
            else "completed"
        )
        await self.proposal_repo.finish_execution(
            str(claimed["id"]),
            status=status,
            result={"outcome": outcome},
        )
        await self.confirm_case_if_present(case.case_id, outcome, status)
        try:
            await post_log(
                guild,
                config,
                requester,
                proposal,
                outcome,
            )
        except discord.HTTPException:
            LOGGER.exception("Could not log automatic action %s", claimed["id"])
        return ToolResult(
            True,
            tool_name,
            data=outcome,
            metadata={
                "guild_id": str(guild.id),
                "proposal_id": str(claimed["id"]),
                "automatic": True,
            },
        )

    async def _execute_registered_proposal(
        self,
        context: ToolExecutionContext,
        proposal: ModerationProposal,
    ) -> Any:
        if context.interaction is None:
            if proposal.action == "list_roles" and context.guild is not None:
                return roles.list_roles(context.guild)
            if (
                proposal.action == "discord_api"
                and context.guild is not None
                and context.requester is not None
                and is_read_only_operation(
                    str(proposal.parameters.get("resource_type") or "").lower(),
                    str(proposal.parameters.get("method") or ""),
                )
            ):
                read_context = SimpleNamespace(guild=context.guild, user=context.requester)
                return await execute_discord_api_operation(read_context, proposal)
            raise ValueError("This operation can only run after moderator confirmation.")
        return await self._execute_proposal_impl(
            context.interaction,
            context.source_message,
            proposal,
        )

    async def _execute_proposal_impl(
        self,
        interaction: discord.Interaction,
        source_message: discord.Message,
        proposal: ModerationProposal,
    ) -> str:
        if not interaction.guild or not isinstance(interaction.user, discord.Member):
            raise ValueError("This action must be confirmed by a server member.")
        action = proposal.action
        if action not in ACTION_NAMES:
            raise ValueError("The proposal contained an unsupported action.")

        if action == "discord_api":
            return await execute_discord_api_operation(interaction, proposal)
        if action == "list_roles":
            return roles.list_roles(interaction.guild)
        if action == "remove_automation":
            repository = self.automation_repo
            if repository is None:
                raise ValueError("TetalBot automation storage is unavailable; no rule was changed.")
            rules = await repository.list_enabled_for_guild(interaction.guild.id, limit=50)
            raw_rule_id = str(proposal.parameters.get("rule_id") or "").strip()
            raw_rule_name = str(proposal.parameters.get("rule_name") or "").strip()
            selected = resolve_automation_rule(
                rules,
                rule_id=raw_rule_id or None,
                rule_name=raw_rule_name or None,
            )
            if selected is None:
                if raw_rule_id:
                    raise ValueError("No enabled TetalBot automation with that UUID exists in this server.")
                raise ValueError(f"No enabled TetalBot automation closely matches **{raw_rule_name}**.")
            rule_id = str(selected["id"])
            if not await repository.disable(rule_id, interaction.guild.id):
                raise ValueError("That automation is no longer enabled. Refresh the list and try again.")
            return f"Disabled TetalBot automation **{str(selected.get('name') or 'Unnamed automation')}** (`{rule_id}`)."
        if action == "send_message":
            params = proposal.parameters
            destination = str(params.get("destination", "")).strip().lower()
            content = str(params.get("content", "")).strip()
            if not content or len(content) > 2000:
                raise ValueError("Message content must be between 1 and 2000 characters.")
            if destination == "dm":
                raw_user_id = params.get("target_user_id")
                if raw_user_id is None:
                    raise ValueError("A target_user_id is required for a DM.")
                try:
                    target = interaction.guild.get_member(int(raw_user_id))
                except (TypeError, ValueError):
                    target = None
                if target is None:
                    raise ValueError("I can only DM a member of this server. That member was not found.")
                try:
                    dm = target.dm_channel or await target.create_dm()
                    await dm.send(content, allowed_mentions=discord.AllowedMentions.none())
                except discord.Forbidden as exc:
                    raise ValueError("Discord does not allow the bot to DM that member. They may have DMs disabled.") from exc
                return f"sent the DM to **{target.display_name}**."
            if destination == "channel":
                raw_channel_id = params.get("channel_id")
                target_channel = None
                if raw_channel_id is not None:
                    try:
                        target_channel = interaction.guild.get_channel_or_thread(int(raw_channel_id))
                    except (TypeError, ValueError):
                        target_channel = None
                if target_channel is None and params.get("channel_name"):
                    wanted = str(params["channel_name"]).strip().lstrip("#").casefold()
                    matches = [ch for ch in interaction.guild.text_channels if ch.name.casefold() == wanted]
                    if len(matches) == 1:
                        target_channel = matches[0]
                    elif len(matches) > 1:
                        raise ValueError("That channel name is ambiguous. Use its channel ID.")
                if not isinstance(target_channel, (discord.TextChannel, discord.Thread)):
                    raise ValueError("Choose an accessible text channel in this server.")
                requester_perms = target_channel.permissions_for(interaction.user)
                bot_perms = target_channel.permissions_for(interaction.guild.me)
                if not requester_perms.view_channel or not requester_perms.send_messages:
                    raise ValueError("You need View Channel and Send Messages in the destination channel.")
                if not bot_perms.view_channel or not bot_perms.send_messages:
                    raise ValueError("The bot needs View Channel and Send Messages in the destination channel.")
                allowed_mentions = discord.AllowedMentions.none()
                raw_mention_id = params.get("mention_user_id")
                if raw_mention_id is not None:
                    try:
                        mention_target = interaction.guild.get_member(int(raw_mention_id))
                    except (TypeError, ValueError):
                        mention_target = None
                    if mention_target is None:
                        raise ValueError("The requested mention target is not a current server member.")
                    allowed_mentions = discord.AllowedMentions(users=[mention_target])
                await target_channel.send(content, allowed_mentions=allowed_mentions)
                return f"sent the message in {target_channel.mention}."
            raise ValueError("Choose destination='channel' or destination='dm'.")
        if action in {
            "create_role", "delete_role", "modify_role", "assign_role", "remove_role",
        }:
            if not interaction.user.guild_permissions.manage_roles:
                raise ValueError("Manage Roles permission is required.")
            return await roles.execute(interaction, proposal)
        if action in {
            "create_channel", "delete_channel", "modify_channel", "lock_channel",
            "unlock_channel", "set_slowmode", "create_category", "delete_category",
        }:
            if not interaction.user.guild_permissions.manage_channels:
                raise ValueError("Manage Channels permission is required.")
            return await channels.execute(interaction, proposal)
        if action in {"create_thread", "create_forum_post", "archive_thread", "unarchive_thread", "lock_thread", "unlock_thread"}:
            return await threads.execute(interaction, source_message, proposal)
        if action in {"create_event", "edit_event", "delete_event"}:
            return await events.execute(interaction, proposal)
        if action in {"create_invite", "revoke_invite", "create_webhook", "edit_webhook", "delete_webhook"}:
            return await resources.execute(interaction, proposal)
        if action in {"create_automod_rule", "edit_automod_rule", "delete_automod_rule"}:
            return await automod.execute(interaction, proposal)
        if action in {"create_emoji", "delete_emoji", "create_sticker", "delete_sticker"}:
            return await assets.execute(interaction, proposal)
        if action in {"rename_server", "set_afk", "set_verification"}:
            if not interaction.user.guild_permissions.manage_guild:
                raise ValueError("Manage Server permission is required.")
            return await server.execute(interaction, proposal)
        if action in {"delete_by_description", "delete_by_similarity"}:
            ids = proposal.parameters.get("message_ids", [])
            channel_ids = proposal.parameters.get("message_channels", {})
            self._require_message_delete_permissions(
                interaction,
                [
                    int(channel_id)
                    for channel_id in channel_ids.values()
                    if channel_id is not None
                ],
            )
            return await self._delete_messages(
                interaction.guild,
                ids,
                {"message_channels": channel_ids},
                proposal,
            )
        if action == "delete":
            ids = proposal.parameters.get("message_ids") or proposal.evidence_message_ids
            if len(ids) > 200:
                raise ValueError("A single deletion confirmation is limited to 200 messages. Split larger cleanups into separate requests.")
            if len(ids) > 1:
                channel_ids = proposal.parameters.get("message_channels", {})
                self._require_message_delete_permissions(
                    interaction,
                    [
                        int(channel_id)
                        for channel_id in channel_ids.values()
                        if channel_id is not None
                    ],
                )
                return await self._delete_messages(interaction.guild, ids, proposal.parameters, proposal)
            self._require_message_delete_permissions(
                interaction, [source_message.channel.id]
            )
            message = await self.resolve_evidence_message(source_message, ids)
            if message is None:
                raise ValueError("I could not resolve a message to delete.")
            if message.guild is None or message.guild.id != interaction.guild.id:
                raise ValueError("The target message is outside this server.")
            self._require_message_delete_permissions(
                interaction, [message.channel.id]
            )
            return await delete.execute(interaction, message, proposal)

        target_ids = proposal.target_user_ids or (
            [proposal.target_user_id] if proposal.target_user_id is not None else []
        )
        if not target_ids:
            raise ValueError("The proposal was missing a valid target.")
        successes: list[str] = []
        failures: list[tuple[str, str]] = []
        required_permission = {
            "warn": "moderate_members",
            "mute": "moderate_members",
            "unmute": "moderate_members",
            "ban": "ban_members",
            "unban": "ban_members",
            "kick": "kick_members",
        }.get(action)
        if required_permission:
            if not getattr(interaction.user.guild_permissions, required_permission):
                raise ValueError(
                    f"{required_permission.replace('_', ' ').capitalize()} permission is required."
                )
            bot_member = interaction.guild.me
            if bot_member is None or not getattr(
                bot_member.guild_permissions, required_permission
            ):
                raise ValueError(
                    f"The bot needs {required_permission.replace('_', ' ')} permission."
                )

        for target_id in target_ids:
            label = f"<@{target_id}> (`{target_id}`)"
            try:
                target_member = interaction.guild.get_member(target_id)
                if action == "unban":
                    if target_member is not None:
                        raise ValueError(
                            "That user is still in the server; use unmute instead."
                        )
                    target_user = await self.resolve_banned_user(
                        interaction.guild, target_id
                    )
                    if target_user is None:
                        raise ValueError("I could not find that banned user.")
                    result = await unban.execute(interaction, target_user, proposal)
                else:
                    if target_member is None:
                        raise ValueError("That user is not currently in the server.")
                    allowed, reason = can_moderate(interaction.user, target_member)
                    if not allowed:
                        raise ValueError(reason)
                    if action == "warn":
                        result = await warn.execute(interaction, target_member, proposal)
                    elif action == "mute":
                        result = await mute.execute(interaction, target_member, proposal)
                    elif action == "unmute":
                        result = await unmute.execute(interaction, target_member, proposal)
                    elif action == "ban":
                        result = await ban.execute(interaction, target_member, proposal)
                    elif action == "kick":
                        result = await kick.execute(interaction, target_member, proposal)
                    else:
                        raise ValueError("Unsupported member action.")
                successes.append(label)
                LOGGER.info("Moderation action %s succeeded for user %s", action, target_id)
            except Exception as exc:
                failures.append((label, _discord_failure_reason(exc)))
                if isinstance(exc, (discord.HTTPException, ValueError)):
                    LOGGER.warning(
                        "Moderation action %s failed for user %s: %s",
                        action,
                        target_id,
                        _discord_failure_reason(exc),
                    )
                else:
                    LOGGER.exception(
                        "Unexpected moderation action %s failure for user %s",
                        action,
                        target_id,
                    )
        return _batch_outcome(successes, failures)

    @staticmethod
    def _require_message_delete_permissions(
        interaction: discord.Interaction,
        channel_ids: list[int],
    ) -> None:
        guild = interaction.guild
        requester = interaction.user
        bot_member = guild.me if guild is not None else None
        if guild is None or not isinstance(requester, discord.Member) or bot_member is None:
            raise ValueError("A current server permission context is required.")
        unique_channel_ids = set(channel_ids)
        if not unique_channel_ids:
            unique_channel_ids = {interaction.channel_id} if interaction.channel_id else set()
        if not unique_channel_ids:
            raise ValueError("I could not identify the channel permissions to check.")
        for channel_id in unique_channel_ids:
            channel = guild.get_channel(channel_id)
            if not isinstance(channel, discord.TextChannel):
                raise ValueError("A target message channel is unavailable in this server.")
            if not channel.permissions_for(requester).manage_messages:
                raise ValueError(
                    "You need Manage Messages permission in every affected channel."
                )
            if not channel.permissions_for(bot_member).manage_messages:
                raise ValueError(
                    "The bot needs Manage Messages permission in every affected channel."
                )

    @staticmethod
    async def _delete_messages(
        guild: discord.Guild,
        message_ids: list[int],
        parameters: dict[str, object],
        proposal: ModerationProposal,
    ) -> str:
        channels = parameters.get("message_channels", {})
        successes: list[str] = []
        failures: list[tuple[str, str]] = []
        for raw_id in message_ids:
            try:
                message_id = int(raw_id)
                channel_id = (
                    channels.get(str(message_id))
                    if isinstance(channels, dict)
                    else None
                )
                channel = guild.get_channel(int(channel_id)) if channel_id else None
                if not isinstance(channel, discord.TextChannel):
                    raise ValueError("The message channel is unavailable.")
                message = await channel.fetch_message(int(raw_id))
                await message.delete()
                successes.append(f"`{message_id}`")
            except Exception as exc:
                failures.append((f"`{raw_id}`", _discord_failure_reason(exc)))
        return _batch_outcome(successes, failures)

    @staticmethod
    async def resolve_banned_user(
        guild: discord.Guild, user_id: int
    ) -> discord.User | None:
        try:
            async for entry in guild.bans(limit=None):
                if entry.user.id == user_id:
                    return entry.user
        except discord.HTTPException:
            return None
        return None

    @staticmethod
    async def resolve_evidence_message(
        source_message: discord.Message, evidence_ids: list[int]
    ) -> discord.Message | None:
        channel = source_message.channel
        for message_id in evidence_ids:
            try:
                return await channel.fetch_message(message_id)
            except discord.HTTPException:
                continue
        return None


bot = ModerationBot()



@bot.tree.command(
    name="auto_action",
    description="Enable or disable automatic execution for one approved low-risk action",
)
@app_commands.checks.has_permissions(manage_guild=True)
@app_commands.choices(action=[
    app_commands.Choice(name="Warn", value="warn"),
    app_commands.Choice(name="Mute", value="mute"),
    app_commands.Choice(name="Unmute", value="unmute"),
    app_commands.Choice(name="Modify channel", value="modify_channel"),
    app_commands.Choice(name="Unlock channel", value="unlock_channel"),
    app_commands.Choice(name="Set slowmode", value="set_slowmode"),
    app_commands.Choice(name="Rename server", value="rename_server"),
    app_commands.Choice(name="Set AFK", value="set_afk"),
])
async def auto_action_command(
    interaction: discord.Interaction,
    action: str,
    enabled: bool,
) -> None:
    if interaction.guild is None:
        await interaction.response.send_message("This command only works in a server.", ephemeral=True)
        return
    if action not in LOW_RISK_ACTIONS:
        await interaction.response.send_message("That action is not eligible for automatic execution.", ephemeral=True)
        return
    config = bot.config_store.get(interaction.guild.id)
    allowed = set(config.auto_execute_low_risk_actions)
    if enabled:
        allowed.add(action)
    else:
        allowed.discard(action)
    config.auto_execute_low_risk_actions = sorted(allowed)
    bot.config_store.save()
    persisted = await bot.persist_guild_config(interaction.guild.id)
    state = "enabled" if enabled else "disabled"
    if not persisted:
        await interaction.response.send_message(
            "The local setting was saved, but PostgreSQL synchronization failed. Check the bot logs before relying on this change.",
            ephemeral=True,
        )
        return
    await interaction.response.send_message(
        f"Automatic execution for {action} is now {state}.",
        ephemeral=True,
    )




@bot.tree.command(name="guild_settings", description="Configure common Discord server-wide settings")
@app_commands.describe(
    system_channel="Channel for system messages",
    rules_channel="Server rules channel",
    updates_channel="Community updates channel",
    description="Server description (leave blank to keep unchanged)",
    default_notifications="Default notification setting for new members",
    explicit_content_filter="Explicit media scanning level",
)
@app_commands.choices(
    default_notifications=[
        app_commands.Choice(name="All messages", value="all_messages"),
        app_commands.Choice(name="Only mentions", value="only_mentions"),
    ],
    explicit_content_filter=[
        app_commands.Choice(name="Disabled", value="disabled"),
        app_commands.Choice(name="Members without roles", value="members_without_roles"),
        app_commands.Choice(name="All members", value="all_members"),
    ],
)
@app_commands.checks.has_permissions(manage_guild=True)
async def guild_settings_command(
    interaction: discord.Interaction,
    system_channel: discord.TextChannel | None = None,
    rules_channel: discord.TextChannel | None = None,
    updates_channel: discord.TextChannel | None = None,
    description: str | None = None,
    default_notifications: str | None = None,
    explicit_content_filter: str | None = None,
) -> None:
    guild = interaction.guild
    if guild is None:
        await interaction.response.send_message("This command only works in a server.", ephemeral=True)
        return
    changes: dict[str, Any] = {}
    for channel, key in (
        (system_channel, "system_channel"),
        (rules_channel, "rules_channel"),
        (updates_channel, "public_updates_channel"),
    ):
        if channel is not None:
            if channel.guild.id != guild.id:
                await interaction.response.send_message("All selected channels must belong to this server.", ephemeral=True)
                return
            changes[key] = channel
    if description is not None:
        if len(description) > 120:
            await interaction.response.send_message("Server descriptions are limited to 120 characters.", ephemeral=True)
            return
        changes["description"] = description or None
    notification_values = {
        "all_messages": discord.NotificationLevel.all_messages,
        "only_mentions": discord.NotificationLevel.only_mentions,
    }
    filter_values = {
        "disabled": discord.ContentFilter.disabled,
        "members_without_roles": discord.ContentFilter.no_role,
        "all_members": discord.ContentFilter.all_members,
    }
    if default_notifications is not None:
        if default_notifications not in notification_values:
            await interaction.response.send_message("Invalid default notification setting.", ephemeral=True)
            return
        changes["default_notifications"] = notification_values[default_notifications]
    if explicit_content_filter is not None:
        if explicit_content_filter not in filter_values:
            await interaction.response.send_message("Invalid explicit content filter setting.", ephemeral=True)
            return
        changes["explicit_content_filter"] = filter_values[explicit_content_filter]
    if not changes:
        await interaction.response.send_message("Provide at least one setting to change.", ephemeral=True)
        return
    try:
        await guild.edit(reason=f"Guild settings updated by {interaction.user} ({interaction.user.id})", **changes)
    except discord.Forbidden:
        await interaction.response.send_message("The bot needs Manage Server permission to change these settings.", ephemeral=True)
        return
    except discord.HTTPException:
        LOGGER.exception("Guild settings update failed for guild=%s", guild.id)
        await interaction.response.send_message("Discord rejected the settings update. Check the bot logs.", ephemeral=True)
        return
    changed = ", ".join(sorted(changes))
    await interaction.response.send_message(f"Updated server settings: {changed}.", ephemeral=True)


@bot.tree.command(name="context_settings", description="Configure message retention and indexing exclusions")
@app_commands.describe(
    retention_days="How long indexed message text is retained (1-3650 days)",
    excluded_channel="Channel to include or exclude from message indexing",
    exclude_channel="True excludes the selected channel; false includes it",
)
@app_commands.checks.has_permissions(manage_guild=True)
async def context_settings_command(
    interaction: discord.Interaction,
    retention_days: app_commands.Range[int, 1, 3650] | None = None,
    excluded_channel: discord.TextChannel | None = None,
    exclude_channel: bool = True,
) -> None:
    guild = interaction.guild
    if guild is None:
        await interaction.response.send_message("This command only works in a server.", ephemeral=True)
        return
    config = bot.config_store.get(guild.id)
    if retention_days is not None:
        config.retention_days = int(retention_days)
    if excluded_channel is not None:
        excluded = set(config.excluded_channel_ids)
        if exclude_channel:
            excluded.add(excluded_channel.id)
        else:
            excluded.discard(excluded_channel.id)
        config.excluded_channel_ids = sorted(excluded)
    bot.config_store.save()
    persisted = await bot.persist_guild_config(guild.id)
    if not persisted:
        await interaction.response.send_message("Local settings were saved, but PostgreSQL synchronization failed. Check logs.", ephemeral=True)
        return
    excluded_text = ", ".join(f"<#{item}>" for item in config.excluded_channel_ids) or "none"
    await interaction.response.send_message(
        f"Message retention: {config.retention_days} days. Excluded channels: {excluded_text}.",
        ephemeral=True,
    )


@bot.tree.command(name="context_backfill", description="Explicitly index recent history from one channel")
@app_commands.describe(
    channel="The channel whose history should be indexed",
    days="Only messages from this many recent days are eligible",
    max_messages="Maximum messages to inspect (up to 5000)",
)
@app_commands.checks.has_permissions(manage_guild=True)
async def context_backfill_command(
    interaction: discord.Interaction,
    channel: discord.TextChannel,
    days: app_commands.Range[int, 1, 90] = 7,
    max_messages: app_commands.Range[int, 1, 5000] = 1000,
) -> None:
    guild = interaction.guild
    requester = interaction.user
    bot_member = guild.me if guild else None
    if guild is None or not isinstance(requester, discord.Member) or bot_member is None:
        await interaction.response.send_message("This command requires a server member.", ephemeral=True)
        return
    if channel.guild.id != guild.id:
        await interaction.response.send_message("Choose a channel from this server.", ephemeral=True)
        return
    for member, label in ((requester, "You"), (bot_member, "The bot")):
        permissions = channel.permissions_for(member)
        if not permissions.view_channel or not permissions.read_message_history:
            await interaction.response.send_message(
                f"{label} needs View Channel and Read Message History in {channel.mention}.",
                ephemeral=True,
            )
            return
    config = bot.config_store.get(guild.id)
    if channel.id in config.excluded_channel_ids:
        await interaction.response.send_message("That channel is excluded from indexing. Remove the exclusion first.", ephemeral=True)
        return
    if bot.context_repo is None:
        await interaction.response.send_message("PostgreSQL context storage is unavailable.", ephemeral=True)
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    from datetime import timedelta
    cutoff = discord.utils.utcnow() - timedelta(days=days)
    scanned = stored = 0
    try:
        async for message in channel.history(limit=int(max_messages), after=cutoff, oldest_first=True):
            scanned += 1
            await bot.context_repo.store_message(message)
            if not message.author.bot:
                stored += 1
    except discord.Forbidden:
        await interaction.followup.send("Discord denied access while reading channel history.", ephemeral=True)
        return
    except discord.HTTPException:
        LOGGER.exception("Context backfill failed for guild=%s channel=%s", guild.id, channel.id)
        await interaction.followup.send("Discord returned an error during backfill. Some messages may already have been indexed.", ephemeral=True)
        return
    await interaction.followup.send(
        f"Backfill finished for {channel.mention}: inspected {scanned} messages, indexed up to {stored} non-bot messages. Existing retention and deletion rules still apply.",
        ephemeral=True,
    )


@bot.tree.command(name="setup", description="Configure the bot's live context channels")
@app_commands.describe(
    rules="Channel containing the server rules",
    logs="Channel where moderation actions are logged",
    staff="Private staff channel for optional context",
)
@app_commands.checks.has_permissions(manage_guild=True)
async def setup_command(
    interaction: discord.Interaction,
    rules: discord.TextChannel | None = None,
    logs: discord.TextChannel | None = None,
    staff: discord.TextChannel | None = None,
) -> None:
    if not interaction.guild:
        await interaction.response.send_message("This command only works in a server.", ephemeral=True)
        return
    config = bot.config_store.get(interaction.guild.id)
    if rules is not None:
        config.rules_channel_id = rules.id
    if logs is not None:
        config.logs_channel_id = logs.id
    if staff is not None:
        config.staff_channel_id = staff.id
    bot.config_store.save()
    persisted = await bot.persist_guild_config(interaction.guild.id)
    if not persisted:
        await interaction.response.send_message(
            "The local settings were saved, but PostgreSQL synchronization failed. Check the bot logs.",
            ephemeral=True,
        )
        return
    await bot.refresh_rules_for_guild(interaction.guild)
    configured = [
        f"rules={rules.mention}" if rules else "rules unchanged",
        f"logs={logs.mention}" if logs else "logs unchanged",
        f"staff={staff.mention}" if staff else "staff unchanged",
    ]
    await interaction.response.send_message(
        "Saved live context channels: " + ", ".join(configured),
        ephemeral=True,
    )


@bot.tree.command(name="setup_status", description="Show the configured context channels")
@app_commands.checks.has_permissions(manage_guild=True)
async def setup_status_command(interaction: discord.Interaction) -> None:
    if not interaction.guild:
        await interaction.response.send_message("This command only works in a server.", ephemeral=True)
        return
    config = bot.config_store.get(interaction.guild.id)
    def channel_name(channel_id: int | None) -> str:
        channel = interaction.guild.get_channel(channel_id) if channel_id else None
        return channel.mention if channel else "not configured"
    await interaction.response.send_message(
        f"Rules: {channel_name(config.rules_channel_id)}\n"
        f"Logs: {channel_name(config.logs_channel_id)}\n"
        f"Staff context: {channel_name(config.staff_channel_id)}",
        ephemeral=True,
    )


@bot.tree.command(name="credits", description="Show TetalBot ownership and attribution")
async def credits_command(interaction: discord.Interaction) -> None:
    from .security.ownership import ATTRIBUTION, COPYRIGHT, CREATOR, OWNER, PROJECT_ID

    embed = discord.Embed(
        title="TetalBot",
        description=ATTRIBUTION,
        color=discord.Color.blurple(),
    )
    embed.add_field(name="Creator", value=CREATOR, inline=True)
    embed.add_field(name="Owner", value=OWNER, inline=True)
    embed.add_field(name="Project ID", value=PROJECT_ID, inline=False)
    embed.set_footer(text=COPYRIGHT)
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="cases", description="Show recent moderation cases for a user")
@app_commands.describe(
    user="User whose moderation history you want to review",
    limit="Number of recent cases to show (1-20)",
)
@app_commands.checks.has_permissions(manage_guild=True)
async def cases_command(
    interaction: discord.Interaction,
    user: discord.User,
    limit: app_commands.Range[int, 1, 20] = 10,
) -> None:
    if not interaction.guild:
        await interaction.response.send_message(
            "This command only works in a server.", ephemeral=True
        )
        return

    cases = bot.case_store.recent_for_target(interaction.guild.id, user.id, limit)
    if not cases:
        await interaction.response.send_message(
            f"No moderation cases found for {user.mention}.", ephemeral=True
        )
        return

    embed = discord.Embed(
        title=f"Recent moderation cases for {user}",
        description=f"Target: {user.mention} (`{user.id}`)",
        color=discord.Color.blurple(),
    )
    for case in cases:
        details = [
            f"Moderator: <@{case.moderator_id}> (`{case.moderator_id}`)",
            f"Reason: {case.reason or 'No reason provided'}",
            f"Rule: {case.rule_reference or 'Not specified'}",
            (
                "Evidence: "
                + (", ".join(str(item) for item in case.evidence_message_ids) or "None")
            ),
            f"Proposed: {case.proposed_at}",
        ]
        if case.duration_minutes is not None:
            details.append(f"Duration: {case.duration_minutes} minutes")
        if case.confirmed_at:
            details.append(f"Confirmed: {case.confirmed_at}")
        if case.closed_at:
            details.append(f"Closed: {case.closed_at}")
        if case.outcome:
            details.append(f"Outcome: {case.outcome}")
        embed.add_field(
            name=f"Case #{case.case_id} · {case.status.upper()} · {case.action}",
            value="\n".join(details)[:512],
            inline=False,
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
) -> None:
    if isinstance(error, app_commands.MissingPermissions):
        message = "You need the required staff permissions to use that command."
    else:
        LOGGER.exception("Slash command error", exc_info=error)
        message = "That command could not be completed."
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


def run() -> None:
    token = os.getenv("DISCORD_BOT_TOKEN")
    if not token:
        raise RuntimeError("DISCORD_BOT_TOKEN is not configured.")
    from .utils import configure_logging

    configure_logging()
    bot.run(token)


if __name__ == "__main__":
    run()