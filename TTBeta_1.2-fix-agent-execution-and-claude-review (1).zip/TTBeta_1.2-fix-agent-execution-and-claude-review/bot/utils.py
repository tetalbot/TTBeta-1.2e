"""Shared Discord and moderation helpers."""

from __future__ import annotations

import logging
import os
import re
from datetime import timedelta
from typing import Iterable

import discord


LOGGER = logging.getLogger("ai-moderator")
MAX_TIMEOUT_MINUTES = 28 * 24 * 60
ACTION_NAMES = {
    "warn", "mute", "unmute", "ban", "unban", "kick", "delete",
    "create_role", "delete_role", "modify_role", "assign_role", "remove_role", "list_roles",
    "create_channel", "delete_channel", "modify_channel", "lock_channel",
    "unlock_channel", "set_slowmode", "delete_by_description",
    "delete_by_similarity", "rename_server", "create_category", "delete_category",
    "set_afk", "set_verification", "create_thread", "create_forum_post",
    "archive_thread", "unarchive_thread", "lock_thread", "unlock_thread",
    "create_event", "edit_event", "delete_event",
    "create_invite", "revoke_invite", "create_webhook", "edit_webhook", "delete_webhook",
    "create_automod_rule", "edit_automod_rule", "delete_automod_rule",
    "create_emoji", "delete_emoji", "create_sticker", "delete_sticker",
    "remove_automation", "send_message", "discord_api",
}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}


def configure_logging() -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


def strip_bot_mention(content: str, bot_user_id: int) -> str:
    patterns = (rf"<@!?{bot_user_id}>",)
    result = content
    for pattern in patterns:
        result = re.sub(pattern, "", result)
    return result.strip()


def is_image_attachment(attachment: discord.Attachment) -> bool:
    content_type = (attachment.content_type or "").lower()
    if content_type.startswith("image/"):
        return True
    return any(attachment.filename.lower().endswith(ext) for ext in IMAGE_EXTENSIONS)


def format_duration(minutes: int | None) -> str:
    if minutes is None:
        return "until manually removed"
    if minutes < 60:
        return f"{minutes} minute{'s' if minutes != 1 else ''}"
    hours, remainder = divmod(minutes, 60)
    if remainder == 0:
        return f"{hours} hour{'s' if hours != 1 else ''}"
    return f"{hours}h {remainder}m"


def safe_reason(reason: str | None) -> str | None:
    if reason is None:
        return None
    cleaned = " ".join(reason.split()).strip()
    return cleaned[:480] or None


def moderation_reason(reason: str | None) -> str:
    return safe_reason(reason) or "No reason provided"


def can_moderate(actor: discord.Member, target: discord.Member) -> tuple[bool, str]:
    if actor.id == target.id:
        return False, "You cannot moderate yourself."
    if target.id == actor.guild.owner_id:
        return False, "The server owner cannot be moderated."
    if actor.id != actor.guild.owner_id and target.top_role >= actor.top_role:
        return False, "Your highest role must be above the target's highest role."
    me = actor.guild.me
    if me is None or target.top_role >= me.top_role:
        return False, "My highest role must be above the target's highest role."
    return True, ""


def clamp_timeout(minutes: int | None) -> int:
    if minutes is None:
        return MAX_TIMEOUT_MINUTES
    return max(1, min(minutes, MAX_TIMEOUT_MINUTES))


def mention_members(members: Iterable[discord.Member]) -> str:
    return ", ".join(f"{member.display_name} ({member.id})" for member in members)


def action_label(action: str) -> str:
    return action.capitalize()


async def send_dm(member: discord.Member, message: str) -> None:
    try:
        await member.send(message)
    except (discord.Forbidden, discord.HTTPException):
        LOGGER.info("Could not DM user %s", member.id)