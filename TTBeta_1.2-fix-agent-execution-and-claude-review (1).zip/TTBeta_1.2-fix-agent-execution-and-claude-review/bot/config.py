"""Persistent per-server configuration for the moderation bot."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock


DATA_DIR = Path(__file__).parent / "data"
CONFIG_PATH = DATA_DIR / "guild_config.json"
CASE_HISTORY_PATH = DATA_DIR / "moderation_cases.json"
_lock = Lock()


@dataclass
class GuildConfig:
    rules_channel_id: int | None = None
    logs_channel_id: int | None = None
    staff_channel_id: int | None = None
    context_message_limit: int = 10
    rules_message_limit: int = 0
    staff_message_limit: int = 0
    auto_execute_low_risk_actions: list[str] = field(default_factory=list)
    retention_days: int = 90
    excluded_channel_ids: list[int] = field(default_factory=list)



@dataclass
class ConfigStore:
    guilds: dict[str, GuildConfig] = field(default_factory=dict)

    def get(self, guild_id: int) -> GuildConfig:
        key = str(guild_id)
        if key not in self.guilds:
            self.guilds[key] = GuildConfig()
        return self.guilds[key]

    def save(self) -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        payload = {guild_id: asdict(config) for guild_id, config in self.guilds.items()}
        with _lock:
            CONFIG_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_store() -> ConfigStore:
    if not CONFIG_PATH.exists():
        return ConfigStore()

    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return ConfigStore()

    guilds: dict[str, GuildConfig] = {}
    for guild_id, values in raw.items():
        if isinstance(values, dict):
            allowed = {
                key: value
                for key, value in values.items()
                if key in GuildConfig.__dataclass_fields__
            }
            guilds[str(guild_id)] = GuildConfig(**allowed)
    return ConfigStore(guilds=guilds)


@dataclass
class ModerationCase:
    """A durable record for one proposed moderation action."""

    case_id: int
    guild_id: int
    moderator_id: int
    target_id: int
    action: str
    reason: str | None
    rule_reference: str | None
    evidence_message_ids: list[int]
    proposed_at: str
    status: str = "proposed"
    confirmed_at: str | None = None
    closed_at: str | None = None
    outcome: str | None = None
    duration_minutes: int | None = None


@dataclass
class CaseStore:
    cases: list[ModerationCase] = field(default_factory=list)

    def record_proposal(
        self,
        *,
        guild_id: int,
        moderator_id: int,
        target_id: int,
        action: str,
        reason: str | None,
        rule_reference: str | None,
        evidence_message_ids: list[int],
        duration_minutes: int | None = None,
    ) -> ModerationCase:
        case = ModerationCase(
            case_id=self._next_case_id(),
            guild_id=guild_id,
            moderator_id=moderator_id,
            target_id=target_id,
            action=action,
            reason=reason,
            rule_reference=rule_reference,
            evidence_message_ids=list(evidence_message_ids),
            proposed_at=_utc_now(),
            duration_minutes=duration_minutes,
        )
        self.cases.append(case)
        self.save()
        return case

    def mark_confirmed(
        self,
        case_id: int,
        outcome: str,
        *,
        status: str = "completed",
    ) -> None:
        if status not in {"confirmed", "completed", "partially_completed"}:
            raise ValueError(f"Unsupported completed case status: {status}")
        case = self._get(case_id)
        case.status = status
        case.confirmed_at = _utc_now()
        case.outcome = outcome
        self.save()

    def mark_closed(self, case_id: int, status: str, outcome: str | None = None) -> None:
        if status not in {"failed", "cancelled", "expired"}:
            raise ValueError(f"Unsupported case status: {status}")
        case = self._get(case_id)
        case.status = status
        case.closed_at = _utc_now()
        case.outcome = outcome
        self.save()

    def recent_for_target(
        self, guild_id: int, target_id: int, limit: int = 10
    ) -> list[ModerationCase]:
        matching = [
            case
            for case in reversed(self.cases)
            if case.guild_id == guild_id and case.target_id == target_id
        ]
        return matching[: max(1, limit)]

    def save(self) -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        payload = [asdict(case) for case in self.cases]
        temporary_path = CASE_HISTORY_PATH.with_suffix(".json.tmp")
        with _lock:
            temporary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            os.replace(temporary_path, CASE_HISTORY_PATH)

    def _next_case_id(self) -> int:
        return max((case.case_id for case in self.cases), default=0) + 1

    def _get(self, case_id: int) -> ModerationCase:
        for case in self.cases:
            if case.case_id == case_id:
                return case
        raise ValueError(f"Moderation case {case_id} was not found.")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_case_store() -> CaseStore:
    if not CASE_HISTORY_PATH.exists():
        return CaseStore()

    try:
        raw = json.loads(CASE_HISTORY_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return CaseStore()
    if not isinstance(raw, list):
        return CaseStore()

    cases: list[ModerationCase] = []
    for values in raw:
        if not isinstance(values, dict):
            continue
        try:
            cases.append(
                ModerationCase(
                    case_id=int(values["case_id"]),
                    guild_id=int(values["guild_id"]),
                    moderator_id=int(values["moderator_id"]),
                    target_id=int(values["target_id"]),
                    action=str(values["action"]),
                    reason=values.get("reason"),
                    rule_reference=values.get("rule_reference"),
                    evidence_message_ids=[
                        int(message_id)
                        for message_id in values.get("evidence_message_ids", [])
                    ],
                    proposed_at=str(values["proposed_at"]),
                    status=str(values.get("status", "proposed")),
                    confirmed_at=(
                        str(values["confirmed_at"])
                        if values.get("confirmed_at")
                        else None
                    ),
                    closed_at=(
                        str(values["closed_at"])
                        if values.get("closed_at")
                        else None
                    ),
                    outcome=(
                        str(values["outcome"]) if values.get("outcome") else None
                    ),
                    duration_minutes=(
                        int(values["duration_minutes"])
                        if values.get("duration_minutes") is not None
                        else None
                    ),
                )
            )
        except (KeyError, TypeError, ValueError):
            continue
    return CaseStore(cases=cases)