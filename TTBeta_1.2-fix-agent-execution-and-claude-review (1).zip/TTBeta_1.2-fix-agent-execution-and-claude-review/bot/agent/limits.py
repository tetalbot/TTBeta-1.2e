"""Configurable request and concurrency limits for agent work."""

from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncIterator


class AgentLimitExceeded(RuntimeError):
    """Raised when an agent request exceeds its configured execution budget."""


@dataclass(frozen=True)
class AgentLimits:
    max_tool_calls: int = 15
    max_reasoning_iterations: int = 10
    task_timeout_seconds: int = 120
    max_concurrent_tasks: int = 8
    max_concurrent_per_guild: int = 3
    max_concurrent_per_user: int = 1
    max_context_chars: int = 30_000
    max_investigation_result_chars: int = 20_000
    max_context_image_bytes: int = 8_000_000
    max_message_backfill_days: int = 7

    @classmethod
    def from_environment(cls) -> "AgentLimits":
        defaults = cls()
        values: dict[str, int] = {}
        for field_name, default_value in defaults.__dict__.items():
            env_name = f"AGENT_{field_name.upper()}"
            raw_value = os.getenv(env_name)
            if raw_value is None:
                values[field_name] = default_value
                continue
            try:
                parsed = int(raw_value)
            except ValueError as exc:
                raise RuntimeError(f"{env_name} must be a positive integer.") from exc
            if parsed < 1:
                raise RuntimeError(f"{env_name} must be a positive integer.")
            values[field_name] = parsed
        return cls(**values)


class AgentTaskLimiter:
    """Limits global, per-guild, and per-user concurrent agent work."""

    def __init__(self, limits: AgentLimits) -> None:
        self.limits = limits
        self._global = asyncio.Semaphore(limits.max_concurrent_tasks)
        self._guilds: dict[int, asyncio.Semaphore] = {}
        self._users: dict[tuple[int, int], asyncio.Semaphore] = {}

    def _guild_semaphore(self, guild_id: int) -> asyncio.Semaphore:
        if guild_id not in self._guilds:
            self._guilds[guild_id] = asyncio.Semaphore(
                self.limits.max_concurrent_per_guild
            )
        return self._guilds[guild_id]

    def _user_semaphore(self, guild_id: int, user_id: int) -> asyncio.Semaphore:
        key = (guild_id, user_id)
        if key not in self._users:
            self._users[key] = asyncio.Semaphore(
                self.limits.max_concurrent_per_user
            )
        return self._users[key]

    @asynccontextmanager
    async def slot(self, guild_id: int, user_id: int) -> AsyncIterator[None]:
        try:
            async with asyncio.timeout(self.limits.task_timeout_seconds):
                async with self._global:
                    async with self._guild_semaphore(guild_id):
                        async with self._user_semaphore(guild_id, user_id):
                            yield
        except TimeoutError as exc:
            raise AgentLimitExceeded(
                "This request exceeded its time limit. Please narrow the request and try again."
            ) from exc
