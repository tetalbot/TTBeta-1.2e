"""Reflective, policy-bound Discord API operations for the agent.

This is deliberately a single generic execution surface. New discord.py coroutine
methods become discoverable from the installed library; authorization, argument
binding, risk and confirmation stay enforced in Python.
"""
from __future__ import annotations

import inspect
import logging
import re
from typing import Any

import discord

LOGGER = logging.getLogger("ai-moderator.discord-api")

RESOURCE_CLASSES: dict[str, tuple[type, ...]] = {
    "guild": (discord.Guild,),
    "channel": (discord.TextChannel, discord.VoiceChannel, discord.ForumChannel, discord.StageChannel),
    "category": (discord.CategoryChannel,),
    "role": (discord.Role,),
    "member": (discord.Member,),
    "thread": (discord.Thread,),
    "message": (discord.Message,),
}

# discord.py exposes edit(**options), so its accepted fields must be bounded
# independently of Python's permissive **kwargs signature.
EDIT_FIELDS: dict[str, set[str]] = {
    "guild": {
        "name", "description", "verification_level", "default_notifications",
        "explicit_content_filter", "afk_timeout", "afk_channel", "system_channel",
        "rules_channel", "public_updates_channel", "preferred_locale",
        "premium_progress_bar_enabled",
    },
    "channel": {
        "name", "topic", "position", "category", "nsfw", "slowmode_delay",
        "bitrate", "user_limit", "rtc_region", "video_quality_mode",
        "default_auto_archive_duration", "archived", "locked", "invitable",
        "sync_permissions",
    },
    "category": {"name", "position", "nsfw"},
    "role": {"name", "permissions", "colour", "color", "hoist", "mentionable", "position"},
    "member": {"nick", "roles"},
    "thread": {"name", "archived", "locked", "auto_archive_duration", "invitable"},
    "message": {"content"},
}

READ_PREFIXES = ("fetch_",)
READ_METHODS = {"fetch", "fetch_message", "fetch_member", "fetch_role", "fetch_channel"}
BLOCKED_METHODS = {
    # These can remove the bot from a server, close its gateway, or perform
    # unpreviewed bulk destructive actions. They are not staff resource actions.
    "leave", "close", "logout", "connect", "disconnect",
    "prune_members", "purge", "delete_messages",
    # These require binary upload payloads, not JSON arguments. TetalBot has
    # dedicated attachment-backed workflows for emoji/sticker creation.
    "create_custom_emoji", "create_sticker",
}

PERMISSION_BY_OPERATION = {
    ("guild", "ban"): "ban_members",
    ("guild", "fetch_bans"): "ban_members",
    ("guild", "fetch_invites"): "manage_guild",
    ("guild", "fetch_integrations"): "manage_guild",
    ("guild", "fetch_automod_rules"): "manage_guild",
    ("guild", "unban"): "ban_members",
    ("guild", "kick"): "kick_members",
    ("guild", "edit"): "manage_guild",
    ("guild", "create_role"): "manage_roles",
    ("guild", "create_category"): "manage_channels",
    ("guild", "create_text_channel"): "manage_channels",
    ("guild", "create_voice_channel"): "manage_channels",
    ("guild", "create_forum"): "manage_channels",
    ("guild", "create_stage_channel"): "manage_channels",
    ("channel", "edit"): "manage_channels",
    ("channel", "delete"): "manage_channels",
    ("channel", "clone"): "manage_channels",
    ("channel", "set_permissions"): "manage_roles",
    ("category", "edit"): "manage_channels",
    ("category", "delete"): "manage_channels",
    ("category", "clone"): "manage_channels",
    ("category", "set_permissions"): "manage_roles",
    ("channel", "create_invite"): "create_instant_invite",
    ("channel", "create_webhook"): "manage_webhooks",
    ("channel", "send"): "send_messages",
    ("channel", "purge"): "manage_messages",
    ("channel", "delete_messages"): "manage_messages",
    ("channel", "create_thread"): "create_public_threads",
    ("thread", "edit"): "manage_threads",
    ("thread", "delete"): "manage_threads",
    ("thread", "send"): "send_messages_in_threads",
    ("message", "delete"): "manage_messages",
    ("message", "edit"): "manage_messages",
    ("message", "pin"): "manage_messages",
    ("message", "unpin"): "manage_messages",
    ("message", "clear_reactions"): "manage_messages",
    ("message", "remove_reaction"): "manage_messages",
    ("message", "add_reaction"): "add_reactions",
    ("message", "reply"): "send_messages",
    ("role", "edit"): "manage_roles",
    ("role", "delete"): "manage_roles",
    ("member", "edit"): "manage_nicknames",
    ("member", "ban"): "ban_members",
    ("member", "kick"): "kick_members",
    ("member", "timeout"): "moderate_members",
    ("member", "add_roles"): "manage_roles",
    ("member", "remove_roles"): "manage_roles",
}

# Methods with **kwargs are useful, but only these method families may receive
# extra fields and each has a resource-specific field allowlist.
KWARG_METHODS = {
    "edit", "set_permissions", "create_text_channel", "create_voice_channel",
    "create_category", "create_role", "create_forum", "create_stage_channel",
    "create_thread",
}
CREATE_FIELDS = {
    "create_text_channel": {"name", "topic", "category", "position", "nsfw", "slowmode_delay"},
    "create_voice_channel": {"name", "category", "position", "bitrate", "user_limit", "rtc_region"},
    "create_category": {"name", "position"},
    "create_role": {"name", "permissions", "colour", "color", "hoist", "mentionable"},
    "create_forum": {"name", "topic", "category", "position", "nsfw", "slowmode_delay"},
    "create_stage_channel": {"name", "category", "position", "bitrate", "user_limit", "rtc_region"},
    "create_thread": {"name", "auto_archive_duration", "type", "invitable", "slowmode_delay"},
    "set_permissions": {"overwrite", "reason"},
}

def _classes_for(resource_type: str) -> tuple[type, ...]:
    if resource_type not in RESOURCE_CLASSES:
        raise ValueError(f"Unsupported Discord resource type: {resource_type}")
    return RESOURCE_CLASSES[resource_type]


def _signature_is_exposed(method_name: str, signature: inspect.Signature) -> bool:
    if any(parameter.kind is inspect.Parameter.VAR_POSITIONAL for parameter in signature.parameters.values()):
        return method_name in {"add_roles", "remove_roles"}
    if any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in signature.parameters.values()):
        return method_name in KWARG_METHODS
    return True


def _method_signature(
    resource_type: str,
    method_name: str,
    *,
    resource: Any | None = None,
):
    if resource is not None:
        if not isinstance(resource, _classes_for(resource_type)):
            raise ValueError(f"The selected object is not a {resource_type}.")
        method = getattr(type(resource), method_name, None)
        if method is None or not inspect.iscoroutinefunction(method):
            raise ValueError(f"{method_name!r} is not an available async operation for {resource_type}.")
        try:
            return inspect.signature(method)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Could not inspect {method_name!r} for {resource_type}.") from exc
    matches = []
    for cls in _classes_for(resource_type):
        method = getattr(cls, method_name, None)
        if method is None or not inspect.iscoroutinefunction(method):
            continue
        try:
            signature = inspect.signature(method)
        except (TypeError, ValueError):
            continue
        if _signature_is_exposed(method_name, signature):
            matches.append((method, signature))
    if not matches:
        raise ValueError(f"{method_name!r} is not an available supported async operation for {resource_type}.")
    return matches[0][1]


def _supported_method(
    resource_type: str,
    method_name: str,
    *,
    resource: Any | None = None,
) -> bool:
    if not method_name or method_name.startswith("_") or method_name in BLOCKED_METHODS:
        return False
    # "discover" is a read-only meta-operation over the live discord.py catalogue.
    if method_name == "discover":
        return resource_type in RESOURCE_CLASSES
    try:
        signature = _method_signature(resource_type, method_name, resource=resource)
    except ValueError:
        return False
    return _signature_is_exposed(method_name, signature)


def discover_discord_operations() -> dict[str, list[dict[str, str]]]:
    """Discover supported coroutine methods from the installed discord.py classes."""
    result: dict[str, list[dict[str, str]]] = {}
    for resource_type, classes in RESOURCE_CLASSES.items():
        found: dict[str, dict[str, str]] = {}
        for cls in classes:
            for name, method in inspect.getmembers(cls, predicate=inspect.iscoroutinefunction):
                # Keep the first supported class variant, matching _method_signature's
                # deterministic preference instead of silently overwriting it with a
                # different subclass signature later in the class tuple.
                if name in found or not _supported_method(resource_type, name):
                    continue
                try:
                    signature = str(_method_signature(resource_type, name))
                except (TypeError, ValueError):
                    signature = "(...)"
                description = inspect.getdoc(method) or "Discord operation."
                extra_fields = (
                    EDIT_FIELDS.get(resource_type, set()) if name == "edit"
                    else CREATE_FIELDS.get(name, set()) if name.startswith("create_")
                    else set(discord.Permissions.VALID_FLAGS) | {"overwrite", "reason"} if name == "set_permissions"
                    else set()
                )
                found[name] = {
                    "method": name,
                    "signature": signature,
                    "description": " ".join(description.split())[:160],
                    "risk": "READ" if is_read_only_operation(resource_type, name) else "HIGH",
                    "permission": required_permission(resource_type, name, {}) or "none",
                    "accepted_extra_arguments": ", ".join(sorted(extra_fields)) or "none",
                }
        result[resource_type] = [found[name] for name in sorted(found)]
    return result


def operation_catalog_text() -> str:
    lines = [
        "## Generic Discord API operations",
        "",
        "Use the discord_api tool for operations on existing Discord resources and supported resource creation methods.",
        "The runtime discovers methods from the installed discord.py version. This is the current live method catalogue:",
    ]
    for resource_type, operations in discover_discord_operations().items():
        lines.append(f"### {resource_type}")
        for operation in operations[:25]:
            lines.append(
                f"- {operation['method']}{operation['signature']} "
                f"[{operation['risk']}; permission={operation['permission']}; "
                f"extra_arguments={operation['accepted_extra_arguments']}]: "
                f"{operation['description']}"
            )
    lines.extend([
        "",
        "Use resource_type plus resource_id/resource_name for an existing object. Use guild as resource_type for guild-level create/fetch operations. Pass only named JSON arguments accepted by the listed signature. For edit, fields are restricted to the resource's documented safe field set. All mutations require confirmation.",
        "If the needed method is not visible in this compact list, search the live catalogue with the read-only meta-operation: call discord_api using the relevant resource_type, method='discover', and arguments={query:'plain-language operation being sought'}. The result includes real method names, signatures, required permissions, risk, and allowed extra arguments. If has_more is true, continue with the returned next_offset. If no query matches, the result falls back to the full catalogue in pages. Never assume the first page is exhaustive.",
        "A method appearing here does not bypass runtime permissions, role hierarchy, argument checks, or confirmation.",
    ])
    return "\n".join(lines)


def is_read_only_operation(resource_type: str, method_name: str) -> bool:
    if method_name == "discover":
        return resource_type in RESOURCE_CLASSES
    if method_name.startswith(READ_PREFIXES) or method_name in READ_METHODS:
        return _supported_method(resource_type, method_name)
    return False


def required_permission(resource_type: str, method_name: str, arguments: dict[str, Any]) -> str | None:
    if method_name == "discover":
        return None
    permission = PERMISSION_BY_OPERATION.get((resource_type, method_name))
    if resource_type == "member" and method_name == "edit":
        if "roles" in arguments and "nick" in arguments:
            return "administrator"
        if "roles" in arguments:
            return "manage_roles"
        return "manage_nicknames"
    if permission:
        return permission
    if is_read_only_operation(resource_type, method_name):
        if resource_type in {"channel", "category", "thread"}:
            return "view_channel"
        if method_name in {"fetch_audit_log", "fetch_audit_logs", "audit_logs"}:
            return "view_audit_log"
        if method_name in {"fetch_bans", "fetch_ban"}:
            return "ban_members"
        return None
    # Role edits and membership changes can affect access. Unknown mutations are
    # deliberately admin-only rather than silently receiving weak authorization.
    return "administrator"


def _snowflake_id(value: Any) -> int:
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    raw = str(value).strip()
    if raw.isdecimal():
        return int(raw)
    match = re.fullmatch(r"<(?:#|@!?|@&)(\d+)>", raw)
    if match:
        return int(match.group(1))
    raise ValueError("Resource IDs must be Discord snowflakes or valid Discord mentions.")


def _resolve_resource(guild: discord.Guild, resource_type: str, params: dict[str, Any]) -> Any:
    raw_id = params.get("resource_id")
    name = str(params.get("resource_name") or "").strip().casefold()
    if resource_type in {"channel", "category", "thread"}:
        name = name.lstrip("#")
    if raw_id is None and name:
        mention = re.fullmatch(r"<(?:#|@!?|@&)(\d+)>", name)
        if mention:
            raw_id = mention.group(1)
    if resource_type == "guild":
        return guild
    if resource_type == "message":
        raise ValueError("Messages must be resolved using both channel_id and resource_id.")
    if raw_id is not None:
        try:
            numeric_id = _snowflake_id(raw_id)
        except (TypeError, ValueError) as exc:
            raise ValueError("resource_id must be a Discord snowflake.") from exc
        if resource_type in {"channel", "thread", "category"}:
            obj = guild.get_channel_or_thread(numeric_id)
        elif resource_type == "role":
            obj = guild.get_role(numeric_id)
        elif resource_type == "member":
            obj = guild.get_member(numeric_id)
        else:
            obj = None
        if obj is not None:
            if not isinstance(obj, _classes_for(resource_type)):
                raise ValueError(f"The selected object is not a {resource_type}.")
            return obj
    if name:
        if resource_type in {"channel", "thread", "category"}:
            candidates = list(guild.channels) + list(guild.threads)
            if resource_type == "category":
                candidates = list(guild.categories)
            elif resource_type == "thread":
                candidates = list(guild.threads)
            matches = [item for item in candidates if item.name.casefold() == name and isinstance(item, _classes_for(resource_type))]
        elif resource_type == "role":
            matches = [item for item in guild.roles if item.name.casefold() == name]
        elif resource_type == "member":
            matches = [item for item in guild.members if item.display_name.casefold() == name or item.name.casefold() == name]
        else:
            matches = []
        if len(matches) > 1:
            raise ValueError(f"More than one {resource_type} matches that name. Use its ID.")
        if matches:
            return matches[0]
    raise ValueError(f"The requested {resource_type} was not found in this server.")


async def _resolve_resource_live(
    guild: discord.Guild,
    resource_type: str,
    params: dict[str, Any],
) -> Any:
    """Resolve from cache first, then use Discord's REST fetch methods by ID."""
    try:
        return _resolve_resource(guild, resource_type, params)
    except ValueError as cache_error:
        raw_id = params.get("resource_id")
        resource_name = str(params.get("resource_name") or "").strip()
        if raw_id is None and resource_name:
            mention = re.fullmatch(r"<(?:#|@!?|@&)(\d+)>", resource_name)
            if mention:
                raw_id = mention.group(1)
        if raw_id is not None and resource_type == "member":
            try:
                resource = await guild.fetch_member(_snowflake_id(raw_id))
            except discord.NotFound as exc:
                raise ValueError(f"Member {raw_id} was not found in this server.") from exc
            except discord.HTTPException as exc:
                raise ValueError(f"Discord could not fetch member {raw_id}: {exc}") from exc
            return resource
        if raw_id is not None and resource_type in {"channel", "category", "thread"}:
            try:
                resource = await guild.fetch_channel(_snowflake_id(raw_id))
            except discord.NotFound as exc:
                raise ValueError(f"Channel or thread {raw_id} was not found in this server.") from exc
            except discord.HTTPException as exc:
                raise ValueError(f"Discord could not fetch channel {raw_id}: {exc}") from exc
            if not isinstance(resource, _classes_for(resource_type)):
                raise ValueError(f"The selected object is not a {resource_type}.")
            return resource
        if resource_type == "role":
            try:
                fetched_roles = await guild.fetch_roles()
            except discord.HTTPException as exc:
                raise ValueError(f"Discord could not fetch server roles: {exc}") from exc
            if raw_id is not None:
                match = next((role for role in fetched_roles if role.id == _snowflake_id(raw_id)), None)
            else:
                name = str(params.get("resource_name") or "").strip().casefold()
                matches = [role for role in fetched_roles if role.name.casefold() == name]
                if len(matches) > 1:
                    raise ValueError("More than one role matches that name. Use its ID.")
                match = matches[0] if matches else None
            if match is not None:
                return match
        if resource_type in {"channel", "category", "thread"} and params.get("resource_name"):
            fetch_channels = getattr(guild, "fetch_channels", None)
            if fetch_channels is not None:
                try:
                    fetched_channels = await fetch_channels()
                except discord.HTTPException as exc:
                    raise ValueError(f"Discord could not fetch server channels: {exc}") from exc
                name = str(params["resource_name"]).strip().casefold().lstrip("#")
                candidates = [
                    channel for channel in fetched_channels
                    if isinstance(channel, _classes_for(resource_type))
                    and channel.name.casefold() == name
                ]
                if len(candidates) > 1:
                    raise ValueError(f"More than one {resource_type} matches that name. Use its ID.")
                if candidates:
                    return candidates[0]
        raise cache_error


def _resolve_argument(guild: discord.Guild, name: str, value: Any, args: dict[str, Any]) -> Any:
    if name == "roles" and isinstance(value, list):
        resolved_roles = []
        for role_id in value:
            if isinstance(role_id, discord.Role):
                resolved_roles.append(role_id)
                continue
            role = guild.get_role(_snowflake_id(role_id))
            if role is None:
                raise ValueError(f"Role {role_id} was not found in this server.")
            resolved_roles.append(role)
        return resolved_roles
    if name in {"user", "member", "target"}:
        raw = args.get("member_id", args.get("user_id", args.get("target_id")))
        if raw is not None:
            obj = guild.get_member(_snowflake_id(raw))
            if obj is None:
                raise ValueError(f"Member {raw} was not found in this server.")
            return obj
    if name == "role":
        raw = args.get("role_id")
        if raw is not None:
            obj = guild.get_role(_snowflake_id(raw))
            if obj is None:
                raise ValueError(f"Role {raw} was not found in this server.")
            return obj
    if name in {"channel", "category"}:
        raw = args.get("channel_id", args.get("category_id"))
        if raw is not None:
            obj = guild.get_channel(_snowflake_id(raw))
            if obj is None:
                raise ValueError(f"Channel {raw} was not found in this server.")
            if name == "category" and not isinstance(obj, discord.CategoryChannel):
                raise ValueError("The selected channel is not a category.")
            return obj
    return value


ENUM_ARGUMENT_TYPES = {
    "verification_level": discord.VerificationLevel,
    "default_notifications": discord.NotificationLevel,
    "explicit_content_filter": discord.ContentFilter,
    "video_quality_mode": discord.VideoQualityMode,
    "preferred_locale": discord.Locale,
}


def _normalise_enum(value: Any, enum_type: type, argument_name: str) -> Any:
    if value is None or isinstance(value, enum_type):
        return value
    if isinstance(value, str):
        candidate = value.strip().casefold().replace("-", "_").replace(" ", "_")
        for member in enum_type:
            if member.name.casefold() == candidate or str(member.value).casefold() == candidate:
                return member
    elif isinstance(value, int) and not isinstance(value, bool):
        try:
            return enum_type(value)
        except ValueError:
            pass
    allowed = ", ".join(member.name for member in enum_type)
    raise ValueError(f"Invalid {argument_name}: {value!r}. Allowed values: {allowed}.")


def _normalise_colour(value: Any) -> discord.Colour:
    if isinstance(value, discord.Colour):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        try:
            return discord.Colour(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("Colour must be a valid RGB integer or six-digit hexadecimal value.") from exc
    text = str(value).strip().casefold()
    named = {
        "red": discord.Colour.red,
        "orange": discord.Colour.orange,
        "yellow": discord.Colour.gold,
        "gold": discord.Colour.gold,
        "green": discord.Colour.green,
        "blue": discord.Colour.blue,
        "purple": discord.Colour.purple,
        "pink": discord.Colour.magenta,
        "white": lambda: discord.Colour.from_rgb(255, 255, 255),
        "black": lambda: discord.Colour.from_rgb(0, 0, 0),
        "default": discord.Colour.default,
    }
    if text in named:
        return named[text]()
    if text.startswith("#"):
        text = text[1:]
    if re.fullmatch(r"[0-9a-f]{6}", text):
        return discord.Colour(int(text, 16))
    raise ValueError("Colour must be a supported colour name or six-digit hexadecimal value.")


def _normalise_permission_flags(
    value: Any,
    *,
    base: discord.Permissions | None = None,
) -> discord.Permissions:
    """Apply explicit JSON flags, preserving unspecified bits when editing a role."""
    if isinstance(value, discord.Permissions):
        return value
    if not isinstance(value, dict):
        raise ValueError("permissions must be an object containing boolean permission flags.")
    valid_flags = set(discord.Permissions.VALID_FLAGS)
    unknown = set(value) - valid_flags
    if unknown:
        raise ValueError("Unknown Discord permission flags: " + ", ".join(sorted(map(str, unknown))))
    permissions = discord.Permissions(base.value if base is not None else 0)
    for name, enabled in value.items():
        if type(enabled) is not bool:
            raise ValueError(f"Permission {name} must be true or false.")
        setattr(permissions, name, enabled)
    return permissions


def _ensure_admin_grant_owner(
    guild: discord.Guild,
    requester: discord.Member,
    permissions: Any,
) -> None:
    """Keep generic role operations under the specialised role workflow's owner-only rule."""
    explicitly_grants_admin = (
        permissions.get("administrator") is True
        if isinstance(permissions, dict)
        else getattr(permissions, "administrator", False) is True
    )
    if explicitly_grants_admin and requester.id != guild.owner_id:
        raise ValueError("Only the server owner can grant the Administrator permission.")


def _ensure_admin_role_assignment_owner(
    guild: discord.Guild,
    requester: discord.Member,
    roles: list[Any],
) -> None:
    for role in roles:
        _ensure_admin_grant_owner(guild, requester, getattr(role, "permissions", None))


def _normalise_arguments(
    guild: discord.Guild,
    resource_type: str,
    method_name: str,
    raw_arguments: dict[str, Any],
    *,
    resource: Any | None = None,
) -> dict[str, Any]:
    if not isinstance(raw_arguments, dict):
        raise ValueError("arguments must be a JSON object.")
    signature = _method_signature(resource_type, method_name, resource=resource)
    params = {
        name: param for name, param in signature.parameters.items()
        if name not in {"self", "cls"}
    }
    has_kwargs = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
    allowed_extra = (
        EDIT_FIELDS.get(resource_type, set()) if method_name == "edit"
        else CREATE_FIELDS.get(method_name, set()) if method_name.startswith("create_")
        else set(discord.Permissions.VALID_FLAGS) | {"overwrite", "reason"} if method_name == "set_permissions"
        else set()
    )
    raw_arguments = dict(raw_arguments)
    for parameter_name, aliases in {
        "user": ("user_id", "member_id"),
        "member": ("member_id", "user_id"),
        "role": ("role_id",),
        "channel": ("channel_id",),
        "category": ("category_id", "channel_id"),
    }.items():
        if parameter_name in params and parameter_name not in raw_arguments:
            alias = next((key for key in aliases if key in raw_arguments), None)
            if alias:
                raw = raw_arguments.pop(alias)
                if parameter_name == "user" and method_name == "unban":
                    resolved = discord.Object(id=_snowflake_id(raw))
                elif parameter_name in {"user", "member"}:
                    resolved = guild.get_member(_snowflake_id(raw))
                elif parameter_name == "role":
                    resolved = guild.get_role(_snowflake_id(raw))
                else:
                    resolved = guild.get_channel(_snowflake_id(raw))
                if resolved is None:
                    raise ValueError(f"The requested {parameter_name} was not found in this server.")
                raw_arguments[parameter_name] = resolved
    if "target" in params and "target" not in raw_arguments:
        target_id = raw_arguments.get("target_id")
        target_type = str(raw_arguments.get("target_type") or "member").lower()
        if target_id is not None:
            if target_type == "role":
                raw_arguments["target"] = guild.get_role(_snowflake_id(target_id))
            else:
                raw_arguments["target"] = guild.get_member(_snowflake_id(target_id))
            if raw_arguments["target"] is None:
                raise ValueError("The permission target was not found in this server.")
            raw_arguments.pop("target_id", None)
            raw_arguments.pop("target_type", None)
    if method_name in {"add_roles", "remove_roles"} and "roles" not in raw_arguments:
        raw_arguments["roles"] = raw_arguments.pop("role_ids", [])
    unknown = set(raw_arguments) - set(params) - allowed_extra
    if unknown:
        raise ValueError("Unsupported arguments for this operation: " + ", ".join(sorted(unknown)))
    if has_kwargs and method_name not in KWARG_METHODS:
        raise ValueError("This method does not accept dynamic keyword arguments.")
    normalised: dict[str, Any] = {}
    for key, value in raw_arguments.items():
        if key in params:
            normalised[key] = _resolve_argument(guild, key, value, raw_arguments)
        else:
            normalised[key] = value
    if method_name == "set_permissions" and isinstance(normalised.get("overwrite"), dict):
        normalised["overwrite"] = discord.PermissionOverwrite(**normalised["overwrite"])
    if method_name == "set_permissions":
        permission_flags = set(discord.Permissions.VALID_FLAGS)
        direct = {key: normalised.pop(key) for key in list(normalised) if key in permission_flags}
        if direct:
            normalised.update(direct)
    if method_name.startswith("create_") and "category" in normalised and isinstance(normalised["category"], (str, int)):
        raw_category = normalised["category"]
        resolved_category = guild.get_channel(_snowflake_id(raw_category))
        if not isinstance(resolved_category, discord.CategoryChannel):
            raise ValueError(f"Category {raw_category} was not found in this server.")
        normalised["category"] = resolved_category
    if method_name == "edit":
        channel_argument_types = {
            "category": discord.CategoryChannel,
            "voice_channel": discord.VoiceChannel,
            "afk_channel": discord.VoiceChannel,
            "system_channel": discord.TextChannel,
            "rules_channel": discord.TextChannel,
            "public_updates_channel": discord.TextChannel,
        }
        for key, expected_type in channel_argument_types.items():
            if key not in normalised or normalised[key] is None:
                continue
            if isinstance(normalised[key], (str, int)):
                raw = normalised[key]
                obj = guild.get_channel(_snowflake_id(raw))
                if obj is None:
                    raise ValueError(f"Channel {raw} was not found in this server.")
                normalised[key] = obj
            if not isinstance(normalised[key], expected_type):
                raise ValueError(f"{key} must reference a {expected_type.__name__}.")
        if resource_type == "role" and "permissions" in normalised:
            current_permissions = getattr(resource, "permissions", None)
            normalised["permissions"] = _normalise_permission_flags(
                normalised["permissions"],
                base=current_permissions,
            )
        if "overwrites" in normalised and isinstance(normalised["overwrites"], dict):
            raise ValueError("Overwrites must be configured with set_permissions operations, not a raw object map.")
    if method_name == "create_role" and "permissions" in normalised:
        normalised["permissions"] = _normalise_permission_flags(normalised["permissions"])
    if (resource_type == "role" and method_name == "edit") or (
        resource_type == "guild" and method_name == "create_role"
    ):
        if "color" in normalised:
            if "colour" in normalised:
                raise ValueError("Provide either color or colour, not both.")
            normalised["colour"] = normalised.pop("color")
        if "colour" in normalised and normalised["colour"] is not None:
            normalised["colour"] = _normalise_colour(normalised["colour"])
    for key, enum_type in ENUM_ARGUMENT_TYPES.items():
        if key in normalised:
            normalised[key] = _normalise_enum(normalised[key], enum_type, key)
    return normalised


def _verification_matches(actual: Any, expected: Any) -> bool:
    if isinstance(expected, discord.Permissions):
        return isinstance(actual, discord.Permissions) and actual.value == expected.value
    if isinstance(expected, discord.Colour):
        return isinstance(actual, discord.Colour) and actual.value == expected.value
    if isinstance(expected, discord.PermissionOverwrite):
        return isinstance(actual, discord.PermissionOverwrite) and actual.pair() == expected.pair()
    if isinstance(expected, (list, tuple)) and all(hasattr(item, "id") for item in expected):
        return [getattr(item, "id", None) for item in actual] == [
            getattr(item, "id", None) for item in expected
        ] if isinstance(actual, (list, tuple)) else False
    if hasattr(expected, "id"):
        return getattr(actual, "id", None) == expected.id
    if hasattr(expected, "value") and hasattr(actual, "value"):
        return actual.value == expected.value
    return actual == expected


def _verify_edit_result(
    resource_type: str,
    verified: Any,
    arguments: dict[str, Any],
) -> None:
    for key, expected in arguments.items():
        if key == "reason":
            continue
        if key == "sync_permissions":
            if expected is True and not getattr(verified, "permissions_synced", False):
                raise RuntimeError("Discord did not confirm that channel permissions were synchronised.")
            continue
        if not hasattr(verified, key):
            raise RuntimeError(
                f"Discord returned an updated {resource_type}, but its {key} field could not be verified."
            )
        actual = getattr(verified, key)
        if not _verification_matches(actual, expected):
            raise RuntimeError(f"Discord did not confirm the requested {key} change.")


def _serialise_result(value: Any) -> dict[str, Any]:
    """Return useful, bounded JSON data from a read-only Discord result."""
    if isinstance(value, (list, tuple, set)):
        items = list(value)
        return {
            "type": "collection",
            "count": len(items),
            "truncated": len(items) > 50,
            "items": [_serialise_result(item) for item in items[:50]],
        }
    if isinstance(value, dict):
        entries = list(value.items())
        return {
            "type": "object",
            "count": len(entries),
            "truncated": len(entries) > 50,
            "items": {str(key): _serialise_result(item) for key, item in entries[:50]},
        }
    if isinstance(value, discord.Message):
        return {
            "type": "message",
            "id": str(value.id),
            "content": value.content[:4000],
            "author": {
                "id": str(value.author.id),
                "name": getattr(value.author, "display_name", value.author.name),
            },
            "channel_id": str(value.channel.id),
            "channel_name": getattr(value.channel, "name", "unknown"),
            "created_at": value.created_at.isoformat(),
            "jump_url": value.jump_url,
            "attachments": [
                {"id": str(item.id), "filename": item.filename, "url": item.url}
                for item in value.attachments[:10]
            ],
        }
    if isinstance(value, discord.Member):
        return {
            "type": "member",
            "id": str(value.id),
            "name": value.display_name,
            "username": value.name,
            "bot": value.bot,
            "roles": [{"id": str(role.id), "name": role.name} for role in value.roles],
            "joined_at": value.joined_at.isoformat() if value.joined_at else None,
        }
    if isinstance(value, discord.Role):
        return {
            "type": "role",
            "id": str(value.id),
            "name": value.name,
            "position": value.position,
            "managed": value.managed,
            "permissions": value.permissions.value,
        }
    if isinstance(value, discord.abc.GuildChannel):
        return {
            "type": "channel",
            "id": str(value.id),
            "name": value.name,
            "channel_type": str(value.type),
            "category": value.category.name if getattr(value, "category", None) else None,
            "topic": getattr(value, "topic", None),
        }
    if isinstance(value, discord.Thread):
        return {
            "type": "thread",
            "id": str(value.id),
            "name": value.name,
            "archived": value.archived,
            "locked": value.locked,
            "parent_id": str(value.parent_id) if value.parent_id else None,
        }
    if hasattr(value, "id"):
        return {
            "type": type(value).__name__,
            "id": str(value.id),
            "name": getattr(value, "name", None),
        }
    return {"type": type(value).__name__, "value": str(value)[:2000]}


async def execute_discord_api_operation(
    interaction: discord.Interaction,
    proposal: Any,
) -> str | dict[str, Any]:
    guild = interaction.guild
    if guild is None:
        raise ValueError("This operation requires a server.")
    params = proposal.parameters
    resource_type = str(params.get("resource_type") or "").strip().lower()
    method_name = str(params.get("method") or "").strip()
    if not _supported_method(resource_type, method_name):
        raise ValueError(f"{method_name!r} is not an exposed Discord operation for {resource_type!r}.")
    if method_name == "discover":
        raw_arguments = params.get("arguments", {})
        if not isinstance(raw_arguments, dict):
            raise ValueError("arguments must be a JSON object.")
        query = str(raw_arguments.get("query") or "").strip().casefold()
        raw_offset = raw_arguments.get("offset", 0)
        raw_limit = raw_arguments.get("limit", 50)
        if type(raw_offset) is not int or raw_offset < 0:
            raise ValueError("Discovery offset must be a non-negative integer.")
        if type(raw_limit) is not int or not 1 <= raw_limit <= 50:
            raise ValueError("Discovery limit must be an integer between 1 and 50.")
        operations = discover_discord_operations().get(resource_type, [])
        candidates = operations
        matched_count = 0
        if query:
            terms = [part for part in re.findall(r"[a-z0-9_]+", query) if len(part) > 1]
            ranked = []
            for operation in operations:
                haystack = " ".join((
                    operation["method"],
                    operation["signature"],
                    operation["description"],
                    operation.get("accepted_extra_arguments", ""),
                )).casefold()
                score = sum(1 for term in terms if term in haystack)
                if score:
                    ranked.append((score, operation))
            ranked.sort(key=lambda item: (item[0], item[1]["method"]), reverse=True)
            if ranked:
                candidates = [item for _, item in ranked]
                matched_count = len(candidates)
        selected = candidates[raw_offset:raw_offset + raw_limit]
        next_offset = raw_offset + len(selected)
        return {
            "type": "discord_operation_catalog",
            "resource_type": resource_type,
            "query": query,
            "total_available": len(operations),
            "total_matches": matched_count,
            "offset": raw_offset,
            "returned": len(selected),
            "has_more": next_offset < len(candidates),
            "next_offset": next_offset if next_offset < len(candidates) else None,
            "operations": selected,
        }
    if resource_type == "message":
        raw_channel_id = params.get("channel_id")
        if raw_channel_id is None or params.get("resource_id") is None:
            raise ValueError("Message operations require both channel_id and resource_id.")
        channel = guild.get_channel_or_thread(_snowflake_id(raw_channel_id))
        if channel is None or not hasattr(channel, "fetch_message") or not hasattr(channel, "permissions_for"):
            raise ValueError("The message's channel was not found or cannot fetch messages.")
        for member, label in ((interaction.user, "You"), (guild.me, "The bot")):
            if member is None:
                raise ValueError(f"{label} server-member context is unavailable.")
            channel_permissions = channel.permissions_for(member)
            for required in ("view_channel", "read_message_history"):
                if not getattr(channel_permissions, required, False):
                    raise ValueError(f"{label} need {required.replace('_', ' ')} permission to access that message.")
        try:
            resource = await channel.fetch_message(_snowflake_id(params["resource_id"]))
        except discord.NotFound as exc:
            raise ValueError("The requested message no longer exists.") from exc
    else:
        resource = await _resolve_resource_live(guild, resource_type, params)
    if not _supported_method(resource_type, method_name, resource=resource):
        raise ValueError(f"{method_name!r} is not a supported operation for this specific {resource_type} type.")
    method = getattr(resource, method_name, None)
    if method is None or not callable(method) or not inspect.iscoroutinefunction(method):
        raise ValueError("The selected Discord operation is unavailable on that resource.")
    arguments = _normalise_arguments(
        guild,
        resource_type,
        method_name,
        params.get("arguments", {}),
        resource=resource,
    )
    if (
        (resource_type == "guild" and method_name == "create_role")
        or (resource_type == "role" and method_name == "edit")
    ):
        raw_arguments = params.get("arguments") or {}
        _ensure_admin_grant_owner(
            guild,
            interaction.user,
            raw_arguments.get("permissions") if isinstance(raw_arguments, dict) else None,
        )
    if method_name == "send":
        if "allowed_mentions" in arguments:
            raise ValueError("Custom allowed_mentions are not exposed. Mentions are disabled for safety.")
        arguments["allowed_mentions"] = discord.AllowedMentions.none()
    signature = inspect.signature(method)
    role_args = arguments.pop("roles", None) if method_name in {"add_roles", "remove_roles"} else None
    try:
        if role_args is not None:
            signature.bind(*role_args, **arguments)
        else:
            signature.bind(**arguments)
    except TypeError as exc:
        raise ValueError(f"Invalid arguments for {method_name}: {exc}") from exc

    permission = required_permission(resource_type, method_name, arguments)
    permission_target = resource.channel if isinstance(resource, discord.Message) else resource
    for member, label in ((interaction.user, "You"), (guild.me, "The bot")):
        if member is None:
            raise ValueError(f"{label} server-member context is unavailable.")
        permissions = permission_target.permissions_for(member) if hasattr(permission_target, "permissions_for") else member.guild_permissions
        if permission and not getattr(permissions, permission, False):
            raise ValueError(f"{label} need {permission.replace('_', ' ')} permission for this operation.")
        if resource_type == "message" or (resource_type in {"channel", "thread"} and method_name == "fetch_message"):
            for extra_permission in ("view_channel", "read_message_history"):
                if not getattr(permissions, extra_permission, False):
                    raise ValueError(f"{label} need {extra_permission.replace('_', ' ')} permission for message operations.")

    if resource_type == "role" and method_name in {"edit", "delete"}:
        if resource.is_default() or (interaction.user.id != guild.owner_id and resource >= interaction.user.top_role):
            raise ValueError("Your highest role must be above the target role.")
        if guild.me is None or resource >= guild.me.top_role:
            raise ValueError("The bot's highest role must be above the target role.")
    target_member = resource if resource_type == "member" else arguments.get("user") or arguments.get("member")
    if method_name in {"ban", "kick", "timeout", "edit", "add_roles", "remove_roles"} and isinstance(target_member, discord.Member):
        from ..utils import can_moderate
        allowed, reason = can_moderate(interaction.user, target_member)
        if not allowed:
            raise ValueError(reason)
        if guild.me is None or target_member.top_role >= guild.me.top_role:
            raise ValueError("The bot's highest role must be above the target member.")
        assigned_roles = role_args or arguments.get("roles") or []
        if method_name in {"add_roles", "edit"}:
            _ensure_admin_role_assignment_owner(guild, interaction.user, assigned_roles)
        for role in assigned_roles:
            if interaction.user.id != guild.owner_id and role >= interaction.user.top_role:
                raise ValueError("You cannot assign or remove a role equal to or above your highest role.")
            if role >= guild.me.top_role:
                raise ValueError("The bot cannot assign or remove a role equal to or above its highest role.")

    if resource_type == "message" and method_name == "edit":
        bot_user = getattr(interaction.client, "user", None)
        if bot_user is None or resource.author.id != bot_user.id:
            raise ValueError("Discord only allows the bot to edit its own messages.")
    reason = proposal.reason or "TetalBot agent operation"
    if method_name == "edit" and resource_type == "channel" and arguments.get("sync_permissions") is True:
        parent = arguments.get("category") or getattr(resource, "category", None)
        if parent is None:
            raise ValueError("Permission synchronisation requires a parent category.")
    if role_args is not None:
        if "reason" in signature.parameters and "reason" not in arguments:
            result = await method(*role_args, reason=reason, **arguments)
        else:
            result = await method(*role_args, **arguments)
    else:
        result = await method(reason=reason, **arguments) if "reason" in signature.parameters and "reason" not in arguments else await method(**arguments)

    if method_name == "set_permissions":
        target = arguments.get("target")
        expected_overwrite = arguments.get("overwrite")
        actual_overwrite = resource.overwrites_for(target) if target is not None and hasattr(resource, "overwrites_for") else None
        if expected_overwrite is not None and actual_overwrite is not None:
            for flag, expected in expected_overwrite:
                if getattr(actual_overwrite, flag, None) != expected:
                    raise RuntimeError(f"Discord did not verify the {flag} permission overwrite.")
        for flag, expected in arguments.items():
            if flag in discord.Permissions.VALID_FLAGS and actual_overwrite is not None:
                if getattr(actual_overwrite, flag, None) != expected:
                    raise RuntimeError(f"Discord did not verify the {flag} permission overwrite.")
    if method_name == "delete":
        if resource_type == "message":
            try:
                await resource.channel.fetch_message(resource.id)
            except discord.NotFound:
                pass
            else:
                raise RuntimeError("Discord returned from delete but the message still exists.")
        if resource_type in {"channel", "category", "thread"} and guild.get_channel_or_thread(resource.id) is not None:
            raise RuntimeError("Discord returned from delete but the resource still exists in the guild cache.")
        if resource_type == "role" and guild.get_role(resource.id) is not None:
            raise RuntimeError("Discord returned from delete but the role still exists in the guild cache.")
    if method_name == "edit":
        verified = result if result is not None else resource
        _verify_edit_result(resource_type, verified, arguments)
    target_label = getattr(resource, "name", getattr(resource, "display_name", resource_type))
    if is_read_only_operation(resource_type, method_name):
        return _serialise_result(result)
    if method_name == "delete":
        return f"deleted {resource_type} **{target_label}**."
    if method_name == "edit":
        return f"updated {resource_type} **{target_label}** and verified the returned state."
    if result is not None and hasattr(result, "id"):
        return f"{method_name} completed for {resource_type} **{target_label}** (result ID {result.id})."
    return f"{method_name} completed for {resource_type} **{target_label}**."
