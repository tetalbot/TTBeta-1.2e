"""Central entry point for Gemini reasoning and bounded context retrieval."""

from __future__ import annotations

import asyncio
import json
import copy
from dataclasses import dataclass
from typing import Any

from ..ai import AgentStep, GeminiInterpreter, ModerationProposal
from ..entity_resolution import resolve_tool_entities
from ..config import GuildConfig
from ..context import AIContext, MessageContext, collect_context
from ..tools.dispatcher import ToolResult, dispatch_tool
from ..tools.registry import ToolRegistry
from .limits import AgentLimitExceeded, AgentLimits, AgentTaskLimiter
from ..security.authorization import authorize_operation
from ..security.risk_policy import classify_action_risk, requires_confirmation


@dataclass
class AgentTurn:
    context: AIContext
    proposal: ModerationProposal


@dataclass
class AgentTaskResult:
    context: AIContext
    proposal: ModerationProposal | None = None
    proposals: list[ModerationProposal] | None = None
    final_response: str | None = None
    tool_results: list[dict[str, Any]] | None = None


class AgentOrchestrator:
    """Coordinates context retrieval and every Gemini request made by the bot."""

    def __init__(
        self,
        interpreter: GeminiInterpreter,
        limits: AgentLimits | None = None,
        tool_registry: ToolRegistry | None = None,
    ) -> None:
        self.interpreter = interpreter
        self.limits = limits or AgentLimits.from_environment()
        self.limiter = AgentTaskLimiter(self.limits)
        self.tool_registry = tool_registry

    @staticmethod
    def _validate_search_backed_delete(
        proposal: ModerationProposal,
        tool_results: list[dict[str, Any]],
    ) -> str | None:
        """Bind a search-derived delete proposal to the exact successful search result."""
        search_result = next(
            (
                item for item in reversed(tool_results)
                if item.get("tool") == "search_recent_messages" and item.get("success") is True
            ),
            None,
        )
        if search_result is None:
            # Explicit message-ID deletions remain supported without a search.
            return None
        data = search_result.get("data")
        if not isinstance(data, dict):
            return "I could not verify the message-search result. No messages were queued."
        if data.get("scan_complete") is not True or data.get("results_complete") is not True:
            return "The message search was incomplete, so I cannot safely queue deletion. Narrow the search and try again."
        matches = data.get("matches")
        if not isinstance(matches, list):
            return "The message-search result did not contain a valid evidence list."
        try:
            expected_channels = {
                str(item["message_id"]): str(item["channel_id"])
                for item in matches
                if isinstance(item, dict) and item.get("message_id") is not None
                and item.get("channel_id") is not None
            }
            match_count = int(data.get("match_count", -1))
        except (TypeError, ValueError):
            return "The message-search result contained invalid evidence identifiers."
        if len(expected_channels) != len(matches) or match_count != len(matches):
            return "The message-search result was truncated or malformed. No deletion was queued."

        parameters = proposal.parameters
        raw_ids = parameters.get("message_ids") or proposal.evidence_message_ids
        proposed_ids = [str(value) for value in raw_ids]
        if (
            len(proposed_ids) != len(set(proposed_ids))
            or set(proposed_ids) != set(expected_channels)
        ):
            return "The deletion targets do not exactly match the messages returned by the search. No deletion was queued."
        evidence_ids = {str(value) for value in proposal.evidence_message_ids}
        if evidence_ids != set(expected_channels):
            return "The deletion evidence IDs do not match the search results. No deletion was queued."
        raw_channels = parameters.get("message_channels")
        if not isinstance(raw_channels, dict):
            return "The deletion proposal is missing the searched messages' channel mapping."
        proposed_channels = {str(key): str(value) for key, value in raw_channels.items()}
        if proposed_channels != expected_channels:
            return "The deletion channel mapping does not match the search results. No deletion was queued."
        return None

    async def run_agent_task(
        self,
        message: Any,
        request: str,
        config: GuildConfig,
        cached_rules: list[MessageContext],
        conversation: list[dict[str, str]],
        tool_context: Any,
    ) -> AgentTaskResult:
        """Run a bounded reasoning loop; only READ tools execute before confirmation."""
        guild_id = message.guild.id
        user_id = message.author.id
        async with self.limiter.slot(guild_id, user_id):
            context = await collect_context(
                message,
                request,
                config,
                cached_rules,
            )
            context = self._bound_context(context)
            bounded_history = self._bound_history(conversation)
            tool_results: list[dict[str, Any]] = []
            seen_calls: set[str] = set()
            tool_call_count = 0
            failed_tool_calls = 0
            max_recovery_attempts = min(3, self.limits.max_reasoning_iterations)

            for _ in range(self.limits.max_reasoning_iterations):
                try:
                    step: AgentStep = await asyncio.wait_for(
                        self.interpreter.generate_agent_step(
                            context,
                            bounded_history,
                            (
                                self.tool_registry.schemas()
                                if self.tool_registry is not None
                                else []
                            ),
                            tool_results,
                        ),
                        timeout=self.limits.task_timeout_seconds,
                    )
                except TimeoutError as exc:
                    raise AgentLimitExceeded(
                        "This request exceeded its time limit. Please narrow the request and try again."
                    ) from exc

                if step.decision == "final":
                    return AgentTaskResult(
                        context, final_response=step.text, tool_results=tool_results
                    )
                if step.decision == "question":
                    return AgentTaskResult(
                        context,
                        proposal=ModerationProposal(question=step.text),
                        tool_results=tool_results,
                    )
                if step.decision == "plan":
                    planned = step.actions or []
                    max_calls = min(
                        self.limits.max_tool_calls,
                        self.limits.max_reasoning_iterations,
                    )
                    if not 2 <= len(planned) <= min(10, max_calls):
                        return AgentTaskResult(
                            context,
                            proposal=ModerationProposal(
                                question=f"This action plan must contain between 2 and {min(10, max_calls)} steps."
                            ),
                            tool_results=tool_results,
                        )
                    validated: list[ModerationProposal] = []
                    seen_plan_calls: set[str] = set()
                    for item in planned:
                        tool_name = item["tool_name"]
                        arguments = item["arguments"]
                        call_key = json.dumps(
                            [tool_name, arguments],
                            sort_keys=True,
                            ensure_ascii=False,
                            default=str,
                        )
                        if call_key in seen_plan_calls:
                            return AgentTaskResult(
                                context,
                                proposal=ModerationProposal(
                                    question="The plan contains a duplicate action. Please submit a clearer request."
                                ),
                                tool_results=tool_results,
                            )
                        seen_plan_calls.add(call_key)
                        tool, proposal, authorization_error = self._authorize_registered_call(
                            tool_name,
                            arguments,
                            tool_context,
                            guild_id=guild_id,
                            user_id=user_id,
                        )
                        if authorization_error or proposal is None:
                            return AgentTaskResult(
                                context,
                                proposal=ModerationProposal(
                                    question=authorization_error or "A planned action could not be validated."
                                ),
                                tool_results=tool_results,
                            )
                        if classify_action_risk(proposal.action, proposal) == "READ":
                            return AgentTaskResult(
                                context,
                                proposal=ModerationProposal(
                                    question="Action plans may contain modifying actions only. Read-only steps must be completed separately."
                                ),
                                tool_results=tool_results,
                            )
                        validated.append(proposal)
                    return AgentTaskResult(
                        context,
                        proposals=validated,
                        tool_results=tool_results,
                    )
                if not step.tool_name or not isinstance(step.arguments, dict):
                    return AgentTaskResult(
                        context,
                        proposal=ModerationProposal(
                            question="I could not validate the requested operation. Please rephrase it."
                        ),
                        tool_results=tool_results,
                    )

                call_key = json.dumps(
                    [step.tool_name, step.arguments],
                    sort_keys=True,
                    ensure_ascii=False,
                    default=str,
                )
                if call_key in seen_calls:
                    tool_results.append(
                        ToolResult(
                            False,
                            step.tool_name,
                            error={
                                "code": "DUPLICATE_TOOL_CALL",
                                "message": "This exact tool call already ran in this task.",
                            },
                        ).to_dict()
                    )
                    return AgentTaskResult(
                        context,
                        final_response=(
                            "I already tried that exact step and it did not move the task forward, "
                            "so I stopped rather than repeat it. No duplicate action was taken."
                        ),
                        tool_results=tool_results,
                    )
                seen_calls.add(call_key)

                if tool_call_count >= self.limits.max_tool_calls:
                    return AgentTaskResult(
                        context,
                        final_response=(
                            "I reached the safe tool-call limit and stopped. "
                            "Please split the remaining work into a separate request."
                        ),
                        tool_results=tool_results,
                    )
                tool_call_count += 1

                if self.tool_registry is None:
                    tool = None
                else:
                    try:
                        tool = self.tool_registry.get(step.tool_name)
                    except KeyError:
                        tool = None

                if tool is None:
                    result = await dispatch_tool(
                        self.tool_registry or ToolRegistry(),
                        step.tool_name,
                        step.arguments,
                        tool_context,
                        guild_id=guild_id,
                    )
                    result_payload = result.to_dict()
                    tool_results.append(result_payload)
                    if not result_payload.get("success"):
                        failed_tool_calls += 1
                        if failed_tool_calls >= max_recovery_attempts:
                            return AgentTaskResult(
                                context,
                                final_response=(
                                    "I tried several safe alternatives, but the operation kept failing. "
                                    "I stopped without repeating completed actions. "
                                    "The failed attempts and their errors are available in the task results."
                                ),
                                tool_results=tool_results,
                            )
                    # The next reasoning iteration receives the failed result and may
                    # inspect state, discover another method, or choose a different route.
                    continue

                tool, proposal, authorization_error = self._authorize_registered_call(step.tool_name, step.arguments, tool_context, guild_id=guild_id, user_id=user_id)
                if authorization_error or proposal is None:
                    return AgentTaskResult(context, proposal=ModerationProposal(question=authorization_error or "The requested operation could not be authorized."), tool_results=tool_results)

                if proposal.action == "delete":
                    evidence_error = self._validate_search_backed_delete(proposal, tool_results)
                    if evidence_error:
                        return AgentTaskResult(
                            context,
                            proposal=ModerationProposal(question=evidence_error),
                            tool_results=tool_results,
                        )

                risk = classify_action_risk(proposal.action, proposal)
                if risk == "HIGH":
                    proposal.continue_after_confirmation = step.continue_after_confirmation
                    return AgentTaskResult(
                        context,
                        proposal=proposal,
                        tool_results=tool_results,
                    )
                if risk == "LOW":
                    if requires_confirmation(proposal.action, proposal, config):
                        proposal.continue_after_confirmation = step.continue_after_confirmation
                        return AgentTaskResult(
                            context,
                            proposal=proposal,
                            tool_results=tool_results,
                        )
                    auto_executor = getattr(tool_context, "auto_executor", None)
                    if not callable(auto_executor):
                        return AgentTaskResult(
                            context,
                            proposal=ModerationProposal(
                                question=(
                                    "Automatic execution is enabled, but the safe execution "
                                    "service is unavailable. No action was taken."
                                )
                            ),
                            tool_results=tool_results,
                        )
                    result = await auto_executor(step.tool_name, proposal, tool_context)
                    result_payload = self._bound_tool_result(result)
                    tool_results.append(result_payload)
                    if not result_payload.get("success", True):
                        failed_tool_calls += 1
                        if failed_tool_calls >= max_recovery_attempts:
                            return AgentTaskResult(
                                context,
                                final_response=(
                                    "I tried several safe alternatives, but the operation kept failing. "
                                    "I stopped without repeating completed actions. "
                                    "The failed attempts and their errors are available in the task results."
                                ),
                                tool_results=tool_results,
                            )
                    continue

                result = await dispatch_tool(
                    self.tool_registry,
                    step.tool_name,
                    step.arguments,
                    tool_context,
                    guild_id=guild_id,
                )
                result_payload = self._bound_tool_result(result)
                tool_results.append(result_payload)
                if not result_payload.get("success"):
                    failed_tool_calls += 1
                    if failed_tool_calls >= max_recovery_attempts:
                        return AgentTaskResult(
                            context,
                            final_response=(
                                "I tried several safe alternatives, but the operation kept failing. "
                                "I stopped without repeating completed actions. "
                                "The failed attempts and their errors are available in the task results."
                            ),
                            tool_results=tool_results,
                        )
                # Feed the actual error back into the next model turn instead of
                # asking a separate helper to write a final apology and stopping.

            completed = [
                str(item.get("data"))
                for item in tool_results
                if item.get("success") and item.get("data")
            ]
            progress = (
                " I completed: " + "; ".join(completed[-5:])
                if completed else
                " I have not completed any changes."
            )
            return AgentTaskResult(
                context,
                final_response=(
                    "I couldn't safely finish the whole request within my reasoning budget. "
                    "I stopped without repeating completed actions." + progress
                    + " Tell me which remaining part to continue with."
                ),
                tool_results=tool_results,
            )

    async def interpret_message(
        self,
        message: Any,
        request: str,
        config: GuildConfig,
        cached_rules: list[MessageContext],
        conversation: list[dict[str, str]],
    ) -> AgentTurn:
        guild_id = message.guild.id
        user_id = message.author.id

        async with self.limiter.slot(guild_id, user_id):
            context = await collect_context(
                message,
                request,
                config,
                cached_rules,
            )
            context = self._bound_context(context)
            bounded_history = self._bound_history(conversation)
            try:
                proposal = await asyncio.wait_for(
                    self.interpreter.interpret(
                        context,
                        bounded_history,
                        tool_definitions=(
                            self.tool_registry.schemas()
                            if self.tool_registry is not None
                            else None
                        ),
                    ),
                    timeout=self.limits.task_timeout_seconds,
                )
            except TimeoutError as exc:
                raise AgentLimitExceeded(
                    "This request exceeded its time limit. Please narrow the request and try again."
                ) from exc
            return AgentTurn(context=context, proposal=proposal)

    async def select_message_ids(
        self,
        *,
        guild_id: int,
        user_id: int,
        instruction: str,
        candidates: list[str],
    ) -> set[int]:
        async with self.limiter.slot(guild_id, user_id):
            try:
                return await asyncio.wait_for(
                    self.interpreter.select_message_ids(
                        instruction,
                        candidates,
                        guild_id=guild_id,
                        user_id=user_id,
                    ),
                    timeout=self.limits.task_timeout_seconds,
                )
            except TimeoutError as exc:
                raise AgentLimitExceeded(
                    "The evidence search exceeded its time limit."
                ) from exc

    def _authorize_registered_call(self, tool_name: str, arguments: Any, context: Any, *, guild_id: int, user_id: int) -> tuple[Any | None, ModerationProposal | None, str | None]:
        """Validate and authorize a registered tool at the final dispatch boundary."""
        if self.tool_registry is None:
            return None, None, "No tool registry is configured."
        try:
            tool = self.tool_registry.get(tool_name)
        except KeyError:
            return None, None, "This operation is not registered."
        if not isinstance(arguments, dict):
            return tool, None, "Tool arguments must be an object."
        # Resolve names against the live guild before schema validation. Keep the
        # resolved IDs in the original payload so every later layer sees the same
        # unambiguous target.
        entity_error = resolve_tool_entities(guild=getattr(context, "guild", None), arguments=arguments)
        if entity_error:
            return tool, None, entity_error
        error = tool.validate_arguments(arguments)
        if error:
            return tool, None, error
        proposal = ModerationProposal.from_payload(arguments)
        guild = getattr(context, "guild", None)
        requester = getattr(context, "requester", None)
        bot_member = getattr(context, "bot_member", None) or getattr(guild, "me", None)
        source_message = getattr(context, "source_message", None)
        if guild is None or getattr(guild, "id", None) != guild_id:
            return tool, proposal, "The tool context belongs to a different or missing server."
        if requester is None or getattr(requester, "id", None) != user_id:
            return tool, proposal, "The tool context does not match the requesting user."
        decision = authorize_operation(guild=guild, requester=requester, bot_member=bot_member, tool=tool, proposal=proposal, channel=getattr(source_message, "channel", None))
        if not decision.allowed:
            return tool, proposal, decision.message
        return tool, proposal, None
    async def dispatch_tool_calls(
        self,
        calls: list[dict[str, Any]],
        context: Any,
        *,
        guild_id: int,
        user_id: int,
    ) -> list[ToolResult]:
        """Dispatch a bounded sequential tool plan through the registered handlers."""
        max_calls = min(
            self.limits.max_tool_calls,
            self.limits.max_reasoning_iterations,
        )
        if len(calls) > max_calls:
            raise AgentLimitExceeded(
                f"This plan exceeds the configured limit of {max_calls} tool steps."
            )
        if self.tool_registry is None:
            raise RuntimeError("No tool registry is configured for this orchestrator.")

        results: list[ToolResult] = []
        async with self.limiter.slot(guild_id, user_id):
            for call in calls:
                if not isinstance(call, dict):
                    results.append(
                        ToolResult(
                            False,
                            "",
                            error={
                                "code": "INVALID_TOOL_CALL",
                                "message": "Each tool call must be an object.",
                            },
                        )
                    )
                    break
                tool_name = str(call.get("name") or "")
                tool, proposal, authorization_error = self._authorize_registered_call(tool_name, call.get("arguments"), context, guild_id=guild_id, user_id=user_id)
                if authorization_error:
                    results.append(ToolResult(False, tool_name, error={"code": "AUTHORIZATION_DENIED", "message": authorization_error}, metadata={"guild_id": str(guild_id)}))
                    break
                if proposal is None or classify_action_risk(proposal.action, proposal) != "READ":
                    results.append(
                        ToolResult(
                            False,
                            tool_name,
                            error={
                                "code": "CONFIRMATION_REQUIRED",
                                "message": "Modifying operations must use the persistent confirmation workflow.",
                            },
                            metadata={"guild_id": str(guild_id)},
                        )
                    )
                    break
                result = await dispatch_tool(self.tool_registry, tool_name, call.get("arguments"), context, guild_id=guild_id)
                results.append(result)
                if not result.success:
                    break
        return results

    def _bound_context(self, context: AIContext) -> AIContext:
        context = copy.deepcopy(context)
        budget = self.limits.max_context_chars
        context.current_request = context.current_request[: min(4_000, budget // 4)]
        context.member_directory = context.member_directory[: min(6_000, budget // 4)]

        for collection in (
            context.recent_messages,
            context.rules_messages,
            context.staff_messages,
        ):
            for item in collection:
                item.content = item.content[:1_000]
                item.image_urls = item.image_urls[:2]
            if len(context.as_text()) > budget:
                del collection[:-10]

        while len(context.as_text()) > budget:
            if context.recent_messages:
                context.recent_messages.pop(0)
            elif context.staff_messages:
                context.staff_messages.pop(0)
            elif context.rules_messages:
                context.rules_messages.pop(0)
            elif context.member_directory:
                context.member_directory = context.member_directory[: budget // 8]
            else:
                context.current_request = context.current_request[: budget // 4]
                break
        return context

    def _bound_history(
        self, conversation: list[dict[str, str]]
    ) -> list[dict[str, str]]:
        max_history = min(20, self.limits.max_reasoning_iterations * 2)
        per_message_chars = max(
            500,
            self.limits.max_context_chars // max(1, max_history),
        )
        return [
            {
                "role": str(message.get("role", "user")),
                "content": str(message.get("content", ""))[:per_message_chars],
            }
            for message in conversation[-max_history:]
        ]

    def _bound_tool_result(self, result: ToolResult) -> dict[str, Any]:
        payload = result.to_dict()
        max_chars = self.limits.max_investigation_result_chars
        data = payload.get("data")
        if isinstance(data, str) and len(data) > max_chars:
            payload["data"] = data[:max_chars] + "…[truncated]"
        return payload
