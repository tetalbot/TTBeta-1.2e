# Tetal Bot General-Purpose Agent Checklist

Stages are marked complete only after their implementation and checks pass.

## Stage 1 — Existing project stabilization

- [x] Preserve the existing Gemini provider, model setting, and authentication path.
- [x] Fail closed when message or member selection returns no verified IDs.
- [x] Stop restoring executable proposals from persisted chat history after restart.
- [x] Continue in-memory clarifications only when the user replies to the bot's latest message.
- [x] Bound mass moderation to 20 members and show the exact target list before confirmation.
- [x] Report successful and failed targets separately; record partial completion distinctly.
- [x] Replace obsolete Groq test mocks with Gemini-compatible tests.
- [x] Add regression coverage for selection, stale proposals, and partial results.
- [x] Verify at Stage 1: 23 unit tests pass; compile and whitespace checks pass; bot reconnects after restart.

## Stage 2 — Agent and tool architecture

- [x] Extract context gathering, Gemini reasoning, and tool execution into a central orchestrator.
- [x] Add a typed registry and dispatcher for the operations currently supported by the bot.
- [x] Normalize tool results and configure call, reasoning, timeout, concurrency, context, and result limits.
- [x] Add a bounded reasoning loop that feeds read-only results back to Gemini and pauses changes for confirmation.
- [x] Verify Stage 2: 35 unit tests pass; compile and whitespace checks pass.

## Stage 3 — Authorization and confirmations

- [x] Centralize requester, bot, hierarchy, channel, and resource authorization at both agent-loop and sequential-dispatch boundaries.
- [x] Recheck requester and bot Manage Messages permissions in every affected channel before message deletion.
- [x] Add per-guild low-risk automatic-action allowlists with a Manage Server slash command.
- [x] Make the pending-to-executing claim a single conditional database update; startup marks interrupted executions failed without replay.
- [x] Direct tool dispatch is read-only; all modifying actions must use persistent confirmation.

## Stage 4 — PostgreSQL and context

- [x] Define idempotent PostgreSQL migrations for proposals, guilds, channels, members, messages, attachments, links, guild settings, agent tasks, and tool execution records.
- [x] Add a dry-run-first importer for existing SQLite conversations and JSON guild settings/moderation cases; imported rows are idempotent and source files are preserved.
- [x] Event-driven message create/edit/delete collection, bounded full-text retrieval, configurable channel exclusions, and 90-day default retention.
- [x] Runtime conversation-memory cutover to PostgreSQL with a two-hour/20-message bound; legacy SQLite remains available to the explicit importer.
- [x] Historical Discord message backfill is an explicit Manage Server-only operation, scoped to one channel and bounded to 90 days / 5000 messages; no automatic bulk-history ingestion is enabled.
- [x] Per-guild retention days and excluded-channel controls are configurable and persisted in PostgreSQL.

## Stage 5 — Discord operation coverage

- [x] Existing moderation/configuration actions plus read-only server overview, channel listing, permission-filtered recent message search, active threads, server assets, audit logs, invites, webhooks, and retained-message search.
- [x] Confirmed thread/forum operations: create thread, create forum post, archive/unarchive, and lock/unlock.
- [x] Confirmed scheduled-event creation, editing, and deletion with timezone-aware ISO timestamps.
- [x] Confirmed invite creation/revocation and webhook create/edit/delete operations.
- [x] Confirmed keyword-based AutoMod rule create/edit/delete plus read-only rule listing.
- [x] Emoji/sticker creation from visible PNG/image attachments and deletion; audit-log entries can be attached to investigations.
- [x] Role permission editing is supported with strict flag validation and owner-only Administrator grants.
- [x] Common guild settings: system/rules/updates channels, description, default notifications, and explicit-media filtering.
- [ ] Advanced guild settings and unsupported Discord API operations remain.
- [ ] Document Discord permission requirements and unsupported API operations.

## Stage 6 — Investigations

- [x] Bounded, permission-filtered recent message search and safe public HTTP(S) link inspection reject private/reserved destinations, validate DNS answers, follow no redirects, cap bodies at 512 KB, and return untrusted text.
- [x] Persistent investigations with message evidence references, scoped retrieval, status, and closing summaries.
- [x] Slash-command workflow for create/list/show/close, message evidence, safely inspected public URL evidence, and audit-log entry evidence.
- [x] Attachment metadata is retained without storing file bytes. Link inspection is restricted to public HTTP(S), with no redirects and strict bounds.

## Stage 7 — Reliability

- [x] Bounded concurrency and duplicate-call detection are enforced by the agent task limiter and reasoning loop.
- [x] Gemini retries use capped exponential backoff with jitter and shared transient-error classification across all three request paths.
- [x] Content-free token usage metering covers interpreter, agent-step, and message-selection requests.
- [x] Context, tool outputs, and image processing are bounded; Gemini retries distinguish transient failures and use capped exponential backoff with jitter.
- [x] Persist content-free Gemini prompt/candidate/total token counts in PostgreSQL for interpreter and agent-step calls.
- [x] Add Manage Server-gated read-only tools for aggregate AI usage and non-secret bot/database diagnostics.
- [ ] Full operational alerting and structured external monitoring remain.

## Stage 8 — Final verification

- [x] GitHub Actions on commit 4896fb1: Python compile passed; 53 tests and 14 subtests passed; workspace TypeScript typecheck passed.
- [ ] PostgreSQL integration tests against a development database remain.
- [ ] Verify all six migrations, restart, confirmation persistence, and deployment configuration against the actual Replit development environment (not yet run).

## Current storage and coverage notes

- Runtime conversations, proposals, retained context, guild settings, moderation cases, investigations, and Gemini usage are stored in PostgreSQL. Legacy SQLite/JSON files remain import sources.
- PostgreSQL migrations 0000 through 0005 define proposals, context, conversation IDs, investigations, and AI usage. They have not been applied to any database.
- Existing role, channel, category, server-setting, moderation, and message-deletion paths remain available.
- The registry includes permission-filtered server, message, audit, AutoMod, usage, and diagnostics reads. Investigations and evidence ingestion are exposed through slash commands.
- Voice functionality remains explicitly out of scope.
