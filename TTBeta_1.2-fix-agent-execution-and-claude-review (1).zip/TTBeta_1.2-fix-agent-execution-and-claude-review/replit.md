# AI Discord Moderation Bot

A Discord moderation assistant that turns moderator mentions into confirmed, auditable actions using Gemini's multimodal AI.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `uv run python -m bot.main` — run the Discord bot locally
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secrets: `DISCORD_BOT_TOKEN`, `GEMINI_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `bot/main.py` — Discord gateway, slash setup commands, confirmation flow
- `bot/ai.py` — Gemini multimodal structured interpretation
- `bot/context.py` — bounded reads of current, cached rules, staff, and member context
- `bot/memory.py` — SQLite conversation history with expiry and size limits
- `bot/commands/` — validated moderation action handlers
- `bot/config.py` — persisted per-server channel configuration
- `bot/logger.py` — moderation audit messages

## Architecture decisions

- The AI proposes structured actions; Python validates permissions and executes them.
- Rules are cached for one hour; current-channel and staff context remain bounded and on demand.
- Every AI-generated moderation action requires an explicit Discord confirmation.
- Gemini is the configured AI provider and receives image attachments as inline parts when available.

## Product

- Mention the bot with a natural-language moderation request.
- Configure rules, logs, and staff context channels with `/setup`.
- Read recent chat and image attachments when a moderator asks for context.
- Confirm moderation, bulk search/delete, role, channel, category, and server-management proposals.
- DM affected members and write audit details to the configured logs channel.

## User preferences

- Use Gemini only; image analysis is required.
- Missing reasons are allowed and should remain blank rather than being invented.

## Gotchas

- Discord Developer Portal must enable Message Content Intent and Server Members Intent.
- The bot needs Manage Messages, Moderate Members, Kick Members, Ban Members, View Channel, Read Message History, and Send Messages as applicable.
- `GEMINI_MODEL` defaults to `gemini-3.1-flash-lite-preview` and can be overridden if model availability changes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
