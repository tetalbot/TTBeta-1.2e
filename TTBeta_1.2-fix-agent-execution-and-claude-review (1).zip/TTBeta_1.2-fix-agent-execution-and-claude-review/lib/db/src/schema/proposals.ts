import { sql } from "drizzle-orm";
import {
  check,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const proposalsTable = pgTable(
  "proposals",
  {
    id: text("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    operation: text("operation").notNull(),
    arguments: jsonb("arguments").$type<Record<string, unknown>>().notNull(),
    status: text("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    executingAt: timestamp("executing_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    result: jsonb("result").$type<unknown>(),
    metadata: jsonb("metadata")
      .$type<Record<string, unknown>>()
      .notNull()
      .default(sql`'{}'::jsonb`),
  },
  (table) => [
    check(
      "proposals_status_check",
      sql`${table.status} IN ('pending', 'confirmed', 'executing', 'completed', 'partially_completed', 'failed', 'cancelled', 'expired')`,
    ),
    index("proposals_guild_status_idx").on(table.guildId, table.status),
    index("proposals_expires_at_idx").on(table.expiresAt),
  ],
);
