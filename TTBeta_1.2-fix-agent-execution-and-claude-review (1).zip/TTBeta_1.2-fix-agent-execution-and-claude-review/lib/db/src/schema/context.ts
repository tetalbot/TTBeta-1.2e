import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  check,
  customType,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

const tsvector = customType<{ data: string }>({ dataType: () => "tsvector" });

export const guildsTable = pgTable("guilds", {
  guildId: text("guild_id").primaryKey(),
  name: text("name").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const channelsTable = pgTable("channels", {
  channelId: text("channel_id").primaryKey(),
  guildId: text("guild_id").notNull().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  name: text("name").notNull().default(""),
  channelType: text("channel_type").notNull().default("text"),
  parentId: text("parent_id"),
  isArchived: boolean("is_archived").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("channels_guild_idx").on(table.guildId)]);

export const membersTable = pgTable("members", {
  guildId: text("guild_id").notNull().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  userId: text("user_id").notNull(),
  displayName: text("display_name").notNull().default(""),
  isBot: boolean("is_bot").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.guildId, table.userId] })]);

export const messagesTable = pgTable("messages", {
  messageId: text("message_id").primaryKey(),
  guildId: text("guild_id").notNull().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  channelId: text("channel_id").notNull().references(() => channelsTable.channelId, { onDelete: "cascade" }),
  authorId: text("author_id").notNull(),
  content: text("content").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
  editedAt: timestamp("edited_at", { withTimezone: true }),
  referenceMessageId: text("reference_message_id"),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
  contentTsv: tsvector("content_tsv").generatedAlwaysAs(
    sql`to_tsvector('simple', coalesce(content, ''))`,
  ),
}, (table) => [
  index("messages_guild_created_idx").on(table.guildId, table.createdAt).where(sql`deleted_at IS NULL`),
  index("messages_channel_created_idx").on(table.channelId, table.createdAt).where(sql`deleted_at IS NULL`),
  index("messages_content_tsv_idx").using("gin", table.contentTsv),
  index("messages_retention_prune_idx").on(table.createdAt).where(sql`deleted_at IS NULL`),
]);

export const attachmentsTable = pgTable("attachments", {
  attachmentId: text("attachment_id").primaryKey(),
  messageId: text("message_id").notNull().references(() => messagesTable.messageId, { onDelete: "cascade" }),
  filename: text("filename").notNull().default(""),
  contentType: text("content_type"),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull().default(0),
  sourceUrl: text("source_url"),
  contentHash: text("content_hash"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("attachments_message_idx").on(table.messageId)]);

export const messageLinksTable = pgTable("message_links", {
  messageId: text("message_id").notNull().references(() => messagesTable.messageId, { onDelete: "cascade" }),
  url: text("url").notNull(),
}, (table) => [primaryKey({ columns: [table.messageId, table.url] })]);

export const guildSettingsTable = pgTable("guild_settings", {
  guildId: text("guild_id").primaryKey().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  retentionDays: integer("retention_days").notNull().default(90),
  excludedChannelIds: jsonb("excluded_channel_ids").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  rulesChannelId: text("rules_channel_id"),
  logsChannelId: text("logs_channel_id"),
  staffChannelId: text("staff_channel_id"),
  contextMessageLimit: integer("context_message_limit").notNull().default(10),
  rulesMessageLimit: integer("rules_message_limit").notNull().default(0),
  staffMessageLimit: integer("staff_message_limit").notNull().default(0),
  autoExecuteLowRiskActions: jsonb("auto_execute_low_risk_actions").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
}, (table) => [check("guild_settings_retention_check", sql`${table.retentionDays} BETWEEN 1 AND 3650`)]);

export const agentTasksTable = pgTable("agent_tasks", {
  taskId: text("task_id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  status: text("status").notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  summary: text("summary"),
}, (table) => [index("agent_tasks_guild_started_idx").on(table.guildId, table.startedAt)]);

export const toolExecutionsTable = pgTable("tool_executions", {
  executionId: text("execution_id").primaryKey(),
  taskId: text("task_id").references(() => agentTasksTable.taskId, { onDelete: "set null" }),
  guildId: text("guild_id").notNull(),
  toolName: text("tool_name").notNull(),
  riskLevel: text("risk_level").notNull(),
  status: text("status").notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  resultSummary: text("result_summary"),
}, (table) => [index("tool_executions_guild_started_idx").on(table.guildId, table.startedAt)]);

export const conversationMessagesTable = pgTable("conversation_messages", {
  sourceId: bigint("source_id", { mode: "number" }).notNull().default(sql`nextval('conversation_messages_source_id_seq')`),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  channelId: text("channel_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull(),
}, (table) => [primaryKey({ columns: [table.guildId, table.userId, table.channelId, table.sourceId] })]);

export const moderationCasesTable = pgTable("moderation_cases", {
  guildId: text("guild_id").notNull().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  caseId: bigint("case_id", { mode: "number" }).notNull(),
  moderatorId: text("moderator_id").notNull(),
  targetId: text("target_id").notNull(),
  action: text("action").notNull(),
  reason: text("reason"),
  ruleReference: text("rule_reference"),
  evidenceMessageIds: jsonb("evidence_message_ids").$type<number[]>().notNull().default(sql`'[]'::jsonb`),
  proposedAt: timestamp("proposed_at", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("proposed"),
  confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  outcome: text("outcome"),
  durationMinutes: integer("duration_minutes"),
}, (table) => [
  primaryKey({ columns: [table.guildId, table.caseId] }),
  index("moderation_cases_target_idx").on(table.guildId, table.targetId, table.proposedAt),
]);

export const investigationsTable = pgTable("investigations", {
  investigationId: text("investigation_id").primaryKey(),
  guildId: text("guild_id").notNull().references(() => guildsTable.guildId, { onDelete: "cascade" }),
  createdBy: text("created_by").notNull(),
  subjectUserId: text("subject_user_id"),
  title: text("title").notNull(),
  status: text("status").notNull().default("open"),
  summary: text("summary"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
}, (table) => [
  index("investigations_guild_created_idx").on(table.guildId, table.createdAt),
  index("investigations_subject_idx").on(table.guildId, table.subjectUserId, table.createdAt),
]);

export const investigationEvidenceTable = pgTable("investigation_evidence", {
  evidenceId: text("evidence_id").primaryKey(),
  investigationId: text("investigation_id").notNull().references(() => investigationsTable.investigationId, { onDelete: "cascade" }),
  guildId: text("guild_id").notNull(),
  addedBy: text("added_by").notNull(),
  sourceType: text("source_type").notNull(),
  sourceId: text("source_id"),
  channelId: text("channel_id"),
  authorId: text("author_id"),
  excerpt: text("excerpt").notNull().default(""),
  sourceUrl: text("source_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("investigation_evidence_case_idx").on(table.investigationId, table.createdAt),
]);

export const aiUsageTable = pgTable("ai_usage", {
  usageId: bigint("usage_id", { mode: "number" }).primaryKey().generatedAlwaysAsIdentity(),
  guildId: text("guild_id"),
  userId: text("user_id"),
  model: text("model").notNull(),
  operation: text("operation").notNull(),
  promptTokens: integer("prompt_tokens").notNull().default(0),
  candidateTokens: integer("candidate_tokens").notNull().default(0),
  totalTokens: integer("total_tokens").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("ai_usage_guild_created_idx").on(table.guildId, table.createdAt),
  index("ai_usage_created_idx").on(table.createdAt),
]);
