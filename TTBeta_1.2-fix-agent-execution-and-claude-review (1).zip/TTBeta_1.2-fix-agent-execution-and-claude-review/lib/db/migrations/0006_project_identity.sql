-- Persistent attribution identity checked by the bot at startup.
CREATE TABLE IF NOT EXISTS project_identity (
    project_id TEXT PRIMARY KEY,
    owner TEXT NOT NULL,
    creator TEXT NOT NULL,
    attribution TEXT NOT NULL,
    copyright TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO project_identity (
    project_id, owner, creator, attribution, copyright
)
VALUES (
    'TETALBOT-TRITRAX-2026',
    'Tritrax',
    'Tritrax',
    'Made by Tritrax | Owned by Tritrax',
    'Copyright (c) 2026 Tritrax'
)
ON CONFLICT (project_id) DO NOTHING;
