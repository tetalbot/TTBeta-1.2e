CREATE TABLE IF NOT EXISTS ai_usage (
    usage_id BIGSERIAL PRIMARY KEY,
    guild_id TEXT,
    user_id TEXT,
    model TEXT NOT NULL,
    operation TEXT NOT NULL,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    candidate_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ai_usage_guild_created_idx
    ON ai_usage(guild_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ai_usage_created_idx
    ON ai_usage(created_at DESC);
