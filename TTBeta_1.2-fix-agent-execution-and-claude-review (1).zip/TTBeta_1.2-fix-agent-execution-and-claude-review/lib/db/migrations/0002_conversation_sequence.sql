-- Make source_id database-generated so callers can append ordered conversation rows.
CREATE SEQUENCE IF NOT EXISTS conversation_messages_source_id_seq;
ALTER TABLE conversation_messages
    ALTER COLUMN source_id SET DEFAULT nextval('conversation_messages_source_id_seq');
SELECT setval(
    'conversation_messages_source_id_seq',
    GREATEST(COALESCE((SELECT MAX(source_id) FROM conversation_messages), 0) + 1, 1),
    false
);
