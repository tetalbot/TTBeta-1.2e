-- Persistent investigation records and explicitly attached evidence references.
CREATE TABLE IF NOT EXISTS investigations (
    investigation_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    created_by TEXT NOT NULL,
    subject_user_id TEXT,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'closed', 'archived')),
    summary TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS investigations_guild_created_idx
    ON investigations(guild_id, created_at DESC);
CREATE INDEX IF NOT EXISTS investigations_subject_idx
    ON investigations(guild_id, subject_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS investigation_evidence (
    evidence_id TEXT PRIMARY KEY,
    investigation_id TEXT NOT NULL REFERENCES investigations(investigation_id) ON DELETE CASCADE,
    guild_id TEXT NOT NULL,
    added_by TEXT NOT NULL,
    source_type TEXT NOT NULL CHECK (source_type IN ('discord_message', 'public_url', 'note')),
    source_id TEXT,
    channel_id TEXT,
    author_id TEXT,
    excerpt TEXT NOT NULL DEFAULT '',
    source_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS investigation_evidence_case_idx
    ON investigation_evidence(investigation_id, created_at);
