-- Bounded server context and audit metadata. Apply after 0000_proposals.sql.
-- No message content or attachment bytes are backfilled by this migration.

CREATE TABLE IF NOT EXISTS guilds (
    guild_id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS channels (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    name TEXT NOT NULL DEFAULT '',
    channel_type TEXT NOT NULL DEFAULT 'text',
    parent_id TEXT,
    is_archived BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS channels_guild_idx ON channels(guild_id);

CREATE TABLE IF NOT EXISTS members (
    guild_id TEXT NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT '',
    is_bot BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
    message_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    channel_id TEXT NOT NULL REFERENCES channels(channel_id) ON DELETE CASCADE,
    author_id TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL,
    edited_at TIMESTAMPTZ,
    reference_message_id TEXT,
    deleted_at TIMESTAMPTZ,
    content_tsv TSVECTOR GENERATED ALWAYS AS (
        to_tsvector('simple', coalesce(content, ''))
    ) STORED
);
CREATE INDEX IF NOT EXISTS messages_guild_created_idx
    ON messages(guild_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS messages_channel_created_idx
    ON messages(channel_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS messages_content_tsv_idx
    ON messages USING GIN(content_tsv);

CREATE TABLE IF NOT EXISTS attachments (
    attachment_id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    filename TEXT NOT NULL DEFAULT '',
    content_type TEXT,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    source_url TEXT,
    content_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS attachments_message_idx ON attachments(message_id);

CREATE TABLE IF NOT EXISTS message_links (
    message_id TEXT NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    PRIMARY KEY (message_id, url)
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id TEXT PRIMARY KEY REFERENCES guilds(guild_id) ON DELETE CASCADE,
    retention_days INTEGER NOT NULL DEFAULT 90 CHECK (retention_days BETWEEN 1 AND 3650),
    excluded_channel_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agent_tasks (
    task_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    status TEXT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    summary TEXT
);
CREATE INDEX IF NOT EXISTS agent_tasks_guild_started_idx
    ON agent_tasks(guild_id, started_at DESC);

CREATE TABLE IF NOT EXISTS tool_executions (
    execution_id TEXT PRIMARY KEY,
    task_id TEXT REFERENCES agent_tasks(task_id) ON DELETE SET NULL,
    guild_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    status TEXT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    result_summary TEXT
);
CREATE INDEX IF NOT EXISTS tool_executions_guild_started_idx
    ON tool_executions(guild_id, started_at DESC);

CREATE TABLE IF NOT EXISTS conversation_messages (
    source_id BIGINT NOT NULL,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (guild_id, user_id, channel_id, source_id)
);
CREATE INDEX IF NOT EXISTS conversation_messages_lookup_idx
    ON conversation_messages(guild_id, user_id, channel_id, created_at DESC);

CREATE TABLE IF NOT EXISTS moderation_cases (
    guild_id TEXT NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    case_id BIGINT NOT NULL,
    moderator_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    action TEXT NOT NULL,
    reason TEXT,
    rule_reference TEXT,
    evidence_message_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    proposed_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'proposed',
    confirmed_at TIMESTAMPTZ,
    closed_at TIMESTAMPTZ,
    outcome TEXT,
    duration_minutes INTEGER,
    PRIMARY KEY (guild_id, case_id)
);
CREATE INDEX IF NOT EXISTS moderation_cases_target_idx
    ON moderation_cases(guild_id, target_id, proposed_at DESC);

ALTER TABLE guild_settings
    ADD COLUMN IF NOT EXISTS rules_channel_id TEXT,
    ADD COLUMN IF NOT EXISTS logs_channel_id TEXT,
    ADD COLUMN IF NOT EXISTS staff_channel_id TEXT,
    ADD COLUMN IF NOT EXISTS context_message_limit INTEGER NOT NULL DEFAULT 10,
    ADD COLUMN IF NOT EXISTS rules_message_limit INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS staff_message_limit INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS auto_execute_low_risk_actions JSONB NOT NULL DEFAULT '[]'::jsonb;
