-- Initial PostgreSQL schema for persistent Discord action proposals.
-- Safe to run repeatedly. This migration creates no application data and does not
-- modify existing tables.

CREATE TABLE IF NOT EXISTS proposals (
    id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    arguments JSONB NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    confirmed_at TIMESTAMPTZ,
    executing_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    result JSONB,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    CONSTRAINT proposals_status_check CHECK (
        status IN (
            'pending',
            'confirmed',
            'executing',
            'completed',
            'partially_completed',
            'failed',
            'cancelled',
            'expired'
        )
    )
);

CREATE INDEX IF NOT EXISTS proposals_guild_status_idx
    ON proposals (guild_id, status);

CREATE INDEX IF NOT EXISTS proposals_expires_at_idx
    ON proposals (expires_at);
