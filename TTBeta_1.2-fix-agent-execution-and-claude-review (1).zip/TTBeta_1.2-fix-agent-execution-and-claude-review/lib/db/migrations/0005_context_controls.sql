-- Context retention controls are defined in 0001; this migration adds a pruning index.
CREATE INDEX IF NOT EXISTS messages_retention_prune_idx
    ON messages(created_at) WHERE deleted_at IS NULL;
