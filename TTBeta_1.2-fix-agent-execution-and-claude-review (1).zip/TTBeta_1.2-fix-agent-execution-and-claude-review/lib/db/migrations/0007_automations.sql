CREATE TABLE IF NOT EXISTS automation_rules (
    id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    created_by TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    trigger_event TEXT NOT NULL CHECK (trigger_event IN (
        'member_join', 'member_leave', 'message_contains', 'reaction_add',
        'voice_join', 'role_assign', 'role_remove'
    )),
    trigger_conditions JSONB NOT NULL DEFAULT '{}'::jsonb,
    action_sequence JSONB NOT NULL,
    use_ai_reasoning BOOLEAN NOT NULL DEFAULT FALSE,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_executed_at TIMESTAMPTZ,
    execution_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT
);

CREATE INDEX IF NOT EXISTS automation_rules_event_idx
    ON automation_rules (guild_id, trigger_event, enabled);

CREATE TABLE IF NOT EXISTS automation_executions (
    id TEXT PRIMARY KEY,
    rule_id TEXT NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
    guild_id TEXT NOT NULL,
    event_key TEXT NOT NULL,
    triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    trigger_data JSONB NOT NULL,
    result TEXT NOT NULL CHECK (result IN (
        'running', 'success', 'failed', 'skipped', 'partial'
    )),
    actions_taken JSONB NOT NULL DEFAULT '[]'::jsonb,
    error TEXT,
    UNIQUE (rule_id, event_key)
);

CREATE INDEX IF NOT EXISTS automation_executions_rule_idx
    ON automation_executions (rule_id, triggered_at DESC);
