# PostgreSQL migrations

The bot requires migrations 0000 through 0007 before startup:

1. `0000_proposals.sql`: persistent proposals and confirmation state.
2. `0001_context_storage.sql`: guild settings, message context, retained evidence metadata, task and execution records.
3. `0002_conversation_sequence.sql`: generated source IDs for bounded conversation history.
4. `0003_investigations.sql`: server-scoped investigations and evidence.
5. `0004_ai_usage.sql`: content-free Gemini token usage accounting.
6. `0005_context_controls.sql`: retention-pruning index.
7. `0006_project_identity.sql`: persistent Tritrax ownership identity checked at startup.
8. `0007_automations.sql`: approved event-driven automation rules and execution history.

## Check migration status

Set `DATABASE_URL` to any reachable **development PostgreSQL database** and run. The database can be hosted by any PostgreSQL provider; the bot is not tied to Replit or to a particular hosting platform. Configure `DATABASE_URL` as an environment secret on each deployment:

```sh
uv run python scripts/apply_migrations.py
```

This is a dry run. It connects to PostgreSQL, lists the eight repository migrations,
checks the optional migration-history table, and makes no schema changes.

## Apply migrations

Back up the development database, verify that `DATABASE_URL` points to the
intended development database, then run:

```sh
uv run python scripts/apply_migrations.py --apply
```

The runner asks for the literal confirmation `APPLY`, applies migrations in
numeric order, wraps each migration and its history record in one transaction,
and takes a PostgreSQL advisory lock to prevent two runner processes from
applying migrations concurrently. It records SHA-256 checksums and refuses to
silently accept a changed migration file. If a database has older migrations
that were applied manually, the SQL files are designed to be rerunnable; the
runner will execute unrecorded migrations and then begin tracking them.

The SQL creates tables and indexes and adds required columns. It does not delete
application rows. Do not run migrations against production without a backup and
explicit approval from the repository owner.

After applying all eight migrations, start the bot and verify that
`verify_schema()` succeeds. Runtime proposals, conversations, retained message
context, guild settings, moderation cases, and investigations use PostgreSQL.
Legacy SQLite conversations and JSON settings/cases remain import sources.

Message content is retained for 90 days by default and can be shortened or
lengthened per server. Individual channels can be excluded from indexing. A
Manage Server-only `/context_backfill` command performs explicitly requested,
bounded history ingestion. Conversation history is bounded to 20 messages and
two hours. Attachment bytes are not stored.

## Legacy data import

The optional importer is `scripts/import_legacy_data.py`. It reads the existing
SQLite conversation database and JSON guild/case files without modifying them.

Run a dry-run first:

```sh
python scripts/import_legacy_data.py
```

Back up the source files and use a development database before writing:

```sh
python scripts/import_legacy_data.py --apply
```

The import is additive and idempotent. It does not delete or rewrite legacy
files. Never use `--apply` against production without an owner-approved backup
and migration window.

## TetalBot ownership integrity

The bot verifies a signed Ed25519 ownership manifest before opening its Discord
connection and checks the matching project identity row in PostgreSQL. The
embedded public key is safe to commit; the private signing key is not.

Initialize the owner key once, on a trusted development machine:

    uv run python scripts/ownership.py init

Back up the generated file under .secrets/ to offline storage. Never commit,
upload, or share that private key. Then sign the current protected source tree:

    uv run python scripts/ownership.py sign

Commit the generated public-key module and ownership_manifest.json. Every
intentional edit to a protected runtime file or migration requires re-signing
the release with the owner key. If the manifest, identity, or a protected file
is changed without a valid signature, startup fails closed.

For a new release, first complete code changes, then run the signing command.
Do not regenerate the owner key for routine releases. If the private key is
lost, the pinned public key must be deliberately rotated through a reviewed
source change; there is no hidden recovery bypass.