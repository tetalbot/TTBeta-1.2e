"""Dry-run-first importer for legacy SQLite conversations and JSON state."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sqlite3
from pathlib import Path
from typing import Any

import asyncpg


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA = ROOT / "bot" / "data"


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def read_legacy(sqlite_path: Path, config_path: Path, cases_path: Path) -> dict[str, Any]:
    config = load_json(config_path, {})
    cases = load_json(cases_path, [])
    conversations: list[dict[str, Any]] = []
    if sqlite_path.exists():
        with sqlite3.connect(sqlite_path) as connection:
            connection.row_factory = sqlite3.Row
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(conversation_messages)")
            }
            required = {"id", "guild_id", "user_id", "channel_id", "role", "content", "created_at"}
            if required.issubset(columns):
                conversations = [
                    dict(row)
                    for row in connection.execute(
                        """
                        SELECT id, guild_id, user_id, channel_id, role, content, created_at
                        FROM conversation_messages
                        """
                    )
                ]
    return {
        "guilds": config if isinstance(config, dict) else {},
        "cases": cases if isinstance(cases, list) else [],
        "conversations": conversations,
    }


async def import_data(database_url: str, data: dict[str, Any]) -> None:
    pool = await asyncpg.create_pool(database_url, min_size=1, max_size=3)
    try:
        async with pool.acquire() as connection:
            async with connection.transaction():
                for raw_guild_id, values in data["guilds"].items():
                    if not isinstance(values, dict):
                        continue
                    guild_id = str(raw_guild_id)
                    await connection.execute(
                        "INSERT INTO guilds (guild_id) VALUES ($1) ON CONFLICT DO NOTHING",
                        guild_id,
                    )
                    await connection.execute(
                        """
                        INSERT INTO guild_settings (
                            guild_id, rules_channel_id, logs_channel_id, staff_channel_id,
                            context_message_limit, rules_message_limit, staff_message_limit,
                            auto_execute_low_risk_actions
                        )
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)
                        ON CONFLICT (guild_id) DO UPDATE SET
                            rules_channel_id=EXCLUDED.rules_channel_id,
                            logs_channel_id=EXCLUDED.logs_channel_id,
                            staff_channel_id=EXCLUDED.staff_channel_id,
                            context_message_limit=EXCLUDED.context_message_limit,
                            rules_message_limit=EXCLUDED.rules_message_limit,
                            staff_message_limit=EXCLUDED.staff_message_limit,
                            auto_execute_low_risk_actions=EXCLUDED.auto_execute_low_risk_actions
                        """,
                        guild_id,
                        str(values["rules_channel_id"]) if values.get("rules_channel_id") else None,
                        str(values["logs_channel_id"]) if values.get("logs_channel_id") else None,
                        str(values["staff_channel_id"]) if values.get("staff_channel_id") else None,
                        int(values.get("context_message_limit", 10)),
                        int(values.get("rules_message_limit", 0)),
                        int(values.get("staff_message_limit", 0)),
                        json.dumps(values.get("auto_execute_low_risk_actions", [])),
                    )
                for case in data["cases"]:
                    if not isinstance(case, dict):
                        continue
                    guild_id = str(case.get("guild_id", ""))
                    if not guild_id or case.get("case_id") is None:
                        continue
                    await connection.execute(
                        "INSERT INTO guilds (guild_id) VALUES ($1) ON CONFLICT DO NOTHING",
                        guild_id,
                    )
                    await connection.execute(
                        """
                        INSERT INTO moderation_cases (
                            guild_id, case_id, moderator_id, target_id, action, reason,
                            rule_reference, evidence_message_ids, proposed_at, status,
                            confirmed_at, closed_at, outcome, duration_minutes
                        )
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11,$12,$13,$14)
                        ON CONFLICT (guild_id, case_id) DO NOTHING
                        """,
                        guild_id,
                        int(case["case_id"]),
                        str(case.get("moderator_id", 0)),
                        str(case.get("target_id", 0)),
                        str(case.get("action", "unknown")),
                        case.get("reason"),
                        case.get("rule_reference"),
                        json.dumps(case.get("evidence_message_ids", [])),
                        case["proposed_at"],
                        str(case.get("status", "proposed")),
                        case.get("confirmed_at"),
                        case.get("closed_at"),
                        case.get("outcome"),
                        case.get("duration_minutes"),
                    )
                for item in data["conversations"]:
                    await connection.execute(
                        """
                        INSERT INTO conversation_messages (
                            source_id, guild_id, user_id, channel_id, role, content, created_at
                        )
                        VALUES ($1,$2,$3,$4,$5,$6,$7)
                        ON CONFLICT DO NOTHING
                        """,
                        int(item["id"]),
                        str(item["guild_id"]),
                        str(item["user_id"]),
                        str(item["channel_id"]),
                        str(item["role"])[:20],
                        str(item["content"])[:4000],
                        item["created_at"],
                    )
                await connection.execute("""
                    SELECT setval(
                        'conversation_messages_source_id_seq',
                        GREATEST(COALESCE((SELECT MAX(source_id) FROM conversation_messages), 0) + 1, 1),
                        false
                    )
                """)
    finally:
        await pool.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sqlite-path", type=Path, default=DEFAULT_DATA / "conversations.sqlite3")
    parser.add_argument("--config-path", type=Path, default=DEFAULT_DATA / "guild_config.json")
    parser.add_argument("--cases-path", type=Path, default=DEFAULT_DATA / "moderation_cases.json")
    parser.add_argument("--apply", action="store_true", help="Write to DATABASE_URL. Default is dry-run.")
    args = parser.parse_args()
    data = read_legacy(args.sqlite_path, args.config_path, args.cases_path)
    print(
        "Legacy data found: "
        f"{len(data['guilds'])} guild configs, "
        f"{len(data['cases'])} moderation cases, "
        f"{len(data['conversations'])} conversation rows."
    )
    if not args.apply:
        print("Dry run only. No database was changed. Add --apply after backing up and verifying the development database.")
        return
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise SystemExit("DATABASE_URL is required when --apply is used.")
    asyncio.run(import_data(database_url, data))
    print("Import completed. Source SQLite and JSON files were left untouched.")


if __name__ == "__main__":
    main()
