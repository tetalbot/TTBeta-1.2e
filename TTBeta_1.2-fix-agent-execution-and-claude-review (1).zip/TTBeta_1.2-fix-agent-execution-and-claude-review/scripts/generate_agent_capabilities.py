"""Regenerate AGENT_CAPABILITIES.md from TetalBot's live registries."""

from __future__ import annotations

import sys
from pathlib import Path

# Running this file directly puts scripts/ rather than the repository root
# at sys.path[0]. Add the project root so the bot package is importable.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from bot.capabilities import generate_agent_capabilities


if __name__ == "__main__":
    content = generate_agent_capabilities(PROJECT_ROOT / "AGENT_CAPABILITIES.md")
    print(f"Generated AGENT_CAPABILITIES.md ({len(content)} characters).")
