"""Initialize the offline owner key and sign the TetalBot release manifest."""
from __future__ import annotations
import argparse, base64, hashlib, json, os
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
ROOT = Path(__file__).resolve().parents[1]
PRIVATE_KEY = ROOT / ".secrets" / "tetalbot_ownership_ed25519.pem"
PUBLIC_KEY = ROOT / "bot/security/ownership_public_key.py"
MANIFEST = ROOT / "ownership_manifest.json"
IDENTITY = {"project_id":"TETALBOT-TRITRAX-2026","project_name":"TetalBot","owner":"Tritrax","creator":"Tritrax","attribution":"Made by Tritrax | Owned by Tritrax","copyright":"Copyright (c) 2026 Tritrax"}
FILES = (
 "bot/main.py","bot/ai.py","bot/agent/orchestrator.py",
 "bot/tools/diagnostics.py","bot/diagnostics/__init__.py","bot/diagnostics/log_buffer.py",
 "bot/security/authorization.py",
 "bot/security/risk_policy.py","bot/security/ownership.py","bot/security/ownership_public_key.py",
 "bot/tools/dispatcher.py","bot/tools/moderation.py","bot/database/connection.py","bot/database/proposals.py",
 "lib/db/migrations/0000_proposals.sql","lib/db/migrations/0001_context_storage.sql",
 "lib/db/migrations/0002_conversation_sequence.sql","lib/db/migrations/0003_investigations.sql",
 "lib/db/migrations/0004_ai_usage.sql","lib/db/migrations/0005_context_controls.sql",
 "lib/db/migrations/0006_project_identity.sql",
 "scripts/ownership.py","pyproject.toml","uv.lock",
)
def canonical(value):
 return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
def init_key():
 if PRIVATE_KEY.exists(): raise SystemExit("Private key already exists; refusing to overwrite it.")
 old=PUBLIC_KEY.read_text(encoding="utf-8")
 if 'PUBLIC_KEY_B64 = ""' not in old: raise SystemExit("Public key is already initialized; refusing to replace it.")
 PRIVATE_KEY.parent.mkdir(parents=True,exist_ok=True)
 key=Ed25519PrivateKey.generate()
 pem=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
 raw=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
 PRIVATE_KEY.write_bytes(pem)
 try: os.chmod(PRIVATE_KEY,0o600)
 except OSError: pass
 PUBLIC_KEY.write_text('"""Pinned Ed25519 public key for TetalBot release attribution."""\n\nPUBLIC_KEY_B64 = "'+base64.b64encode(raw).decode("ascii")+'"\n',encoding="utf-8")
 print("Private key created at:",PRIVATE_KEY)
 print("Back it up offline. Never commit or upload it.")
 print("Public key pinned in bot/security/ownership_public_key.py.")
 print("Next: python scripts/ownership.py sign")
def sign_manifest():
 if not PRIVATE_KEY.is_file(): raise SystemExit("Private key missing. Run the init command first.")
 key=serialization.load_pem_private_key(PRIVATE_KEY.read_bytes(),password=None)
 if not isinstance(key,Ed25519PrivateKey): raise SystemExit("Expected an Ed25519 private key.")
 hashes={}
 for relative in FILES:
  path=ROOT/relative
  if not path.is_file(): raise SystemExit("Protected file missing: "+relative)
  hashes[relative]=hashlib.sha256(path.read_bytes()).hexdigest()
 payload={"manifest_version":1,"identity":IDENTITY,"files":hashes}
 signature=key.sign(canonical(payload))
 MANIFEST.write_text(json.dumps({"payload":payload,"signature":base64.b64encode(signature).decode("ascii")},indent=2,sort_keys=True)+"\n",encoding="utf-8")
 print("Signed manifest written:",MANIFEST)
 print("Protected files:",len(hashes))
 print("Keep the private key offline; commit only the public key and signed manifest.")
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 subs=parser.add_subparsers(dest="command",required=True)
 subs.add_parser("init",help="Generate the owner-only Ed25519 signing key.")
 subs.add_parser("sign",help="Sign the current protected source tree.")
 command=parser.parse_args().command
 init_key() if command=="init" else sign_manifest()
if __name__=="__main__": main()