"""Replit/Render entry point that selects Neon and exposes a tiny health endpoint."""

from __future__ import annotations

import json
import os
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class _HealthHandler(BaseHTTPRequestHandler):
    def _respond(self, status: HTTPStatus) -> None:
        body = json.dumps({"status": "ok" if status is HTTPStatus.OK else "not_found"}).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path in ("/", "/health", "/healthz"):
            self._respond(HTTPStatus.OK)
        else:
            self._respond(HTTPStatus.NOT_FOUND)

    def do_HEAD(self) -> None:
        if self.path in ("/", "/health", "/healthz"):
            self._respond(HTTPStatus.OK)
        else:
            self._respond(HTTPStatus.NOT_FOUND)

    def log_message(self, format: str, *args: object) -> None:
        # Keep routine platform health checks out of the bot logs.
        return


def _start_health_server() -> None:
    raw_port = os.getenv("PORT")
    if not raw_port:
        return

    port = int(raw_port)
    if not 1 <= port <= 65535:
        raise ValueError(f"Invalid PORT value: {raw_port!r}")

    server = ThreadingHTTPServer(("0.0.0.0", port), _HealthHandler)
    server.daemon_threads = True
    thread = threading.Thread(
        target=server.serve_forever,
        name="render-health-server",
        daemon=True,
    )
    thread.start()


def main() -> None:
    from scripts.database_env import configure_database_url

    configure_database_url()
    _start_health_server()

    from bot.main import run

    run()


if __name__ == "__main__":
    main()
