"""Run migrations using the configured Neon database URL."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scripts.database_env import configure_database_url
from scripts.apply_migrations import main as run_migrations


def main() -> None:
    configure_database_url()
    run_migrations()


if __name__ == "__main__":
    main()
