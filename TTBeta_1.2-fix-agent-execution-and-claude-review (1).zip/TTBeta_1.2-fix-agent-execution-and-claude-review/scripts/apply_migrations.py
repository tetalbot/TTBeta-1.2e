"""Safe, ordered PostgreSQL migration runner for Tetal Bot.

Dry-run is the default. Pass --apply to execute pending migrations.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import re
from pathlib import Path
from typing import Any

import asyncpg


ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS_DIR = ROOT / "lib" / "db" / "migrations"
MIGRATION_NAME = re.compile(r"^(?P<version>\d{4})_[a-z0-9_]+\.sql$")
LOCK_ID = 7_405_219_031


def load_migrations() -> list[tuple[str, str, str, str]]:
    migrations: list[tuple[str, str, str, str]] = []
    for path in sorted(MIGRATIONS_DIR.glob("[0-9][0-9][0-9][0-9]_*.sql")):
        match = MIGRATION_NAME.fullmatch(path.name)
        if match is None:
            raise RuntimeError(f"Invalid migration filename: {path.name}")
        content = path.read_text(encoding="utf-8")
        if not content.strip():
            raise RuntimeError(f"Migration is empty: {path.name}")
        checksum = hashlib.sha256(content.encode("utf-8")).hexdigest()
        migrations.append((match.group("version"), path.name, content, checksum))

    if not migrations:
        raise RuntimeError(f"No SQL migrations found in {MIGRATIONS_DIR}")
    versions = [item[0] for item in migrations]
    if len(versions) != len(set(versions)):
        raise RuntimeError("Duplicate migration version detected.")
    return migrations


async def inspect_database(database_url: str, migrations: list[tuple[str, str, str, str]]) -> None:
    connection = await asyncpg.connect(database_url)
    try:
        exists = await connection.fetchval(
            "SELECT to_regclass('public._tetalbot_schema_migrations') IS NOT NULL"
        )
        applied: dict[str, str] = {}
        if exists:
            rows = await connection.fetch(
                "SELECT version, filename, checksum FROM _tetalbot_schema_migrations ORDER BY version"
            )
            applied = {str(row["version"]): str(row["checksum"]) for row in rows}

        print(f"Database connection: OK")
        if not exists:
            print("Migration history: not initialized; migrations will be checked against the current schema.")
        else:
            print(f"Migration history: {len(applied)} recorded migration(s).")

        pending = 0
        for version, filename, _sql, checksum in migrations:
            old_checksum = applied.get(version)
            if old_checksum is None:
                pending += 1
                state = "PENDING"
            elif old_checksum != checksum:
                raise RuntimeError(
                    f"Checksum mismatch for applied migration {filename}. "
                    "Do not edit an applied migration; create a new migration instead."
                )
            else:
                state = "APPLIED"
            print(f"{state}: {filename}")
        unknown = sorted(set(applied) - {item[0] for item in migrations})
        if unknown:
            raise RuntimeError(
                "Database contains migration versions absent from this checkout: "
                + ", ".join(unknown)
            )
        if pending:
            print(f"\n{pending} migration(s) need applying.")
        else:
            print("\nAll repository migrations are recorded as applied.")
    finally:
        await connection.close()


async def apply_migrations(
    database_url: str, migrations: list[tuple[str, str, str, str]]
) -> None:
    connection = await asyncpg.connect(database_url)
    try:
        await connection.execute("SELECT pg_advisory_lock($1)", LOCK_ID)
        await connection.execute(
            """
            CREATE TABLE IF NOT EXISTS _tetalbot_schema_migrations (
                version TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                checksum TEXT NOT NULL,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )

        for version, filename, sql, checksum in migrations:
            existing = await connection.fetchrow(
                "SELECT filename, checksum FROM _tetalbot_schema_migrations WHERE version = $1",
                version,
            )
            if existing:
                if existing["checksum"] != checksum:
                    raise RuntimeError(
                        f"Checksum mismatch for {filename}; refusing to modify migration history."
                    )
                print(f"Already applied: {filename}")
                continue

            print(f"Applying: {filename}")
            async with connection.transaction():
                await connection.execute(sql)
                await connection.execute(
                    """
                    INSERT INTO _tetalbot_schema_migrations (version, filename, checksum)
                    VALUES ($1, $2, $3)
                    """,
                    version,
                    filename,
                    checksum,
                )
            print(f"Applied: {filename}")

        print("All migrations completed successfully.")
    finally:
        try:
            await connection.execute("SELECT pg_advisory_unlock($1)", LOCK_ID)
        finally:
            await connection.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply pending migrations. Without this flag, only inspect migration status.",
    )
    args = parser.parse_args()
    database_url = os.getenv("DATABASE_URL")
    if not database_url:
        raise SystemExit("DATABASE_URL is not configured.")

    migrations = load_migrations()
    if args.apply:
        print("WARNING: migrations will modify the PostgreSQL schema.")
        print("Use a development database and take a backup before continuing.")
        confirmation = input("Type APPLY to continue: ").strip()
        if confirmation != "APPLY":
            raise SystemExit("Cancelled. No migrations were applied.")
        asyncio.run(apply_migrations(database_url, migrations))
    else:
        asyncio.run(inspect_database(database_url, migrations))
        print("Dry run only. No database changes were made.")
        print("To apply after verifying this is the development database, run:")
        print("  uv run python scripts/apply_migrations.py --apply")


if __name__ == "__main__":
    main()
