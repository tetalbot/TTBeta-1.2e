"""Resolve the PostgreSQL URL without accidentally using Replit's attached database."""

from __future__ import annotations

import os


def configure_database_url() -> str:
    """Prefer the explicitly configured Neon URL, then fall back to DATABASE_URL."""
    neon_url = os.getenv("NEON_DATABASE_URL", "").strip()
    database_url = os.getenv("DATABASE_URL", "").strip()
    selected = neon_url or database_url
    if not selected:
        raise RuntimeError(
            "Database connection is not configured. Set NEON_DATABASE_URL "
            "(recommended) or DATABASE_URL in the runtime secrets."
        )
    os.environ["DATABASE_URL"] = selected
    return selected
